"""Tests for resolve_bridge.py — bridge mode response shapes and error paths.

These tests exercise the Python bridge modes without needing a running Resolve
instance.  They mock the Resolve API layer and assert the JSON shape of every
response path (success, missing-project, missing-timeline, bad-token, missing-
token).

Run with:  python -m pytest App/tests/test_resolve_bridge.py -v
"""

import json
import os
import signal
import subprocess
import time
import unittest
from unittest.mock import MagicMock, patch

# We import the module directly so we can call each mode handler function
# and patch the Resolve API layer underneath it.
import sys

# The bridge lives under App/Resolve — make it importable from the test dir.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "Resolve"))

import resolve_bridge


def _named_placed_timeline_item():
    """Model Resolve's SetName/GetName round trip for placed timeline clips."""
    item = MagicMock()
    state = {"name": None}

    def set_name(name):
        state["name"] = name
        return True

    item.SetName.side_effect = set_name
    item.GetName.side_effect = lambda: state["name"]
    return item


def _run_signal_child(source, timeout=5):
    """Run a signal-focused child with a hard deadline and guaranteed cleanup."""
    child = subprocess.Popen(
        [sys.executable, "-c", source],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    try:
        stdout, stderr = child.communicate(timeout=timeout)
        return child.returncode, stdout, stderr
    except Exception:
        child.kill()
        child.communicate(timeout=2)
        raise


def _run_signal_child_with_open_stdin(source, timeout=5, signum=signal.SIGTERM):
    """Run a child while leaving stdin open, with a hard deadline and cleanup."""
    child = subprocess.Popen(
        [sys.executable, "-c", source],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    try:
        time.sleep(0.1)
        os.kill(child.pid, signum)
        deadline = time.monotonic() + timeout
        while child.poll() is None and time.monotonic() < deadline:
            time.sleep(0.01)
        if child.poll() is None:
            child.kill()
            raise AssertionError("signal child exceeded hard deadline")
        stdout, stderr = child.communicate(timeout=2)
        return child.returncode, stdout, stderr
    finally:
        if child.poll() is None:
            child.kill()
            child.communicate(timeout=2)


class TestDeferredSigterm(unittest.TestCase):
    """SIGTERM is deferred so the bridge emits at most its normal response."""

    def test_sigterm_before_dispatch_uses_controlled_error(self):
        source = f"""
import os, sys
sys.path.insert(0, {repr(os.path.join(os.path.dirname(__file__), '..', 'Resolve'))})
import resolve_bridge
resolve_bridge.MODES['synthetic'] = lambda request: (_ for _ in ()).throw(RuntimeError('must not run'))
resolve_bridge._install_signal_handlers()
os.kill(os.getpid(), __import__('signal').SIGTERM)
sys.exit(resolve_bridge.main(['resolve_bridge.py', 'synthetic']))
"""
        code, stdout, stderr = _run_signal_child(source)
        lines = [json.loads(line) for line in stdout.splitlines() if line]
        self.assertEqual(code, 3)
        self.assertEqual(len(lines), 1)
        self.assertFalse(lines[0]["ok"])
        self.assertEqual(lines[0]["error"]["code"], "shutdown-requested")
        self.assertEqual(stderr, "")

    def test_sigterm_while_waiting_for_open_stdin_exits_promptly(self):
        source = f"""
import sys
sys.path.insert(0, {repr(os.path.join(os.path.dirname(__file__), '..', 'Resolve'))})
import resolve_bridge
resolve_bridge.MODES['synthetic'] = lambda request: (_ for _ in ()).throw(RuntimeError('must not run'))
sys.exit(resolve_bridge.main(['resolve_bridge.py', 'synthetic']))
"""
        started = time.monotonic()
        code, stdout, stderr = _run_signal_child_with_open_stdin(source)
        elapsed = time.monotonic() - started
        lines = [json.loads(line) for line in stdout.splitlines() if line]
        self.assertLess(elapsed, 2)
        self.assertEqual(code, 3)
        self.assertEqual(len(lines), 1)
        self.assertFalse(lines[0]["ok"])
        self.assertEqual(lines[0]["error"]["code"], "shutdown-requested")
        self.assertEqual(stderr, "")

    def test_sigterm_during_work_is_deferred(self):
        source = f"""
import os, sys, time, signal
sys.path.insert(0, {repr(os.path.join(os.path.dirname(__file__), '..', 'Resolve'))})
import resolve_bridge
def work(request):
    os.kill(os.getpid(), signal.SIGTERM)
    time.sleep(0.4)
    return {{'completed': True}}
resolve_bridge.MODES['synthetic'] = work
sys.exit(resolve_bridge.main(['resolve_bridge.py', 'synthetic']))
"""
        code, stdout, stderr = _run_signal_child(source)
        lines = [json.loads(line) for line in stdout.splitlines() if line]
        self.assertEqual(code, 0)
        self.assertEqual(len(lines), 1)
        self.assertTrue(lines[0]["ok"])
        self.assertEqual(lines[0]["data"], {"completed": True})
        self.assertEqual(stderr, "")

    def test_repeated_sigterm_remains_single_response(self):
        source = f"""
import os, sys, time, signal
sys.path.insert(0, {repr(os.path.join(os.path.dirname(__file__), '..', 'Resolve'))})
import resolve_bridge
resolve_bridge.MODES['synthetic'] = lambda request: (_ for _ in ()).throw(RuntimeError('must not run'))
resolve_bridge._install_signal_handlers()
time.sleep(0.05)
os.kill(os.getpid(), signal.SIGTERM)
os.kill(os.getpid(), signal.SIGTERM)
sys.exit(resolve_bridge.main(['resolve_bridge.py', 'synthetic']))
"""
        code, stdout, stderr = _run_signal_child(source)
        lines = [json.loads(line) for line in stdout.splitlines() if line]
        self.assertEqual(code, 3)
        self.assertEqual(len(lines), 1)
        self.assertEqual(lines[0]["error"]["code"], "shutdown-requested")
        self.assertEqual(stderr, "")


class TestDeferredSigint(unittest.TestCase):
    """SIGINT uses the same deferred shutdown path as SIGTERM."""

    def test_sigint_before_dispatch_uses_controlled_error(self):
        source = f"""
import os, sys
sys.path.insert(0, {repr(os.path.join(os.path.dirname(__file__), '..', 'Resolve'))})
import resolve_bridge
resolve_bridge.MODES['synthetic'] = lambda request: (_ for _ in ()).throw(RuntimeError('must not run'))
resolve_bridge._install_signal_handlers()
os.kill(os.getpid(), __import__('signal').SIGINT)
sys.exit(resolve_bridge.main(['resolve_bridge.py', 'synthetic']))
"""
        code, stdout, stderr = _run_signal_child(source)
        lines = [json.loads(line) for line in stdout.splitlines() if line]
        self.assertEqual(code, 3)
        self.assertEqual(len(lines), 1)
        self.assertFalse(lines[0]["ok"])
        self.assertEqual(lines[0]["error"]["code"], "shutdown-requested")
        self.assertEqual(stderr, "")

    def test_sigint_while_waiting_for_open_stdin_exits_promptly(self):
        source = f"""
import sys
sys.path.insert(0, {repr(os.path.join(os.path.dirname(__file__), '..', 'Resolve'))})
import resolve_bridge
resolve_bridge.MODES['synthetic'] = lambda request: (_ for _ in ()).throw(RuntimeError('must not run'))
sys.exit(resolve_bridge.main(['resolve_bridge.py', 'synthetic']))
"""
        started = time.monotonic()
        code, stdout, stderr = _run_signal_child_with_open_stdin(
            source, signum=signal.SIGINT)
        elapsed = time.monotonic() - started
        lines = [json.loads(line) for line in stdout.splitlines() if line]
        self.assertLess(elapsed, 2)
        self.assertEqual(code, 3)
        self.assertEqual(len(lines), 1)
        self.assertFalse(lines[0]["ok"])
        self.assertEqual(lines[0]["error"]["code"], "shutdown-requested")
        self.assertEqual(stderr, "")

    def test_sigint_during_work_is_deferred(self):
        source = f"""
import os, sys, time, signal
sys.path.insert(0, {repr(os.path.join(os.path.dirname(__file__), '..', 'Resolve'))})
import resolve_bridge
def work(request):
    os.kill(os.getpid(), signal.SIGINT)
    time.sleep(0.4)
    return {{'completed': True}}
resolve_bridge.MODES['synthetic'] = work
sys.exit(resolve_bridge.main(['resolve_bridge.py', 'synthetic']))
"""
        code, stdout, stderr = _run_signal_child(source)
        lines = [json.loads(line) for line in stdout.splitlines() if line]
        self.assertEqual(code, 0)
        self.assertEqual(len(lines), 1)
        self.assertTrue(lines[0]["ok"])
        self.assertEqual(lines[0]["data"], {"completed": True})
        self.assertEqual(stderr, "")

    def test_repeated_sigint_remains_single_response(self):
        source = f"""
import os, sys, time, signal
sys.path.insert(0, {repr(os.path.join(os.path.dirname(__file__), '..', 'Resolve'))})
import resolve_bridge
resolve_bridge.MODES['synthetic'] = lambda request: (_ for _ in ()).throw(RuntimeError('must not run'))
resolve_bridge._install_signal_handlers()
time.sleep(0.05)
os.kill(os.getpid(), signal.SIGINT)
os.kill(os.getpid(), signal.SIGINT)
sys.exit(resolve_bridge.main(['resolve_bridge.py', 'synthetic']))
"""
        code, stdout, stderr = _run_signal_child(source)
        lines = [json.loads(line) for line in stdout.splitlines() if line]
        self.assertEqual(code, 3)
        self.assertEqual(len(lines), 1)
        self.assertEqual(lines[0]["error"]["code"], "shutdown-requested")
        self.assertEqual(stderr, "")


class TestMainProtocol(unittest.TestCase):
    def _main(self, argv, request=None):
        with patch.object(resolve_bridge, "_install_signal_handlers"), \
             patch.object(resolve_bridge, "read_request", return_value=request or {}):
            with patch("sys.stdout") as stdout:
                stdout.write.side_effect = lambda text: self._output.append(text)
                stdout.flush.side_effect = lambda: None
                self._output = []
                rc = resolve_bridge.main(argv)
        payload = json.loads("".join(self._output))
        return rc, payload

    def test_missing_mode_is_usage_error(self):
        rc, payload = self._main(["resolve_bridge.py"])
        self.assertEqual(rc, 2)
        self.assertEqual(payload["event"], "result")
        self.assertFalse(payload["ok"])
        self.assertIsNone(payload["mode"])
        self.assertEqual(payload["error"]["code"], "usage")

    def test_unknown_mode_is_usage_error(self):
        rc, payload = self._main(["resolve_bridge.py", "no-such-mode"])
        self.assertEqual(rc, 2)
        self.assertEqual(payload["event"], "result")
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["mode"], "no-such-mode")
        self.assertEqual(payload["error"]["code"], "unknown-mode")

    def test_read_side_bridge_failure_preserves_code(self):
        failure = resolve_bridge.BridgeFailure("request-bad", "bad request")
        with patch.object(resolve_bridge, "_install_signal_handlers"), \
             patch.object(resolve_bridge, "read_request", side_effect=failure), \
             patch("sys.stdout") as stdout:
            output = []
            stdout.write.side_effect = output.append
            stdout.flush.side_effect = lambda: None
            rc = resolve_bridge.main(["resolve_bridge.py", "info"])
        payload = json.loads("".join(output))
        self.assertEqual(rc, 3)
        self.assertEqual(payload["event"], "result")
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["mode"], "info")
        self.assertEqual(payload["error"]["code"], "request-bad")

    def test_handler_success_result_shape(self):
        with patch.dict(resolve_bridge.MODES, {"synthetic": lambda request: {"value": 7}}), \
             patch.object(resolve_bridge, "_install_signal_handlers"), \
             patch.object(resolve_bridge, "read_request", return_value={}), \
             patch("sys.stdout") as stdout:
            output = []
            stdout.write.side_effect = output.append
            stdout.flush.side_effect = lambda: None
            rc = resolve_bridge.main(["resolve_bridge.py", "synthetic"])
        payload = json.loads("".join(output))
        self.assertEqual(rc, 0)
        self.assertEqual(payload, {"event": "result", "ok": True, "mode": "synthetic", "data": {"value": 7}})

    def test_operation_id_is_echoed_on_protocol_events(self):
        with patch.dict(resolve_bridge.MODES, {"synthetic": lambda request: {"value": 7}}):
            rc, payload = self._main(
                ["resolve_bridge.py", "synthetic"],
                {"operationId": "op-123"},
            )
        self.assertEqual(rc, 0)
        self.assertEqual(payload["operationId"], "op-123")

    def test_handler_bridge_failure_result_shape(self):
        failure = resolve_bridge.BridgeFailure("expected-failure", "nope")
        with patch.dict(resolve_bridge.MODES, {"synthetic": lambda request: (_ for _ in ()).throw(failure)}), \
             patch.object(resolve_bridge, "_install_signal_handlers"), \
             patch.object(resolve_bridge, "read_request", return_value={}), \
             patch("sys.stdout") as stdout:
            output = []
            stdout.write.side_effect = output.append
            stdout.flush.side_effect = lambda: None
            rc = resolve_bridge.main(["resolve_bridge.py", "synthetic"])
        payload = json.loads("".join(output))
        self.assertEqual(rc, 3)
        self.assertEqual(payload["event"], "result")
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["error"]["code"], "expected-failure")

    def test_handler_exception_is_internal_error(self):
        with patch.dict(resolve_bridge.MODES, {"synthetic": lambda request: 1 / 0}), \
             patch.object(resolve_bridge, "_install_signal_handlers"), \
             patch.object(resolve_bridge, "read_request", return_value={}), \
             patch("sys.stdout") as stdout:
            output = []
            stdout.write.side_effect = output.append
            stdout.flush.side_effect = lambda: None
            rc = resolve_bridge.main(["resolve_bridge.py", "synthetic"])
        payload = json.loads("".join(output))
        self.assertEqual(rc, 4)
        self.assertEqual(payload["event"], "result")
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["error"]["code"], "internal-error")


class TestInfoAndWordTiming(unittest.TestCase):
    @patch("resolve_bridge._sweep_stale_scratches_before")
    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge.load_resolve")
    def test_info_reports_version_token_and_resolution(self, load, identity, sweep):
        resolve, project, timeline = _make_mock_resolve()
        timeline.GetSetting.side_effect = lambda key: {
            "timelineResolutionWidth": "1080",
            "timelineResolutionHeight": "1920",
        }[key]
        load.return_value = resolve
        identity.return_value = ({"compositeToken": "token-1"}, 24.0, 0)
        result = resolve_bridge.mode_info({})
        self.assertEqual(result, {
            "resolveVersion": "20.0",
            "token": {"compositeToken": "token-1"},
            "timelineWidth": 1080,
            "timelineHeight": 1920,
        })

    @patch("resolve_bridge._auto_caption_settings")
    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge.load_resolve")
    def test_extract_word_timing_success_cleans_up_scratch_track(self, load, identity, settings):
        resolve, project, timeline = _make_mock_resolve()
        track_created = {"value": False}
        generated = {"value": False}
        timeline.GetTrackCount.side_effect = lambda kind: 1 if track_created["value"] else 0
        timeline.GetStartFrame.return_value = 100
        timeline.GetSetting.side_effect = lambda key: 24.0 if key == "timelineFrameRate" else None
        item_one = MagicMock()
        item_one.GetName.return_value, item_one.GetStart.return_value, item_one.GetEnd.return_value = "hello world", 100, 124
        item_two = MagicMock()
        item_two.GetName.return_value, item_two.GetStart.return_value, item_two.GetEnd.return_value = "bye", 130, 142
        timeline.GetItemListInTrack.side_effect = lambda kind, index: [item_one, item_two] if generated["value"] else []
        timeline.AddTrack.side_effect = lambda kind: track_created.update(value=True) or True
        timeline.CreateSubtitlesFromAudio.side_effect = lambda actual: generated.update(value=True) or True
        load.return_value = resolve
        identity.return_value = ({"compositeToken": "token-1"}, 24.0, 100)
        settings.return_value = {"language": "en", "chars": 1}

        result = resolve_bridge.mode_extract_word_timing({"expectedToken": "token-1"})

        self.assertEqual(result["fps"], 24.0)
        self.assertEqual(result["timelineStartFrame"], 100)
        self.assertEqual(result["words"], [
            {"text": "hello", "startFrame": 100, "endFrame": 113, "startSeconds": 0.0, "endSeconds": 0.541667},
            {"text": "world", "startFrame": 113, "endFrame": 124, "startSeconds": 0.541667, "endSeconds": 1.0},
            {"text": "bye", "startFrame": 130, "endFrame": 142, "startSeconds": 1.25, "endSeconds": 1.75},
        ])
        self.assertEqual(result["stats"], {"rawChunkCount": 2, "multiWordChunks": 1, "wordCount": 3})
        timeline.DeleteTrack.assert_called_once_with("subtitle", 1)

    @patch("resolve_bridge._auto_caption_settings")
    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge.load_resolve")
    def test_extract_word_timing_failure_cleans_up_scratch_track(
            self, load, identity, settings):
        resolve, project, timeline = _make_mock_resolve()
        track_created = {"value": False}
        timeline.GetTrackCount.side_effect = lambda kind: 1 if track_created["value"] else 0
        timeline.AddTrack.side_effect = lambda kind: track_created.update(value=True) or True
        timeline.CreateSubtitlesFromAudio.return_value = False
        load.return_value = resolve
        identity.return_value = ({"compositeToken": "token-1"}, 24.0, 100)
        settings.return_value = {"language": "en", "chars": 1}

        with self.assertRaises(resolve_bridge.BridgeFailure) as context:
            resolve_bridge.mode_extract_word_timing({"expectedToken": "token-1"})

        self.assertEqual(context.exception.code, "auto-caption-rejected")
        timeline.DeleteTrack.assert_called_once_with("subtitle", 1)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_request(token=None):
    payload = {}
    if token is not None:
        payload["expectedToken"] = token
    return json.dumps(payload)


def _make_mock_resolve():
    """Return a mock resolve object with a functional project/timeline chain."""
    resolve = MagicMock()
    resolve.GetVersionString.return_value = "20.0"

    pm = MagicMock()
    resolve.GetProjectManager.return_value = pm

    project = MagicMock()
    project.GetName.return_value = "TestProject"
    pm.GetCurrentProject.return_value = project

    timeline = MagicMock()
    timeline.GetName.return_value = "Timeline 1"
    timeline.GetTrackCount.return_value = 1
    timeline.GetItemListInTrack.return_value = [MagicMock()]
    timeline.GetSetting.return_value = 24.0
    timeline.GetStartFrame.return_value = 0
    timeline.GetCurrentTimeline.return_value = timeline
    project.GetCurrentTimeline.return_value = timeline

    # Token identity pieces
    timeline.GetUniqueId.return_value = 42
    timeline.CreateSubtitlesFromAudio.return_value = False

    return resolve, project, timeline


# ---------------------------------------------------------------------------
# verify_token (raising 3-arg form) tests
# ---------------------------------------------------------------------------

class TestVerifyToken(unittest.TestCase):
    """The single raising form of verify_token(request, project, timeline):
    missing expectedToken -> token-missing, stale token -> token-mismatch,
    matching token passes silently. The legacy bool-returning single-arg
    form was removed (REVIEW-CLEANUP S3) — every mutating mode goes through
    this form after open_project_timeline().
    """

    def _token_request(self, token):
        return {"expectedToken": token}

    @patch("resolve_bridge._timeline_identity")
    def test_missing_expected_token_raises(self, mock_identity):
        mock_identity.return_value = (
            {"compositeToken": "real-token"}, 24.0, 0)
        _, project, timeline = _make_mock_resolve()

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge.verify_token({}, project, timeline)
        self.assertEqual(ctx.exception.code, "token-missing")

    @patch("resolve_bridge._timeline_identity")
    def test_stale_token_raises_token_mismatch(self, mock_identity):
        mock_identity.return_value = (
            {"compositeToken": "real-token"}, 24.0, 0)
        _, project, timeline = _make_mock_resolve()

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge.verify_token(
                self._token_request("stale-token"), project, timeline)
        self.assertEqual(ctx.exception.code, "token-mismatch")

    @patch("resolve_bridge._timeline_identity")
    def test_matching_token_passes_silently(self, mock_identity):
        mock_identity.return_value = (
            {"compositeToken": "real-token"}, 24.0, 0)
        _, project, timeline = _make_mock_resolve()

        # Must not raise.
        resolve_bridge.verify_token(
            self._token_request("real-token"), project, timeline)


class TestSubtitleLayout(unittest.TestCase):
    def test_infer_subtitle_layout_from_single_line_cues(self):
        layout = resolve_bridge._infer_subtitle_layout([
            {"text": "grace is not earned"},
            {"text": "jesus saves"},
        ])
        self.assertEqual(layout, {
            "charactersPerLine": 19,
            "lineBreakMode": "single",
        })

    def test_infer_subtitle_layout_from_two_line_cues(self):
        layout = resolve_bridge._infer_subtitle_layout([
            {"text": "If you've ever tried\u2028shopping for a"},
        ])
        self.assertEqual(layout, {
            "charactersPerLine": 20,
            "lineBreakMode": "double",
        })


class TestGenerateSubtitles(unittest.TestCase):
    def _run(self, request_json=None):
        req = request_json or "{}"
        try:
            return resolve_bridge.mode_generate_subtitles(req)
        except resolve_bridge.BridgeFailure as exc:
            return {"error": {"code": exc.code, "message": exc.message}}

    @patch("resolve_bridge._auto_caption_settings")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    @patch("resolve_bridge._timeline_identity")
    def test_returns_inferred_two_line_layout(self, mock_identity, mock_open, mock_load, mock_settings):
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_settings.return_value = {"chars": 42}
        mock_identity.return_value = (
            {"projectName": "TestProject", "timelineName": "Timeline 1", "timelineId": 42,
             "startFrame": 0, "fps": 24.0, "itemCount": 1, "compositeToken": "tok"},
            24.0,
            0,
        )

        timeline.GetTrackCount.return_value = 1
        item = MagicMock()
        item.GetStart.return_value = 10
        item.GetEnd.return_value = 20
        item.GetName.return_value = "If you've ever tried\u2028shopping for a"
        generated = {"value": False}

        def create_subtitles(settings):
            generated["value"] = True
            return True

        timeline.CreateSubtitlesFromAudio.side_effect = create_subtitles
        timeline.GetItemListInTrack.side_effect = lambda kind, idx: [item] if generated["value"] and idx == 1 else []
        timeline.GetTrackName.return_value = "Captions"

        result = self._run({"expectedToken": "tok"})

        self.assertEqual(result.get("cueCount"), 1)
        track = result["tracks"][0]
        self.assertEqual(track["subtitleLayout"], {
            "charactersPerLine": 20,
            "lineBreakMode": "double",
        })
        self.assertEqual(track["cues"][0]["text"], "If you've ever tried\u2028shopping for a")


# ---------------------------------------------------------------------------
# capture-style tests
# ---------------------------------------------------------------------------

class TestCaptureStyle(unittest.TestCase):
    """Validate the capture-style mode response shape and error paths."""

    def _run(self, request_json=None):
        """Invoke capture_style with optional request JSON, returning the
        handler's return value (a dict).  If the handler raises BridgeFailure
        we catch it and return its to_dict()-compatible dict."""
        req = request_json or "{}"
        try:
            return resolve_bridge.capture_style(req)
        except resolve_bridge.BridgeFailure as exc:
            return {"error": {"code": exc.code, "message": exc.message}}

    def _scratch_fixture(self, project, timeline, comp, textplus=None,
                         title_item=None):
        """Model the current contract: capture operates on a scratch timeline."""
        scratch = MagicMock()
        scratch.GetName.return_value = resolve_bridge.CAPTURE_STYLE_TIMELINE_NAME
        title_item = title_item or MagicMock()
        title_item.GetName.return_value = resolve_bridge.CAPTURE_STYLE_CLIP_NAME
        title_item.GetFusionCompByIndex.return_value = comp
        scratch.GetTrackCount.return_value = 1
        scratch.GetItemListInTrack.return_value = [title_item]
        if textplus is not None:
            comp.GetToolList.return_value = {1: textplus}
        project.GetTimelineCount.return_value = 2
        project.GetTimelineByIndex.side_effect = lambda i: (timeline, scratch)[i - 1]
        project.GetCurrentTimeline.return_value = timeline
        project.GetMediaPool.return_value.DeleteTimelines.return_value = True
        project.GetMediaPool.return_value.CreateEmptyTimeline.return_value = scratch
        project.SetCurrentTimeline.return_value = True
        return scratch, title_item

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_success_response_shape(self, mock_open, mock_load):
        """Insert creates a disposable scratch timeline and reports ready."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)

        # Mock _timeline_identity so the token matches what we pass
        expected_token = "fake-composite-token"
        mock_identity = {
            "projectName": "TestProject",
            "timelineName": "Timeline 1",
            "timelineId": 42,
            "startFrame": 0,
            "fps": 24.0,
            "itemCount": 1,
            "compositeToken": expected_token,
        }
        with patch.object(resolve_bridge, "_timeline_identity", return_value=(mock_identity, 24.0, 0)):
            comp = MagicMock()
            inserted_tool = MagicMock()
            inserted_tool.ID = "TextPlus"
            comp.GetToolList.return_value = {1: inserted_tool}
            comp.AddTool.return_value = inserted_tool
            title_item = MagicMock()
            title_item.GetFusionCompByIndex.return_value = comp
            scratch, _ = self._scratch_fixture(project, timeline, comp,
                                                inserted_tool, title_item)
            scratch.InsertFusionTitleIntoTimeline.return_value = title_item

            result = self._run(_make_request(expected_token))

        self.assertEqual(result.get("status"), "ready")
        self.assertEqual(result["phase"], "insert")
        self.assertEqual(result["message"].startswith("Resolve is now on"), True)

    @patch("resolve_bridge.load_resolve")
    def test_no_project(self, mock_load):
        """When GetCurrentProject returns None, we get a structured error."""
        resolve = MagicMock()
        resolve.GetVersionString.return_value = "20.0"
        resolve.GetProjectManager.return_value = None
        mock_load.return_value = resolve

        result = self._run(_make_request("fake-composite-token"))
        self.assertIn("error", result)
        self.assertEqual(result["error"]["code"], "no-project-open")

    @patch("resolve_bridge.load_resolve")
    def test_no_timeline(self, mock_load):
        """When GetCurrentTimeline returns None, we get a structured error."""
        resolve, project, timeline = _make_mock_resolve()
        resolve.GetProjectManager.return_value.GetCurrentProject.return_value = project
        project.GetCurrentTimeline.return_value = None
        mock_load.return_value = resolve

        result = self._run(_make_request("fake-composite-token"))
        self.assertIn("error", result)
        self.assertEqual(result["error"]["code"], "no-timeline-open")

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_missing_token(self, mock_open, mock_load):
        """Without expectedToken, we get a structured error."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)

        result = self._run("{}")
        self.assertIn("error", result)
        self.assertEqual(result["error"]["code"], "token-missing")

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_token_mismatch(self, mock_open, mock_load):
        """With a wrong expectedToken, we get a structured error."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)

        expected_token = "real-composite-token"
        mock_identity = {
            "projectName": "TestProject",
            "timelineName": "Timeline 1",
            "timelineId": 42,
            "startFrame": 0,
            "fps": 24.0,
            "itemCount": 1,
            "compositeToken": expected_token,
        }
        with patch.object(resolve_bridge, "_timeline_identity", return_value=(mock_identity, 24.0, 0)):
            result = self._run(_make_request("wrong-token"))

        self.assertIn("error", result)
        self.assertEqual(result["error"]["code"], "token-mismatch")

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_no_comp(self, mock_open, mock_load):
        """An inserted scratch clip without a reachable comp fails safely."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        scratch = MagicMock()
        scratch.GetName.return_value = resolve_bridge.CAPTURE_STYLE_TIMELINE_NAME
        title_item = MagicMock()
        title_item.GetFusionCompByIndex.return_value = None
        scratch.InsertFusionTitleIntoTimeline.return_value = title_item
        scratch.GetTrackCount.return_value = 1
        project.GetMediaPool.return_value.CreateEmptyTimeline.return_value = scratch
        project.GetCurrentTimeline.return_value = timeline
        project.SetCurrentTimeline.return_value = True

        expected_token = "real-composite-token"
        mock_identity = {
            "projectName": "TestProject",
            "timelineName": "Timeline 1",
            "timelineId": 42,
            "startFrame": 0,
            "fps": 24.0,
            "itemCount": 1,
            "compositeToken": expected_token,
        }
        with patch.object(resolve_bridge, "_timeline_identity", return_value=(mock_identity, 24.0, 0)):
            result = self._run(_make_request(expected_token))

        self.assertIn("error", result)
        self.assertEqual(result["error"]["code"], "no-comp")


# ---------------------------------------------------------------------------
# capture-style phase 2 (capture) tests
# ---------------------------------------------------------------------------


class TestCaptureStylePhase2(unittest.TestCase):
    """Validate the capture-style phase 2 (capture) behavior."""

    def _run(self, request_json=None):
        req = request_json or "{}"
        # Phase 2 re-finds the dedicated scratch timeline; it does not use
        # Fusion.CurrentComp or the diagnostic tool index/hash from phase 1.
        resolve = resolve_bridge.load_resolve.return_value
        project, target = resolve_bridge.open_project_timeline.return_value
        scratch = MagicMock()
        scratch.GetName.return_value = resolve_bridge.CAPTURE_STYLE_TIMELINE_NAME
        clip = MagicMock()
        clip.GetName.return_value = resolve_bridge.CAPTURE_STYLE_CLIP_NAME
        comp = resolve.GetFusion().CurrentComp
        clip.GetFusionCompByIndex.return_value = comp
        scratch.GetTrackCount.return_value = 1
        scratch.GetItemListInTrack.return_value = [clip]
        found = comp.FindTool.return_value
        if found is not None:
            found.ID = "TextPlus"
        else:
            comp.AddTool.return_value = None
        comp.GetToolList.return_value = ({1: found} if found is not None else {})
        project.GetTimelineCount.return_value = 2
        project.GetTimelineByIndex.side_effect = lambda i: (target, scratch)[i - 1]
        project.GetMediaPool.return_value.DeleteTimelines.return_value = True
        payload = json.loads(req)
        if payload.get("phase") == "capture" and not (
                payload.get("toolId") or payload.get("toolIndex")):
            project.GetTimelineCount.return_value = 0
        try:
            return resolve_bridge.capture_style(req)
        except resolve_bridge.BridgeFailure as exc:
            return {"error": {"code": exc.code, "message": exc.message}}

    def _make_capture_request(self, tool_id="12345", tool_index=1, token="fake-composite-token"):
        return json.dumps({
            "expectedToken": token,
            "phase": "capture",
            "toolId": tool_id,
            "toolIndex": tool_index,
        })

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_capture_returns_settings(self, mock_open, mock_load):
        """Phase 2 reads settings from the Text+ on the scratch timeline."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)

        expected_token = "fake-composite-token"
        mock_identity = {
            "projectName": "TestProject",
            "timelineName": "Timeline 1",
            "timelineId": 42,
            "startFrame": 0,
            "fps": 24.0,
            "itemCount": 1,
            "compositeToken": expected_token,
        }
        with patch.object(resolve_bridge, "_timeline_identity", return_value=(mock_identity, 24.0, 0)):
            fusion = MagicMock()
            resolve.GetFusion.return_value = fusion
            comp = MagicMock()
            fusion.CurrentComp = comp
            comp.GetName.return_value = "Comp1"

            saved_settings = resolve_bridge.OrderedDict([
                ("Font", "Arial"),
                ("Size", 72),
                ("Controls", resolve_bridge.OrderedDict([
                    ("Text", "Hello"),
                    ("Color", [1.0, 0.0, 0.0]),
                ])),
            ])

            textplus = MagicMock()
            textplus.SaveSettings.return_value = saved_settings
            comp.FindTool.return_value = textplus

            result = self._run(self._make_capture_request())

        self.assertEqual(result.get("status"), "captured")
        self.assertEqual(result.get("phase"), "capture")
        self.assertIn("styleSettings", result)
        settings = result["styleSettings"]
        self.assertEqual(settings["Font"], "Arial")
        self.assertEqual(settings["Size"], 72)
        self.assertEqual(settings["Controls"]["Text"], "Hello")
        self.assertEqual(settings["Controls"]["Color"], [1.0, 0.0, 0.0])

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_capture_removes_tool(self, mock_open, mock_load):
        """After capture, the disposable scratch timeline is torn down."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)

        expected_token = "fake-composite-token"
        mock_identity = {
            "projectName": "TestProject",
            "timelineName": "Timeline 1",
            "timelineId": 42,
            "startFrame": 0,
            "fps": 24.0,
            "itemCount": 1,
            "compositeToken": expected_token,
        }
        with patch.object(resolve_bridge, "_timeline_identity", return_value=(mock_identity, 24.0, 0)):
            fusion = MagicMock()
            resolve.GetFusion.return_value = fusion
            comp = MagicMock()
            fusion.CurrentComp = comp
            comp.GetName.return_value = "Comp1"

            textplus = MagicMock()
            textplus.SaveSettings.return_value = resolve_bridge.OrderedDict([("Font", "Arial")])
            comp.FindTool.return_value = textplus

            self._run(self._make_capture_request())

            project.GetMediaPool.return_value.DeleteTimelines.assert_called_once()

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_ordereddict_conversion(self, mock_open, mock_load):
        """Verify that nested OrderedDict values are converted to regular dicts."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)

        expected_token = "fake-composite-token"
        mock_identity = {
            "projectName": "TestProject",
            "timelineName": "Timeline 1",
            "timelineId": 42,
            "startFrame": 0,
            "fps": 24.0,
            "itemCount": 1,
            "compositeToken": expected_token,
        }
        with patch.object(resolve_bridge, "_timeline_identity", return_value=(mock_identity, 24.0, 0)):
            fusion = MagicMock()
            resolve.GetFusion.return_value = fusion
            comp = MagicMock()
            fusion.CurrentComp = comp
            comp.GetName.return_value = "Comp1"

            nested = resolve_bridge.OrderedDict([
                ("a", resolve_bridge.OrderedDict([
                    ("b", resolve_bridge.OrderedDict([("c", 1)])),
                ])),
                ("d", [resolve_bridge.OrderedDict([("e", 2)]), 3]),
            ])
            textplus = MagicMock()
            textplus.SaveSettings.return_value = nested
            comp.FindTool.return_value = textplus

            result = self._run(self._make_capture_request())
            settings = result["styleSettings"]

        # All OrderedDict should be converted to regular dicts
        self.assertIsInstance(settings, dict)
        self.assertIsInstance(settings["a"], dict)
        self.assertIsInstance(settings["a"]["b"], dict)
        self.assertIsInstance(settings["a"]["b"]["c"], int)
        self.assertIsInstance(settings["d"], list)
        self.assertIsInstance(settings["d"][0], dict)
        self.assertEqual(settings["d"][0]["e"], 2)
        self.assertEqual(settings["d"][1], 3)

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_capture_tool_not_found(self, mock_open, mock_load):
        """When the scratch clip cannot expose a Text+, we get an error."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)

        expected_token = "fake-composite-token"
        mock_identity = {
            "projectName": "TestProject",
            "timelineName": "Timeline 1",
            "timelineId": 42,
            "startFrame": 0,
            "fps": 24.0,
            "itemCount": 1,
            "compositeToken": expected_token,
        }
        with patch.object(resolve_bridge, "_timeline_identity", return_value=(mock_identity, 24.0, 0)):
            fusion = MagicMock()
            resolve.GetFusion.return_value = fusion
            comp = MagicMock()
            fusion.CurrentComp = comp
            comp.GetName.return_value = "Comp1"
            comp.FindTool.return_value = None
            # Make iteration over comp yield no matching tool
            comp.__iter__ = MagicMock(return_value=iter([]))

            result = self._run(self._make_capture_request())

        self.assertIn("error", result)
        self.assertEqual(result["error"]["code"], "textplus-create-failed")

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_capture_missing_tool_ref(self, mock_open, mock_load):
        """When the scratch clip is missing, capture fails safely."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)

        expected_token = "fake-composite-token"
        mock_identity = {
            "projectName": "TestProject",
            "timelineName": "Timeline 1",
            "timelineId": 42,
            "startFrame": 0,
            "fps": 24.0,
            "itemCount": 1,
            "compositeToken": expected_token,
        }
        with patch.object(resolve_bridge, "_timeline_identity", return_value=(mock_identity, 24.0, 0)):
            req = json.dumps({
                "expectedToken": expected_token,
                "phase": "capture",
            })
            result = self._run(req)

        self.assertIn("error", result)
        self.assertEqual(result["error"]["code"], "capture-clip-missing")

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_capture_unknown_phase(self, mock_open, mock_load):
        """An unknown phase value returns a structured error."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)

        expected_token = "fake-composite-token"
        mock_identity = {
            "projectName": "TestProject",
            "timelineName": "Timeline 1",
            "timelineId": 42,
            "startFrame": 0,
            "fps": 24.0,
            "itemCount": 1,
            "compositeToken": expected_token,
        }
        with patch.object(resolve_bridge, "_timeline_identity", return_value=(mock_identity, 24.0, 0)):
            req = json.dumps({
                "expectedToken": expected_token,
                "phase": "unknown",
            })
            result = self._run(req)

        self.assertIn("error", result)
        self.assertEqual(result["error"]["code"], "invalid-phase")

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_capture_relocates_tool_structurally(self, mock_open, mock_load):
        """Capture re-finds the sole Text+ structurally on the scratch clip."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)

        expected_token = "fake-composite-token"
        mock_identity = {
            "projectName": "TestProject",
            "timelineName": "Timeline 1",
            "timelineId": 42,
            "startFrame": 0,
            "fps": 24.0,
            "itemCount": 1,
            "compositeToken": expected_token,
        }
        with patch.object(resolve_bridge, "_timeline_identity", return_value=(mock_identity, 24.0, 0)):
            fusion = MagicMock()
            resolve.GetFusion.return_value = fusion
            comp = MagicMock()
            fusion.CurrentComp = comp
            comp.GetName.return_value = "Comp1"
            # The old tool-index/hash fallback is deliberately not involved.
            matching_tool = MagicMock()
            matching_tool.ID = "TextPlus"
            matching_tool.SaveSettings.return_value = resolve_bridge.OrderedDict([("Font", "Helvetica")])
            matching_tool.GetInput.return_value = None
            comp.FindTool.return_value = matching_tool

            req = json.dumps({
                "expectedToken": expected_token,
                "phase": "capture",
                "toolId": "diagnostic-only",
            })
            result = self._run(req)

        self.assertEqual(result.get("status"), "captured")
        self.assertEqual(result["styleSettings"]["Font"], "Helvetica")
        project.GetMediaPool.return_value.DeleteTimelines.assert_called_once()


class TestCaptureStyleDispatchPath(unittest.TestCase):
    """H1/H2 regression: capture-style must work through main()'s dispatcher
    (the path the app actually spawns) and carry toolId as a String end to
    end.

    The older capture-style tests call capture_style(req) with a JSON *string*
    directly, which structurally cannot catch H1: main() hands every handler
    the already-parsed stdin dict, and the handler used to json.loads() it
    again → TypeError → internal-error on every live invocation.
    """

    def _dispatch(self, payload, resolve):
        """Run one full `main(["capture-style"])` invocation with `payload`
        piped in as the JSON stdin body and Resolve API calls mocked out.
        Returns (exit_code, last_protocol_event_dict)."""
        import io
        from contextlib import redirect_stdout

        fake_stdin = MagicMock()
        fake_stdin.isatty.return_value = False
        fake_stdin.buffer.read.return_value = json.dumps(payload).encode("utf-8")

        stdout = io.StringIO()
        with patch.object(resolve_bridge.sys, "stdin", fake_stdin), \
                patch("resolve_bridge.load_resolve", return_value=resolve), \
                redirect_stdout(stdout):
            rc = resolve_bridge.main(["resolve_bridge.py", "capture-style"])

        events = [json.loads(line) for line in stdout.getvalue().splitlines() if line.strip()]
        self.assertTrue(events, "bridge emitted no protocol lines")
        return rc, events[-1]

    def _make_resolve(self, token="tok-dispatch"):
        """Full mocked Resolve/Fusion/comp chain for scratch capture."""
        resolve, project, timeline = _make_mock_resolve()
        mock_identity = {
            "projectName": "TestProject",
            "timelineName": "Timeline 1",
            "timelineId": 42,
            "startFrame": 0,
            "fps": 24.0,
            "itemCount": 1,
            "compositeToken": token,
        }
        fusion = MagicMock()
        resolve.GetFusion.return_value = fusion
        comp = MagicMock()
        fusion.CurrentComp = comp
        comp.GetName.return_value = "Comp1"

        textplus = MagicMock()
        textplus.ID = "TextPlus"
        textplus.SaveSettings.return_value = resolve_bridge.OrderedDict([
            ("Font", "Arial"),
            ("Size", 72),
        ])
        textplus.GetInput.return_value = None
        comp.AddTool.return_value = textplus
        comp.GetToolIndex.return_value = 0
        comp.FindTool.return_value = textplus

        scratch = MagicMock()
        scratch.GetName.return_value = resolve_bridge.CAPTURE_STYLE_TIMELINE_NAME
        title_item = MagicMock()
        title_item.GetName.return_value = resolve_bridge.CAPTURE_STYLE_CLIP_NAME
        title_item.GetFusionCompByIndex.return_value = comp
        scratch.GetTrackCount.return_value = 1
        scratch.GetItemListInTrack.return_value = [title_item]
        scratch.InsertFusionTitleIntoTimeline.return_value = title_item
        project.GetTimelineCount.return_value = 2
        project.GetTimelineByIndex.side_effect = lambda i: (timeline, scratch)[i - 1]
        project.GetCurrentTimeline.return_value = timeline
        project.GetMediaPool.return_value.CreateEmptyTimeline.return_value = scratch
        project.GetMediaPool.return_value.DeleteTimelines.return_value = True
        project.SetCurrentTimeline.return_value = True

        identity_patcher = patch.object(
            resolve_bridge,
            "_timeline_identity",
            return_value=(mock_identity, 24.0, 0),
        )
        return resolve, identity_patcher

    def test_insert_then_capture_round_trip_through_dispatcher(self):
        """The full insert→capture cycle succeeds through the dispatcher."""
        token = "tok-dispatch"
        resolve, identity_patcher = self._make_resolve(token)

        with identity_patcher:
            rc1, event1 = self._dispatch({"expectedToken": token}, resolve)
            self.assertEqual(rc1, 0)
            self.assertTrue(event1["ok"], event1)

            insert = event1["data"]
            self.assertEqual(insert["status"], "ready")

            capture_payload = {
                "expectedToken": token,
                "phase": "capture",
            }
            rc2, event2 = self._dispatch(capture_payload, resolve)

        self.assertEqual(rc2, 0)
        self.assertTrue(event2["ok"], event2)
        captured = event2["data"]
        self.assertEqual(captured["status"], "captured")
        self.assertEqual(captured["styleSettings"]["Font"], "Arial")
        self.assertEqual(captured["styleSettings"]["Size"], 72)

    def test_dict_request_does_not_crash_internal_error(self):
        """Direct H1 regression: the dispatcher's already-parsed dict reaches
        the handler without raising TypeError inside it."""
        resolve, identity_patcher = self._make_resolve()
        with identity_patcher:
            rc, event = self._dispatch({}, resolve)

        # Without the fix this dies with internal-error / exit 4 before any
        # structured error can be emitted.
        self.assertNotEqual(event.get("error", {}).get("code"), "internal-error")
        self.assertNotEqual(rc, 4)


# ---------------------------------------------------------------------------
# Mode dispatch tests
# ---------------------------------------------------------------------------

class TestModeDispatch(unittest.TestCase):
    """Verify that capture-style is wired into MODES and that the routing
    dict contains the expected keys."""

    def test_capture_style_in_modes(self):
        self.assertIn("capture-style", resolve_bridge.MODES)
        self.assertEqual(resolve_bridge.MODES["capture-style"], resolve_bridge.capture_style)


class TestRequestParsing(unittest.TestCase):
    """Direct handlers and the dispatcher share one request contract."""

    def test_accepts_already_decoded_dispatcher_request(self):
        request = {"phase": "insert"}
        self.assertIs(resolve_bridge._parse_request(request), request)

    def test_accepts_direct_json_string(self):
        self.assertEqual(
            resolve_bridge._parse_request('{"phase":"insert"}'),
            {"phase": "insert"},
        )

    def test_rejects_non_object_json(self):
        with self.assertRaises(resolve_bridge.BridgeFailure) as context:
            resolve_bridge._parse_request("[]")
        self.assertEqual(context.exception.code, "request-not-object")

    def test_preserves_mode_specific_parse_error_code(self):
        with self.assertRaises(resolve_bridge.BridgeFailure) as context:
            resolve_bridge._parse_request("{", error_code="invalid_json")
        self.assertEqual(context.exception.code, "invalid_json")

    def test_all_expected_modes_present(self):
        expected = {
            "info",
            "pull-subtitles",
            "generate-subtitles",
            "extract-word-timing",
            "capture-style",
            "author-textplus",
            "author-persistent-title",
            "export-timeline-audio",
        }
        self.assertEqual(set(resolve_bridge.MODES.keys()), expected)

    def test_author_persistent_title_in_modes(self):
        self.assertIn("author-persistent-title", resolve_bridge.MODES)
        self.assertEqual(
            resolve_bridge.MODES["author-persistent-title"],
            resolve_bridge.mode_author_persistent_title,
        )

# ---------------------------------------------------------------------------
# author-textplus tests
# ---------------------------------------------------------------------------

class TestAuthorTextplus(unittest.TestCase):
    """Validate the author-textplus mode response shape and error paths."""

    def _make_document_request(self, clips=None, token="fake-composite-token"):
        doc = {"clips": clips or [{"id": "clip1"}, {"id": "clip2"}, {"id": "clip3"}]}
        return json.dumps({
            "expectedToken": token,
            "animationDocument": json.dumps(doc),
        })

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    @patch("resolve_bridge._timeline_identity")
    def test_receives_document(self, mock_identity, mock_open, mock_load):
        """Valid document returns clipCount."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_identity.return_value = (
            {"compositeToken": "fake-composite-token"},
            24.0,
            0,
        )

        result = resolve_bridge.author_textplus(self._make_document_request())

        self.assertEqual(result.get("status"), "received")
        self.assertEqual(result["clipCount"], 3)

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    @patch("resolve_bridge._timeline_identity")
    def test_missing_token(self, mock_identity, mock_open, mock_load):
        """Without expectedToken, we get a structured error."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_identity.return_value = (
            {"compositeToken": "fake-composite-token"},
            24.0,
            0,
        )

        req = json.dumps({"animationDocument": json.dumps({"clips": []})})
        try:
            result = resolve_bridge.author_textplus(req)
        except resolve_bridge.BridgeFailure as exc:
            result = {"error": {"code": exc.code, "message": exc.message}}

        self.assertIn("error", result)
        self.assertEqual(result["error"]["code"], "missing_token")

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    @patch("resolve_bridge._timeline_identity")
    def test_token_mismatch(self, mock_identity, mock_open, mock_load):
        """With a wrong expectedToken, we get a structured error."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_identity.return_value = (
            {"compositeToken": "real-composite-token"},
            24.0,
            0,
        )

        req = json.dumps({
            "expectedToken": "wrong-token",
            "animationDocument": json.dumps({"clips": []}),
        })
        try:
            result = resolve_bridge.author_textplus(req)
        except resolve_bridge.BridgeFailure as exc:
            result = {"error": {"code": exc.code, "message": exc.message}}

        self.assertIn("error", result)
        self.assertEqual(result["error"]["code"], "token-mismatch")

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    @patch("resolve_bridge._timeline_identity")
    def test_missing_document(self, mock_identity, mock_open, mock_load):
        """Without animationDocument, we get a structured error."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_identity.return_value = (
            {"compositeToken": "fake-composite-token"},
            24.0,
            0,
        )

        req = json.dumps({"expectedToken": "fake-composite-token"})
        try:
            result = resolve_bridge.author_textplus(req)
        except resolve_bridge.BridgeFailure as exc:
            result = {"error": {"code": exc.code, "message": exc.message}}

        self.assertIn("error", result)
        self.assertEqual(result["error"]["code"], "missing_document")

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    @patch("resolve_bridge._timeline_identity")
    def test_invalid_document_json(self, mock_identity, mock_open, mock_load):
        """When animationDocument is not valid JSON, we get a structured error."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_identity.return_value = (
            {"compositeToken": "fake-composite-token"},
            24.0,
            0,
        )

        req = json.dumps({
            "expectedToken": "fake-composite-token",
            "animationDocument": "not valid json",
        })
        try:
            result = resolve_bridge.author_textplus(req)
        except resolve_bridge.BridgeFailure as exc:
            result = {"error": {"code": exc.code, "message": exc.message}}

        self.assertIn("error", result)
        self.assertEqual(result["error"]["code"], "invalid_document")

    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    @patch("resolve_bridge._timeline_identity")
    def test_ndjson_progress(self, mock_identity, mock_open, mock_load):
        """Progress lines are emitted during execution."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_identity.return_value = (
            {"compositeToken": "fake-composite-token"},
            24.0,
            0,
        )

        import io
        from contextlib import redirect_stdout

        f = io.StringIO()
        with redirect_stdout(f):
            result = resolve_bridge.author_textplus(self._make_document_request())

        output = f.getvalue()
        lines = [json.loads(line) for line in output.strip().split("\n") if line.strip()]

        progress_lines = [l for l in lines if l.get("event") == "progress"]
        self.assertTrue(len(progress_lines) >= 2)
        self.assertEqual(progress_lines[0]["step"], "receiving")
        self.assertEqual(progress_lines[0]["pct"], 0.0)
        self.assertEqual(progress_lines[-1]["step"], "done")
        self.assertEqual(progress_lines[-1]["pct"], 1.0)


if __name__ == "__main__":
    unittest.main()

# ---------------------------------------------------------------------------
# Multi-Clip per-line authoring tests
# ---------------------------------------------------------------------------

import io
from contextlib import redirect_stdout


class TestStripSplineModifiers(unittest.TestCase):
    """_strip_spline_modifiers must remove connected modifiers and tolerate
    missing/static inputs (invariant: strip before spline attach)."""

    def test_missing_inputs_graceful(self):
        """A tool exposing neither Start nor End must not raise."""

        class _Bare:
            pass

        resolve_bridge._strip_spline_modifiers(_Bare(), ("Start", "End"))

    def test_connected_modifier_deleted(self):
        tool = MagicMock()
        source_tool = MagicMock()
        modifier = MagicMock()
        modifier.GetConnectedOutput.return_value.GetTool.return_value = source_tool
        tool.End = modifier

        resolve_bridge._strip_spline_modifiers(tool, ("Start", "End"))
        source_tool.Delete.assert_called_once()

    def test_static_value_left_alone(self):
        tool = MagicMock()
        modifier = MagicMock()
        modifier.GetConnectedOutput.side_effect = AttributeError("static")
        tool.End = modifier

        resolve_bridge._strip_spline_modifiers(tool, ("End",))
        modifier.Delete.assert_not_called()


class TestAttachSteppedSpline(unittest.TestCase):
    """_attach_stepped_spline builds the right table and attaches it."""

    ENTRIES = [
        {"frame": 0, "value": 0.5},
        {"frame": 6, "value": 1.0},
    ]

    def _attach(self, **kwargs):
        comp = MagicMock()
        tool = MagicMock()
        spline = resolve_bridge._attach_stepped_spline(
            comp, tool, "End", self.ENTRIES, **kwargs)
        return comp, tool, spline

    def test_creates_modifier_and_attaches(self):
        comp, tool, spline = self._attach()
        # Proven construction: comp.BezierSpline({}) modifier constructor,
        # attached via attribute assignment — NOT AddTool (which registers
        # a comp tool whose evaluation ignores StepIn/StepOut flags) and
        # NOT SetInput (fail-quiet no-op with a modifier object).
        comp.BezierSpline.assert_called_once_with({})
        self.assertIs(getattr(tool, "End"), spline)

    def test_table_values_and_trailing_pin(self):
        _, _, spline = self._attach(clip_length_frames=24)
        table = spline.SetKeyFrames.call_args[0][0]
        self.assertEqual(set(table.keys()), {0.0, 6.0, 23.0})
        self.assertEqual(table[0.0][1], 0.5)
        self.assertEqual(table[6.0][1], 1.0)
        # Invariant: trailing pin to 1.0 at the clip's last VISIBLE frame
        # (comp-local frames run 0..clip_length-1).
        self.assertEqual(table[23.0][1], 1.0)

    def test_entries_at_or_beyond_clip_length_clamped(self):
        """Any entry keyed at/after clip_length_frames never displays —
        clamp it (and the pin) to the last visible frame so completion is
        always reachable on screen."""
        entries = [
            {"frame": 0, "value": 0.25},
            {"frame": 24, "value": 0.75},
            {"frame": 40, "value": 0.9},
        ]
        comp, tool = MagicMock(), MagicMock()
        resolve_bridge._attach_stepped_spline(
            comp, tool, "End", entries, clip_length_frames=24)
        table = comp.BezierSpline.return_value.SetKeyFrames.call_args[0][0]
        self.assertEqual(set(table.keys()), {0.0, 23.0})
        # The out-of-range entry was clamped onto the last visible frame;
        # the pin intentionally overrides whatever landed there.
        self.assertEqual(table[23.0][1], 1.0)

    def test_clamp_keeps_last_in_range_entry_value(self):
        entries = [
            {"frame": 0, "value": 0.5},
            {"frame": 10, "value": 1.0},
        ]
        comp, tool = MagicMock(), MagicMock()
        resolve_bridge._attach_stepped_spline(
            comp, tool, "End", entries, clip_length_frames=10,
            trailing_pin_value=0.0)
        table = comp.BezierSpline.return_value.SetKeyFrames.call_args[0][0]
        # Entry AT clip_length clamps to 9, then the pin overrides it;
        # the in-range entry at 0 survives untouched.
        self.assertEqual(set(table.keys()), {0.0, 9.0})
        self.assertEqual(table[0.0][1], 0.5)
        self.assertEqual(table[9.0][1], 0.0)

    def test_stepped_flags(self):
        _, _, spline = self._attach()
        table = spline.SetKeyFrames.call_args[0][0]
        for row in table.values():
            self.assertEqual(row["Flags"], {"StepIn": True, "StepOut": True})

    def test_non_stepped_has_no_flags(self):
        comp, tool = MagicMock(), MagicMock()
        resolve_bridge._attach_stepped_spline(
            comp, tool, "End", self.ENTRIES, stepped=False)
        table = (comp.BezierSpline.return_value.SetKeyFrames
                 .call_args[0][0])
        for row in table.values():
            self.assertNotIn("Flags", row)

    def test_no_pin_without_clip_length(self):
        _, _, spline = self._attach()
        table = spline.SetKeyFrames.call_args[0][0]
        self.assertEqual(set(table.keys()), {0.0, 6.0})

    def test_empty_entries_raises_structured(self):
        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._attach_stepped_spline(
                MagicMock(), MagicMock(), "End", [])
        self.assertEqual(ctx.exception.code, "missing-keyframes")


class TestLeadStartEntries(unittest.TestCase):
    """Overlay Start entries key on the SAME frames as their End
    counterparts but lead by half a char-cell in VALUE: Text+ highlights
    a character only when char_start > Start (strict), so an exact
    word-start fraction always drops the leading glyph as a white
    fragment (live-verified: a static Start reproduces the chop
    pixel-identically). Start must NOT be keyed a frame early — that
    leaves one empty-window (white) frame at every word transition."""

    def test_each_entry_keeps_frame_and_leads_half_cell(self):
        text = "abcdefghij"  # 10 chars -> half cell = 0.05
        entries = [
            {"frame": 0, "value": 0.0},
            {"frame": 18, "value": 0.28},
            {"frame": 36, "value": 0.61},
        ]
        led = resolve_bridge._lead_start_entries(entries, text)
        self.assertEqual(
            [(e["frame"], round(e["value"], 6)) for e in led],
            [(0, 0.0), (18, 0.23), (36, 0.56)])

    def test_first_onset_clamps_at_zero(self):
        led = resolve_bridge._lead_start_entries(
            [{"frame": 1, "value": 0.5}, {"frame": 0, "value": 0.25}],
            "abcdef")
        self.assertEqual([e["frame"] for e in led], [1, 0])
        self.assertAlmostEqual(led[0]["value"], 0.5 - 0.5 / 6)
        self.assertAlmostEqual(led[1]["value"], 0.25 - 0.5 / 6)

    def test_tiny_value_clamps_at_zero(self):
        led = resolve_bridge._lead_start_entries(
            [{"frame": 4, "value": 0.03}], "abcdefghij")
        self.assertEqual(led[0]["value"], 0.0)

    def test_empty_text_still_leads(self):
        led = resolve_bridge._lead_start_entries(
            [{"frame": 9, "value": 0.5}], "")
        self.assertEqual(led[0]["frame"], 9)
        self.assertEqual(led[0]["value"], 0.0)

    def test_empty_entries_pass_through(self):
        self.assertEqual(resolve_bridge._lead_start_entries([], "abc"), [])


class TestMirrorLayoutInputs(unittest.TestCase):
    """_mirror_layout_inputs copies every layout-determining input from the
    base Text+ onto the highlight overlay so both layers render their line
    at identical position and scale (zero-movement invariant)."""

    def test_copies_values_and_converts_point_tables(self):
        src, dst = MagicMock(), MagicMock()

        def get_input(name):
            if name == "Center":
                # Point inputs read back as {1: x, 2: y, 3: z} tables;
                # SetInput wants a plain (x, y) tuple.
                return {1: 0.35, 2: 0.65, 3: 0.0}
            if name == "Size":
                return 0.09
            return 1.0

        src.GetInput.side_effect = get_input
        resolve_bridge._mirror_layout_inputs(src, dst)

        dst.SetInput.assert_any_call("Center", (0.35, 0.65))
        dst.SetInput.assert_any_call("Size", 0.09)
        # No mirrored input ever receives None.
        for c in dst.SetInput.call_args_list:
            self.assertIsNotNone(c.args[1])

    def test_skips_failing_or_missing_reads(self):
        src, dst = MagicMock(), MagicMock()
        values = {"Size": 0.08}

        def get_input(name):
            if name == "Boom":
                raise RuntimeError("fail-quiet surface raised")
            return values.get(name)

        src.GetInput.side_effect = get_input
        resolve_bridge._mirror_layout_inputs(src, dst)

        dst.SetInput.assert_called_once_with("Size", 0.08)

    def test_setinput_failures_are_tolerated(self):
        src, dst = MagicMock(), MagicMock()
        src.GetInput.return_value = 1.0
        dst.SetInput.side_effect = RuntimeError("fail-quiet write")
        resolve_bridge._mirror_layout_inputs(src, dst)  # must not raise

    def test_mirror_set_covers_geometry_determining_inputs(self):
        expected = {
            "Center", "Pivot",
            "HorizontalLeftCenterRight", "VerticalTopCenterBottom",
            "CenterOnBaseOfFirstLine",
            "LayoutType", "LayoutSize", "LayoutWidth", "LayoutHeight",
            "Width", "Height",
            "Font", "Style", "Size",
            "CharacterSpacing", "WordSpacing", "LineSpacing",
        }
        self.assertTrue(expected.issubset(
            set(resolve_bridge._LAYOUT_MIRROR_INPUTS)))


class TestAuthorClipOnTrack(unittest.TestCase):
    """One AnimatedClip -> authored TextPlus -> baked Fusion clip with an
    ownership-marker name, all mutations inside one undo bracket."""

    def _make_clip_doc(self, **overrides):
        doc = {
            "startFrame": 100,
            "endFrame": 124,
            "text": "hello world",
            "keyframes": {
                "End": {
                    "entries": [{"frame": 0, "value": 0.5},
                                {"frame": 6, "value": 1.0}],
                    "isStepped": True,
                },
            },
            "overlayKeyframes": None,
        }
        doc.update(overrides)
        return doc

    def _run_author(self, clip_doc, line_number=1):
        mgr = MagicMock()
        comp, tool, spline = mgr.comp, mgr.tool, mgr.spline
        tool.ID = "TextPlus"
        mgr.media_out.ID = "MediaOut"
        # Snapshot MediaOut's Input so tests can prove whether it was
        # rewired (attribute assignment, not SetInput).
        mgr.media_out_input_before = mgr.media_out.Input
        comp.GetToolList.return_value = {1: tool, 2: mgr.media_out}
        comp.AddTool.side_effect = lambda name, *a, **k: (
            mgr.merge if name == "Merge" else mgr.overlay_tool)
        # Splines come from the modifier constructor now (proven pattern);
        # each attach gets a distinct mock so tables can be asserted
        # per-curve.
        mgr.splines = []

        def _bezier(*_a, **_k):
            s = MagicMock()
            mgr.splines.append(s)
            return s

        comp.BezierSpline.side_effect = _bezier

        timeline = mgr.timeline
        timeline.InsertFusionTitleIntoTimeline.return_value = mgr.title_item
        mgr.title_item.GetFusionCompByIndex.return_value = comp
        timeline.CreateFusionClip.return_value = mgr.baked_item
        mgr.baked_item.GetMediaPoolItem.return_value = mgr.pool_item
        timeline.GetItemListInTrack.return_value = [mgr.title_item]

        media_pool, bin_folder = MagicMock(), MagicMock()

        name = resolve_bridge._author_clip_on_track(
            timeline, 1, media_pool, bin_folder, clip_doc, line_number)
        return mgr, timeline, comp, tool, spline, name

    def test_happy_path_authors_bakes_names(self):
        mgr, timeline, comp, tool, spline, name = self._run_author(
            self._make_clip_doc())

        self.assertEqual(name, "CaptionSuite-L0001")
        tool.SetInput.assert_any_call("StyledText", "hello world")
        # Spline attached to End via attribute assignment (proven pattern),
        # with trailing pin at the line-local last VISIBLE frame
        # (124 - 100 - 1 = 23; comp-local frames run 0..length-1).
        self.assertIs(getattr(tool, "End"), mgr.splines[0])
        table = mgr.splines[0].SetKeyFrames.call_args[0][0]
        self.assertIn(23.0, table)
        self.assertEqual(table[23.0][1], 1.0)
        mgr.pool_item.SetClipProperty.assert_called_once_with(
            "Clip Name", "CaptionSuite-L0001")
        timeline.CreateFusionClip.assert_called_once_with([mgr.title_item])

    def test_undo_bracket_wraps_all_mutations(self):
        mgr, *_ = self._run_author(self._make_clip_doc())
        calls = [c[0] for c in mgr.mock_calls]

        def first_index(prefix):
            return next(i for i, n in enumerate(calls) if n == prefix)

        start = first_index("comp.StartUndo")
        first_mutation = min(
            i for i, n in enumerate(calls)
            if n.startswith("tool.SetInput") or n.startswith("comp.AddTool"))
        end = first_index("comp.EndUndo")
        bake = calls.index("timeline.CreateFusionClip")

        comp_start_calls = [c for c in mgr.mock_calls
                            if c[0] == "comp.StartUndo"]
        self.assertEqual(len(comp_start_calls), 1)
        self.assertEqual(comp_start_calls[0].args[0], "Animate line 1")
        self.assertLess(start, first_mutation)
        self.assertGreater(end, first_mutation)
        # Author fully BEFORE baking; EndUndo(False) so scratch comps don't
        # accumulate undo-stack entries across hundreds of lines.
        self.assertLess(end, bake)
        mgr.comp.EndUndo.assert_called_with(False)

    def test_strip_before_attach(self):
        """Modifiers must be stripped from Start/End before splines attach."""
        mgr, _, comp, tool, spline, _ = self._run_author(
            self._make_clip_doc())
        calls = [(c[0], c) for c in mgr.mock_calls]

        strip_index = next(
            i for i, (n, _) in enumerate(calls)
            if n.endswith("GetConnectedOutput"))
        attach_index = next(
            i for i, (n, c) in enumerate(calls)
            if n == "comp.BezierSpline")
        self.assertLess(strip_index, attach_index)

    def test_scratch_track_swept_even_on_success(self):
        mgr, timeline, *_ = self._run_author(self._make_clip_doc())
        timeline.DeleteClips.assert_called_once_with([mgr.title_item], False)

    def test_missing_keyframes_structured_error_no_artifacts(self):
        clip_doc = self._make_clip_doc(keyframes={"Start": {
            "entries": [{"frame": 0, "value": 0.0}], "isStepped": True}})
        timeline = MagicMock()
        media_pool, bin_folder = MagicMock(), MagicMock()

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._author_clip_on_track(
                timeline, 1, media_pool, bin_folder, clip_doc, 3)

        self.assertEqual(ctx.exception.code, "missing-keyframes")
        # Validated up front: nothing was inserted into the timeline.
        timeline.InsertFusionTitleIntoTimeline.assert_not_called()

    def test_empty_end_curve_structured_error(self):
        clip_doc = self._make_clip_doc(keyframes={"End": {"entries": [],
                                                          "isStepped": True}})
        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._author_clip_on_track(
                MagicMock(), 1, MagicMock(), MagicMock(), clip_doc, 1)
        self.assertEqual(ctx.exception.code, "missing-keyframes")

    def test_unreachable_comp_structured_error(self):
        timeline = MagicMock()
        item = MagicMock()
        item.GetFusionCompByIndex.return_value = None
        timeline.InsertFusionTitleIntoTimeline.return_value = item

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._author_clip_on_track(
                timeline, 1, MagicMock(), MagicMock(),
                self._make_clip_doc(), 1)
        self.assertEqual(ctx.exception.code, "no-comp")

    def test_overlay_creates_second_tool(self):
        clip_doc = self._make_clip_doc(overlayKeyframes={
            "Start": {"entries": [{"frame": 0, "value": 0.0}], "isStepped": True},
            "End": {"entries": [{"frame": 0, "value": 0.28},
                                {"frame": 6, "value": 0.55}],
                    "isStepped": True},
        })
        mgr, timeline, comp, tool, spline, name = self._run_author(clip_doc)

        # Second TextPlus created in the SAME comp, same text.
        comp.AddTool.assert_any_call("TextPlus")
        mgr.overlay_tool.SetInput.assert_any_call("StyledText", "hello world")
        # Overlay curves attach via attribute assignment (proven pattern):
        # base End, then overlay Start + End — three distinct splines.
        self.assertEqual(len(mgr.splines), 3)
        self.assertIs(getattr(mgr.overlay_tool, "Start"), mgr.splines[1])
        self.assertIs(getattr(mgr.overlay_tool, "End"), mgr.splines[2])

    def test_overlay_start_keys_same_frame_as_end(self):
        """Multi-clip executor: every overlay Start keyframe is emitted on
        the SAME frame as its End counterpart (no one-frame-early lead —
        that leaves a white gap frame at each transition) and its value
        leads by half a char cell, so the leading glyph of each
        highlighted word stays whole."""
        clip_doc = self._make_clip_doc(overlayKeyframes={
            "Start": {"entries": [
                {"frame": 0, "value": 0.0},
                {"frame": 12, "value": 0.28},
                {"frame": 18, "value": 0.61}],
                "isStepped": True},
            "End": {"entries": [
                {"frame": 0, "value": 0.28},
                {"frame": 12, "value": 0.55},
                {"frame": 18, "value": 1.0}],
                "isStepped": True},
        })
        mgr, *_ = self._run_author(clip_doc)

        start_table = mgr.splines[1].SetKeyFrames.call_args[0][0]
        end_table = mgr.splines[2].SetKeyFrames.call_args[0][0]
        for frame in (0.0, 12.0, 18.0):
            self.assertIn(frame, end_table)
            self.assertIn(frame, start_table)
        half_cell = 0.5 / len("hello world")
        self.assertEqual(set(start_table.keys()), {0.0, 12.0, 18.0})
        self.assertAlmostEqual(start_table[12.0][1], 0.28 - half_cell)
        self.assertAlmostEqual(start_table[18.0][1], 0.61 - half_cell)
        self.assertEqual(start_table[0.0][1], 0.0)

    def test_overlay_merged_into_media_out_chain(self):
        """The overlay MUST be composited over the base via a Merge that
        MediaOut consumes — an orphaned tool never renders (live finding,
        Resolve 21.0.4.5: AddTool does not auto-connect into the dataflow).
        Regression guard for the invisible-highlight bug. Connections must
        use Output-attribute assignment — SetInput with a tool object is a
        fail-quiet no-op on this build."""
        clip_doc = self._make_clip_doc(overlayKeyframes={
            "Start": {"entries": [{"frame": 0, "value": 0.0}], "isStepped": True},
            "End": {"entries": [{"frame": 0, "value": 0.28}],
                    "isStepped": True},
        })
        mgr, _, comp, *_ = self._run_author(clip_doc)

        comp.AddTool.assert_any_call("Merge")
        self.assertIs(mgr.merge.Background, mgr.tool.Output)
        self.assertIs(mgr.merge.Foreground, mgr.overlay_tool.Output)
        self.assertIs(mgr.media_out.Input, mgr.merge.Output)
        # The old (broken) wiring shape must never reappear.
        mgr.media_out.SetInput.assert_not_called()

    def test_no_overlay_leaves_media_out_untouched(self):
        """Plain reveal clips keep the original single-tool graph: no Merge,
        no MediaOut rewiring."""
        mgr, _, comp, *_ = self._run_author(self._make_clip_doc())
        merge_calls = [c for c in comp.AddTool.call_args_list
                       if c.args and c.args[0] == "Merge"]
        self.assertEqual(len(merge_calls), 0)
        self.assertIs(mgr.media_out.Input, mgr.media_out_input_before)

    def test_highlight_color_applied_to_overlay_only(self):
        """highlightColor tints ONLY the overlay's fill (Red1/Green1/Blue1);
        the base tool never receives a color input."""
        clip_doc = self._make_clip_doc(
            overlayKeyframes={
                "Start": {"entries": [{"frame": 0, "value": 0.0}],
                          "isStepped": True},
                "End": {"entries": [{"frame": 0, "value": 0.5}],
                        "isStepped": True},
            },
            highlightColor="#FFD400")
        mgr, *_ = self._run_author(clip_doc)

        color_calls = [c for c in mgr.overlay_tool.SetInput.call_args_list
                       if c.args and c.args[0] in ("Red1", "Green1", "Blue1")]
        self.assertEqual(
            {(c.args[0], round(c.args[1], 4)) for c in color_calls},
            {("Red1", 1.0), ("Green1", 0.8314), ("Blue1", 0.0)})
        base_color_calls = [
            c for c in mgr.tool.SetInput.call_args_list
            if c.args and c.args[0] in ("Red1", "Green1", "Blue1")]
        self.assertEqual(len(base_color_calls), 0)

    def test_bad_highlight_color_structured_error(self):
        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._parse_hex_color("yellow")
        self.assertEqual(ctx.exception.code, "bad-highlight-color")
        self.assertIsNone(resolve_bridge._parse_hex_color(None))

    def test_overlay_mirrors_base_layout_inputs(self):
        """Zero-movement invariant: the highlight overlay must receive the
        base tool's layout inputs (the template TextPlus and a fresh
        AddTool TextPlus carry different default Size — 0.09 vs 0.08 on
        21.0.4.5 — which made every highlighted word render smaller and
        offset from its base counterpart)."""
        clip_doc = self._make_clip_doc(overlayKeyframes={
            "Start": {"entries": [{"frame": 0, "value": 0.0}],
                      "isStepped": True},
            "End": {"entries": [{"frame": 0, "value": 0.5}],
                    "isStepped": True},
        })
        mgr, *_ = self._run_author(clip_doc)

        mirrored = [c.args[0]
                    for c in mgr.overlay_tool.SetInput.call_args_list
                    if len(c.args) == 2
                    and c.args[0] in resolve_bridge._LAYOUT_MIRROR_INPUTS]
        for name in ("Center", "Pivot", "Size", "Font",
                     "HorizontalLeftCenterRight", "VerticalTopCenterBottom",
                     "LayoutWidth", "LayoutHeight"):
            self.assertIn(name, mirrored)


class TestAuthorTextplusExecute(unittest.TestCase):
    """`execute: true` runs the full Multi-Clip executor; absence keeps the
    pass-through contract."""

    def _make_doc_request(self, execute=None, clip_count=2):
        clips = [
            {
                "startFrame": 0,
                "endFrame": 24,
                "text": f"line {i}",
                "keyframes": {"End": {
                    "entries": [{"frame": 0, "value": 0.5}],
                    "isStepped": True,
                }},
                "overlayKeyframes": None,
            }
            for i in range(clip_count)
        ]
        payload = {
            "expectedToken": "fake-composite-token",
            "animationDocument": json.dumps({"clips": clips}),
        }
        if execute is not None:
            payload["execute"] = execute
        return json.dumps(payload)

    def _make_env(self, mock_open, mock_load, mock_verify, clip_count=2):
        import io
        from contextlib import redirect_stdout

        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_verify.side_effect = lambda *a, **k: True

        tracks = ["Video 1"]
        timeline.GetTrackCount.side_effect = lambda _t: len(tracks)
        timeline.GetTrackName.side_effect = lambda _t, idx: tracks[idx - 1]
        timeline.AddTrack.side_effect = lambda _t: (
            tracks.append(f"Video {len(tracks) + 1}"), True)[1]
        timeline.SetTrackName.side_effect = lambda _t, i, n: (
            tracks.__setitem__(i - 1, n), True)[1]
        timeline.GetItemListInTrack.return_value = []

        media_pool = MagicMock()
        project.GetMediaPool.return_value = media_pool
        root = MagicMock()
        root.GetSubFolderList.return_value = []
        media_pool.GetRootFolder.return_value = root
        bin_folder = MagicMock()
        media_pool.AppendSubFolder = None  # unused
        media_pool.AddSubFolder.return_value = bin_folder

        baked = []
        for i in range(1, clip_count + 1):
            clip = MagicMock()
            clip.GetName.return_value = f"CaptionSuite-L{i:04d}"
            baked.append(clip)
        bin_folder.GetClipList.return_value = baked
        media_pool.AppendToTimeline.return_value = [
            _named_placed_timeline_item() for _ in range(clip_count)]

        scratch = MagicMock()
        media_pool.CreateEmptyTimeline.return_value = scratch
        project.SetCurrentTimeline.return_value = True

        return project, timeline, media_pool, bin_folder

    def test_scratch_switch_failure_cleans_up(self):
        project = MagicMock()
        project.SetCurrentTimeline.return_value = False
        media_pool = MagicMock()
        scratch = MagicMock()
        media_pool.CreateEmptyTimeline.return_value = scratch

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._setup_scratch_timeline(project, media_pool, None)

        self.assertEqual(ctx.exception.code, "scratch-timeline-failed")
        media_pool.DeleteTimelines.assert_called_once_with([scratch])

    def test_scratch_cleanup_exception_does_not_replace_switch_failure(self):
        project = MagicMock()
        project.SetCurrentTimeline.return_value = False
        media_pool = MagicMock()
        scratch = MagicMock()
        media_pool.CreateEmptyTimeline.return_value = scratch

        with patch.object(resolve_bridge, "_delete_scratch_timeline",
                          side_effect=RuntimeError("cleanup failed")):
            with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
                resolve_bridge._setup_scratch_timeline(
                    project, media_pool, None)

        self.assertEqual(ctx.exception.code, "scratch-timeline-failed")

    def test_scratch_item_cleanup_exception_does_not_mask_primary_error(self):
        timeline = MagicMock()
        title_item = MagicMock()
        title_item.GetFusionCompByIndex.return_value = None
        timeline.InsertFusionTitleIntoTimeline.return_value = title_item
        timeline.GetItemListInTrack.return_value = [title_item]
        timeline.DeleteClips.side_effect = RuntimeError("cleanup failed")

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._author_clip_on_track(
                timeline, 1, MagicMock(), MagicMock(),
                {"startFrame": 0, "endFrame": 24,
                 "text": "line", "keyframes": {"End": {
                     "entries": [{"frame": 0, "value": 0.5}],
                     "isStepped": True,
                 }}},
                1,
            )

        self.assertEqual(ctx.exception.code, "no-comp")

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_execute_returns_done_shape(self, mock_open, mock_load,
                                        mock_verify, mock_author):
        mock_author.side_effect = ["CaptionSuite-L0001", "CaptionSuite-L0002"]
        project, timeline, media_pool, bin_folder = self._make_env(
            mock_open, mock_load, mock_verify)

        f = io.StringIO()
        with redirect_stdout(f):
            result = resolve_bridge.author_textplus(
                self._make_doc_request(execute=True))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["clipCount"], 2)
        self.assertEqual(result["bakedClipNames"],
                         ["CaptionSuite-L0001", "CaptionSuite-L0002"])
        self.assertEqual(mock_author.call_count, 2)
        # Placement onto the dedicated track (track 2, just created),
        # frame-exact via recordFrame, end-exclusive duration.
        infos = media_pool.AppendToTimeline.call_args[0][0]
        self.assertEqual(infos[0]["trackIndex"], 2)
        self.assertEqual(infos[0]["recordFrame"], 0)
        self.assertEqual(infos[0]["endFrame"], 24)

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_execute_passes_line_number_for_marker(self, mock_open,
                                                   mock_load, mock_verify,
                                                   mock_author):
        mock_author.side_effect = ["CaptionSuite-L0001", "CaptionSuite-L0002"]
        project, timeline, media_pool, bin_folder = self._make_env(
            mock_open, mock_load, mock_verify)

        with redirect_stdout(io.StringIO()):
            resolve_bridge.author_textplus(
                self._make_doc_request(execute=True))

        # Second authored line carries line_number=2 -> ownership marker
        # CaptionSuite-L0002; authoring happens on the scratch timeline.
        first_call, second_call = mock_author.call_args_list[:2]
        self.assertEqual(first_call.args[5], 1)
        self.assertEqual(second_call.args[5], 2)
        self.assertEqual(second_call.args[4]["text"], "line 1")
        self.assertIs(second_call.args[0],
                      media_pool.CreateEmptyTimeline.return_value)

    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    def test_execute_no_project_structured_error(self, mock_load, mock_verify):
        resolve = MagicMock()
        resolve.GetVersionString.return_value = "20.0"
        pm = MagicMock()
        pm.GetCurrentProject.return_value = None
        resolve.GetProjectManager.return_value = pm
        mock_load.return_value = resolve
        mock_verify.side_effect = lambda *a, **k: True

        try:
            result = resolve_bridge.author_textplus(
                self._make_doc_request(execute=True))
        except resolve_bridge.BridgeFailure as exc:
            result = {"error": {"code": exc.code, "message": exc.message}}

        self.assertEqual(result["error"]["code"], "no-project-open")

    @patch("resolve_bridge._execute_animation_document")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    @patch("resolve_bridge._timeline_identity")
    def test_passthrough_preserved_without_execute(self, mock_identity,
                                                   mock_open, mock_load,
                                                   mock_exec):
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_identity.return_value = (
            {"compositeToken": "fake-composite-token"}, 24.0, 0)

        result = resolve_bridge.author_textplus(self._make_doc_request())

        self.assertEqual(result["status"], "received")
        self.assertEqual(result["clipCount"], 2)
        mock_exec.assert_not_called()


# ---------------------------------------------------------------------------
# Checkpoint / resume tests (execute:true + runstateDir)
# ---------------------------------------------------------------------------

import tempfile
import shutil
import time as _time


class TestAuthorTextplusCheckpointing(unittest.TestCase):
    """Checkpointed, resumable execution: incremental durable checkpoints,
    resume from the last good line, token-mismatch refusal, corrupt-file
    policy, atomic writes, heartbeats, and resumableAt error payloads."""

    TOKEN = "fake-composite-token"
    TIMELINE_ID = "tl-checkpoint-test"

    def setUp(self):
        self.runstate_dir = tempfile.mkdtemp(prefix="capproj-runstate-")
        self.addCleanup(shutil.rmtree, self.runstate_dir, ignore_errors=True)

    def _checkpoint_file(self):
        return os.path.join(
            self.runstate_dir, f"{self.TIMELINE_ID}.json")

    def _read_checkpoint(self):
        with open(self._checkpoint_file(), encoding="utf-8") as fh:
            return json.load(fh)

    def _write_checkpoint(self, completed_lines, clip_ids,
                          token=TOKEN, media_ids=None, clip_hashes=None):
        ckpt = {
            "completedLines": completed_lines,
            "completedClipIds": clip_ids,
            "lastToken": token,
            "lastCheckpointAt": "2026-08-25T12:00:00Z",
            "pid": 12345,
        }
        if media_ids is not None:
            ckpt["binMediaIds"] = media_ids
        if clip_hashes is not None:
            ckpt["clipHashes"] = clip_hashes
        with open(self._checkpoint_file(), "w", encoding="utf-8") as fh:
            json.dump(ckpt, fh)

    def _clip_doc(self, i):
        return {
            "startFrame": 0,
            "endFrame": 24,
            "text": f"line {i}",
            "keyframes": {"End": {
                "entries": [{"frame": 0, "value": 0.5}],
                "isStepped": True,
            }},
            "overlayKeyframes": None,
        }

    def _make_request(self, clip_count=3, resume=False, **extra):
        clips = [self._clip_doc(i) for i in range(clip_count)]
        payload = {
            "expectedToken": self.TOKEN,
            "animationDocument": json.dumps({"clips": clips}),
            "execute": True,
            "runstateDir": self.runstate_dir,
            "timelineId": self.TIMELINE_ID,
        }
        if resume:
            payload["resume"] = True
        payload.update(extra)
        return json.dumps(payload)

    def _make_env(self, mock_open, mock_load, mock_verify, clip_count=3):
        """Same Resolve API mock shape as TestAuthorTextplusExecute."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_verify.side_effect = lambda *a, **k: True

        tracks = ["Video 1"]
        timeline.GetTrackCount.side_effect = lambda _t: len(tracks)
        timeline.GetTrackName.side_effect = lambda _t, idx: tracks[idx - 1]
        timeline.AddTrack.side_effect = lambda _t: (
            tracks.append(f"Video {len(tracks) + 1}"), True)[1]
        timeline.SetTrackName.side_effect = lambda _t, i, n: (
            tracks.__setitem__(i - 1, n), True)[1]
        timeline.GetItemListInTrack.return_value = []

        media_pool = MagicMock()
        project.GetMediaPool.return_value = media_pool
        root = MagicMock()
        root.GetSubFolderList.return_value = []
        media_pool.GetRootFolder.return_value = root
        bin_folder = MagicMock()
        media_pool.AddSubFolder.return_value = bin_folder

        baked = []
        for i in range(1, clip_count + 1):
            clip = MagicMock()
            clip.GetName.return_value = f"CaptionSuite-L{i:04d}"
            baked.append(clip)
        bin_folder.GetClipList.return_value = baked
        media_pool.AppendToTimeline.return_value = [
            _named_placed_timeline_item() for _ in range(clip_count)]

        scratch = MagicMock()
        media_pool.CreateEmptyTimeline.return_value = scratch
        project.SetCurrentTimeline.return_value = True

        # (project, timeline, media_pool, bin_folder)
        return project, timeline, media_pool, bin_folder

    def _run(self, request_json):
        f = io.StringIO()
        with redirect_stdout(f):
            try:
                result = resolve_bridge.author_textplus(request_json)
            except resolve_bridge.BridgeFailure as exc:
                result = {"error": dict(exc.extra,
                                        code=exc.code, message=exc.message)}
        events = [
            json.loads(line)
            for line in f.getvalue().strip().split("\n") if line.strip()
        ]
        return result, events

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_fresh_run_checkpoints_incrementally(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        """After each authored line the checkpoint file's completedLines
        grows; the final state matches the total."""
        # Checkpoints record the post-clear baseline token (live fix
        # 2026-08-25); with identity mocked it equals the caller's TOKEN.
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        observed_before_each_call = []

        def author(timeline, track_index, pool, folder, doc, line_number, **_kw):
            # Snapshot what's durable BEFORE this line is authored.
            if os.path.exists(self._checkpoint_file()):
                observed_before_each_call.append(
                    self._read_checkpoint()["completedLines"])
            else:
                observed_before_each_call.append(None)
            return f"CaptionSuite-L{line_number:04d}"

        mock_author.side_effect = author
        self._make_env(mock_open, mock_load, mock_verify, clip_count=3)

        result, _ = self._run(self._make_request(clip_count=3))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["resumedFrom"], 0)
        self.assertEqual(
            result["checkpointPath"], self._checkpoint_file())
        # The initial checkpoint (completedLines=0) is written up front;
        # before each subsequent author call the previous line was durable.
        self.assertEqual(observed_before_each_call, [0, 1, 2])
        final = self._read_checkpoint()
        self.assertEqual(final["completedLines"], 3)
        self.assertEqual(final["completedClipIds"],
                         ["CaptionSuite-L0001", "CaptionSuite-L0002",
                          "CaptionSuite-L0003"])
        self.assertEqual(final["lastToken"], self.TOKEN)
        self.assertEqual(final["pid"], os.getpid())

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_placement_phase_rechecks_identity_after_baking(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        """The multi-clip executor also rejects drift before placement."""
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        mock_author.side_effect = ["CaptionSuite-L0001", "CaptionSuite-L0002"]
        _, _, media_pool, _ = self._make_env(
            mock_open, mock_load, mock_verify, clip_count=2)
        calls = 0

        def verify(*_args, **_kwargs):
            nonlocal calls
            calls += 1
            # The public mode and executor each verify the initial target,
            # then two per-line checks pass; the placement phase check
            # catches the simulated external change.
            if calls == 5:
                raise resolve_bridge.BridgeFailure(
                    "token-mismatch", "timeline changed during authoring")

        mock_verify.side_effect = verify
        result, _ = self._run(self._make_request(clip_count=2))

        self.assertEqual(result["error"]["code"], "token-mismatch")
        self.assertEqual(mock_author.call_count, 2)
        media_pool.AppendToTimeline.assert_not_called()

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_resume_picks_up_from_checkpoint(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """Resume skips already-done lines: only the remaining clips are
        authored, and the response reports where it resumed from."""
        mock_author.side_effect = ["CaptionSuite-L0002",
                                   "CaptionSuite-L0003"]
        env = self._make_env(mock_open, mock_load, mock_verify, clip_count=3)
        # Record the seeded bin clip's media id so the checkpoint is
        # identity-verifiable, and the REAL content hash of line 1 so the
        # prefix-hash validation (M4) passes.
        committed_id = str(
            env[3].GetClipList.return_value[0].GetMediaId())
        self._write_checkpoint(
            1, ["CaptionSuite-L0001"], media_ids=[committed_id],
            clip_hashes=[resolve_bridge._clip_content_hash(
                self._clip_doc(0))])

        result, _ = self._run(self._make_request(clip_count=3, resume=True))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["resumedFrom"], 1)
        self.assertEqual(mock_author.call_count, 2)
        # Only lines 2 and 3 were authored.
        self.assertEqual([call.args[5] for call in
                          mock_author.call_args_list], [2, 3])
        final = self._read_checkpoint()
        self.assertEqual(final["completedLines"], 3)
        self.assertEqual(final["binMediaIds"][0], committed_id)

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_resume_reconciles_bin_against_checkpoint_d13(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """D13 hole scenario, fail safe: the checkpoint claims 2 done but a
        pool item was deleted (L0002 no longer in the bin). Resume must NOT
        positionally map surviving clips onto the wrong lines — it
        invalidates the checkpoint, sweeps what's left, and re-authors from
        line 1."""
        env = self._make_env(mock_open, mock_load, mock_verify, clip_count=3)
        seeded = {c.GetName(): c
                  for c in env[3].GetClipList.return_value}

        def author(timeline, track_index, pool, folder, doc, line_number, **_kw):
            name = f"CaptionSuite-L{line_number:04d}"
            clip = MagicMock()
            clip.GetName.return_value = name
            clip.GetMediaId.return_value = 555000 + line_number
            return name

        mock_author.side_effect = author
        self._write_checkpoint(
            2, ["CaptionSuite-L0001", "CaptionSuite-L0002"],
            media_ids=[str(seeded["CaptionSuite-L0001"].GetMediaId()),
                       "missing-media-id"])

        result, events = self._run(self._make_request(clip_count=3,
                                                      resume=True))

        self.assertEqual(result["status"], "done")
        # Fail safe: full run from line 1.
        self.assertEqual(result["resumedFrom"], 0)
        self.assertEqual([call.args[5] for call in
                          mock_author.call_args_list], [1, 2, 3])
        self.assertEqual(result["reconcile"]["action"], "invalidated")
        self.assertTrue(
            any(e.get("step") == "resume-invalidated" for e in events))

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_resume_prefix_hash_mismatch_falls_back_to_full_run(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """M4: the resume path must not trust the checkpoint's committed
        prefix when the incoming document differs over it — a franken-result
        (old clips + new content) is exactly what this prevents. Any hash
        mismatch falls back to a clean FULL run."""
        mock_author.side_effect = ["CaptionSuite-L0001",
                                   "CaptionSuite-L0002",
                                   "CaptionSuite-L0003"]
        env = self._make_env(mock_open, mock_load, mock_verify, clip_count=3)
        committed_id = str(
            env[3].GetClipList.return_value[0].GetMediaId())
        self._write_checkpoint(
            1, ["CaptionSuite-L0001"],
            media_ids=[committed_id],
            clip_hashes=["stale-hash-of-a-different-document"])

        result, events = self._run(self._make_request(clip_count=3,
                                                      resume=True))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["resumedFrom"], 0)
        self.assertEqual([call.args[5] for call in
                          mock_author.call_args_list], [1, 2, 3])
        self.assertTrue(
            any(e.get("step") == "resume-invalidated" and
                e.get("reason") == "prefix-hash-mismatch" for e in events))
        # The rewritten checkpoint reflects the full fresh run.
        final = self._read_checkpoint()
        self.assertEqual(final["completedLines"], 3)

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_resume_matching_prefix_hashes_resume_normally(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """M4 positive case: when the incoming document's hashes MATCH the
        checkpoint's recorded prefix hashes, validation passes and the run
        resumes normally (validation must not break legitimate resumes)."""
        clips = [
            {
                "startFrame": 0,
                "endFrame": 24,
                "text": f"line {i}",
                "keyframes": {"End": {
                    "entries": [{"frame": 0, "value": 0.5}],
                    "isStepped": True,
                }},
                "overlayKeyframes": None,
            }
            for i in range(3)
        ]
        real_hash = resolve_bridge._clip_content_hash(clips[0])
        mock_author.side_effect = ["CaptionSuite-L0002",
                                   "CaptionSuite-L0003"]
        env = self._make_env(mock_open, mock_load, mock_verify, clip_count=3)
        committed_id = str(
            env[3].GetClipList.return_value[0].GetMediaId())
        self._write_checkpoint(
            1, ["CaptionSuite-L0001"],
            media_ids=[committed_id],
            clip_hashes=[real_hash])

        payload = json.dumps({
            "expectedToken": self.TOKEN,
            "animationDocument": json.dumps({"clips": clips}),
            "execute": True,
            "runstateDir": self.runstate_dir,
            "timelineId": self.TIMELINE_ID,
            "resume": True,
        })
        result, _ = self._run(payload)

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["resumedFrom"], 1)
        self.assertEqual([call.args[5] for call in
                          mock_author.call_args_list], [2, 3])

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_resume_token_mismatch_refuses_to_author(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """A checkpoint written against a different identity token produces
        the structured token-mismatch-checkpoint error and authors nothing."""
        self._make_env(mock_open, mock_load, mock_verify, clip_count=3)
        self._write_checkpoint(1, ["CaptionSuite-L0001"],
                               token="stale-token")

        result, _ = self._run(self._make_request(clip_count=3, resume=True))

        self.assertEqual(result["error"]["code"],
                         "token-mismatch-checkpoint")
        mock_author.assert_not_called()

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_corrupt_checkpoint_treated_as_fresh_start(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """POLICY: a corrupt checkpoint file is ignored (fresh start), not a
        hard error — re-authoring is idempotent, availability wins."""
        mock_author.side_effect = ["CaptionSuite-L0001",
                                   "CaptionSuite-L0002"]
        self._make_env(mock_open, mock_load, mock_verify, clip_count=2)
        with open(self._checkpoint_file(), "w", encoding="utf-8") as fh:
            fh.write("{corrupt json not parsed")

        result, _ = self._run(self._make_request(clip_count=2, resume=True))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["resumedFrom"], 0)
        self.assertEqual(mock_author.call_count, 2)
        # The bad file got replaced by a valid fresh checkpoint.
        self.assertEqual(self._read_checkpoint()["completedLines"], 2)

    def test_save_checkpoint_is_atomic_replace(self):
        """The temp+os.replace pattern leaves no partial JSON: an interrupted
        replace keeps the previous complete file, and a successful one leaves
        no .tmp residue."""
        path = self._checkpoint_file()
        first = {"completedLines": 1}
        resolve_bridge._save_checkpoint(
            self.runstate_dir, self.TIMELINE_ID, first)
        original = open(path, encoding="utf-8").read()

        with patch("resolve_bridge.os.replace",
                   side_effect=OSError("simulated crash mid-write")):
            with self.assertRaises(OSError):
                resolve_bridge._save_checkpoint(
                    self.runstate_dir, self.TIMELINE_ID,
                    {"completedLines": 2})

        # The previous complete checkpoint survived the failed replace.
        self.assertEqual(open(path, encoding="utf-8").read(), original)
        self.assertEqual(json.loads(original)["completedLines"], 1)
        # ...and a successful replace cleans up its temp file.
        resolve_bridge._save_checkpoint(
            self.runstate_dir, self.TIMELINE_ID, {"completedLines": 2})
        leftovers = [n for n in os.listdir(self.runstate_dir)
                     if ".tmp" in n]
        self.assertEqual(leftovers, [])
        self.assertEqual(json.loads(open(path).read())["completedLines"], 2)

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_heartbeats_emitted_during_long_runs(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """Slow authoring triggers heartbeat NDJSON lines carrying the line
        number."""
        def slow_author(timeline, track_index, pool, folder, doc,
                        line_number, **_kw):
            _time.sleep(0.02)
            return f"CaptionSuite-L{line_number:04d}"

        mock_author.side_effect = slow_author
        self._make_env(mock_open, mock_load, mock_verify, clip_count=3)

        with patch.object(resolve_bridge, "HEARTBEAT_SECONDS", 0.001):
            _, events = self._run(self._make_request(clip_count=3))

        beats = [e for e in events if e.get("event") == "heartbeat"]
        self.assertTrue(len(beats) >= 1)
        for beat in beats:
            self.assertIn("line", beat)

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_no_runstate_dir_writes_no_files(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """Backward compatibility: without runstateDir nothing persists and
        the response carries no checkpointPath."""
        mock_author.side_effect = ["CaptionSuite-L0001",
                                   "CaptionSuite-L0002"]
        self._make_env(mock_open, mock_load, mock_verify, clip_count=2)

        payload = json.loads(self._make_request(clip_count=2))
        del payload["runstateDir"]
        del payload["timelineId"]

        with patch("resolve_bridge._save_checkpoint") as mock_save:
            result, _ = self._run(json.dumps(payload))

        self.assertEqual(result["status"], "done")
        self.assertNotIn("checkpointPath", result)
        self.assertEqual(result["resumedFrom"], 0)
        mock_save.assert_not_called()
        # No checkpoint files appeared anywhere unexpected.
        self.assertFalse(any(
            name.endswith(".json")
            for name in os.listdir(tempfile.gettempdir())
            if name.startswith("tl-checkpoint-test")))

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_resume_or_reuse_without_runstate_dir_fails_loud(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """L3: resume/reuseCheckpoint without runstateDir is a structured
        error, never a silent full re-author."""
        self._make_env(mock_open, mock_load, mock_verify, clip_count=2)

        payload = json.loads(self._make_request(clip_count=2, resume=True))
        del payload["runstateDir"]
        result, _ = self._run(json.dumps(payload))
        self.assertEqual(result["error"]["code"],
                         "resume-requires-runstate-dir")

        payload = json.loads(self._make_request(clip_count=2))
        payload["reuseCheckpoint"] = True
        del payload["runstateDir"]
        result, _ = self._run(json.dumps(payload))
        self.assertEqual(result["error"]["code"],
                         "resume-requires-runstate-dir")

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_exception_midloop_reports_resumable_at(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """An unexpected failure mid-loop surfaces as a structured error with
        resumableAt pointing at the last durably completed line."""
        calls = []

        def author(timeline, track_index, pool, folder, doc, line_number, **_kw):
            calls.append(line_number)
            if len(calls) == 2:
                raise RuntimeError("Resolve exploded mid-bake")
            return f"CaptionSuite-L{line_number:04d}"

        mock_author.side_effect = author
        self._make_env(mock_open, mock_load, mock_verify, clip_count=3)

        result, _ = self._run(self._make_request(clip_count=3))

        self.assertEqual(result["error"]["code"], "execution-failed")
        self.assertEqual(result["error"]["resumableAt"], 1)
        # And the checkpoint on disk agrees.
        self.assertEqual(self._read_checkpoint()["completedLines"], 1)


# ---------------------------------------------------------------------------
# D13 bin reconciliation on resume
# ---------------------------------------------------------------------------

class TestReconcileBinOnResume(unittest.TestCase):
    """D13: a kill between bake and checkpoint-write leaves one orphaned bin
    clip behind. Resume must reconcile actual owned artifacts against the
    checkpoint (clean or adopt) before continuing — and non-resume runs must
    never reconcile at all."""

    TOKEN = "fake-composite-token"
    TIMELINE_ID = "tl-reconcile-test"

    def setUp(self):
        self.runstate_dir = tempfile.mkdtemp(prefix="capproj-reconcile-")
        self.addCleanup(shutil.rmtree, self.runstate_dir, ignore_errors=True)

    def _checkpoint_file(self):
        return os.path.join(self.runstate_dir, f"{self.TIMELINE_ID}.json")

    def _reconcile_file(self):
        return os.path.join(
            self.runstate_dir, f"{self.TIMELINE_ID}-reconcile.json")

    def _read_checkpoint(self):
        with open(self._checkpoint_file(), encoding="utf-8") as fh:
            return json.load(fh)

    def _clip_doc(self, i):
        """Same doc shape _make_request authors (hashes must match)."""
        return {
            "startFrame": 0,
            "endFrame": 24,
            "text": f"line {i}",
            "keyframes": {"End": {
                "entries": [{"frame": 0, "value": 0.5}],
                "isStepped": True,
            }},
            "overlayKeyframes": None,
        }

    def _write_checkpoint(self, completed_lines, clip_ids, token=TOKEN,
                          media_ids="auto", clip_hashes="auto"):
        """Write a synthetic checkpoint. `media_ids="auto"` records the ids
        the mocked bin clips expose for `clip_ids`; `clip_hashes="auto"`
        records the REAL content hashes of the corresponding incoming docs —
        both required for a resume to pass identity + hash validation.
        Pass explicit lists to override, or None to omit (old format)."""
        ckpt = {
            "completedLines": completed_lines,
            "completedClipIds": clip_ids,
            "lastToken": token,
            "lastCheckpointAt": "2026-08-25T12:00:00Z",
            "pid": 12345,
        }
        if media_ids == "auto":
            ckpt["binMediaIds"] = [self._media_id(n) for n in clip_ids]
        elif media_ids is not None:
            ckpt["binMediaIds"] = media_ids
        if clip_hashes == "auto":
            ckpt["clipHashes"] = [
                resolve_bridge._clip_content_hash(self._clip_doc(i))
                for i in range(len(clip_ids))]
        elif clip_hashes is not None:
            ckpt["clipHashes"] = clip_hashes
        with open(self._checkpoint_file(), "w", encoding="utf-8") as fh:
            json.dump(ckpt, fh)

    def _media_id(self, name):
        """Deterministic mock GetMediaId for a bin clip name (mirrors
        _make_bin_clip); checkpoints must record the same ids the mocked
        clips expose so identity-based resume validation can pass."""
        return str(9000 + abs(hash(name)) % 1000)

    def _make_bin_clip(self, name):
        clip = MagicMock()
        clip.GetName.return_value = name
        clip.GetMediaId.return_value = int(self._media_id(name))
        return clip

    def _make_request(self, clip_count=3, resume=False,
                      reconcile_mode=None, **extra):
        clips = [
            {
                "startFrame": 0,
                "endFrame": 24,
                "text": f"line {i}",
                "keyframes": {"End": {
                    "entries": [{"frame": 0, "value": 0.5}],
                    "isStepped": True,
                }},
                "overlayKeyframes": None,
            }
            for i in range(clip_count)
        ]
        payload = {
            "expectedToken": self.TOKEN,
            "animationDocument": json.dumps({"clips": clips}),
            "execute": True,
            "runstateDir": self.runstate_dir,
            "timelineId": self.TIMELINE_ID,
        }
        if resume:
            payload["resume"] = True
        if reconcile_mode is not None:
            payload["reconcileMode"] = reconcile_mode
        payload.update(extra)
        return json.dumps(payload)

    def _make_env(self, mock_open, mock_load, mock_verify, bin_names,
                  track_items=None):
        """Resolve API mocks; `bin_names` is the initial destination-bin
        contents (list of clip names); `track_items` optionally seeds the
        target animate track."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_verify.side_effect = lambda *a, **k: True

        tracks = ["Video 1"]
        timeline.GetTrackCount.side_effect = lambda _t: len(tracks)
        timeline.GetTrackName.side_effect = lambda _t, idx: tracks[idx - 1]
        timeline.AddTrack.side_effect = lambda _t: (
            tracks.append(f"Video {len(tracks) + 1}"), True)[1]
        timeline.SetTrackName.side_effect = lambda _t, i, n: (
            tracks.__setitem__(i - 1, n), True)[1]
        track_state = {"items": list(track_items or [])}
        timeline.GetItemListInTrack.side_effect = (
            lambda _t, idx: list(track_state["items"])
            if idx == 2 else [])

        def delete_track_clips(clips, *_args, **_kwargs):
            doomed = {id(c) for c in clips}
            track_state["items"] = [
                c for c in track_state["items"] if id(c) not in doomed]
            return True

        # Model real deletion so the post-clear verification re-scan in
        # _clear_owned_clips sees a genuinely emptied track.
        timeline.DeleteClips.side_effect = delete_track_clips

        media_pool = MagicMock()
        project.GetMediaPool.return_value = media_pool
        root = MagicMock()
        root.GetSubFolderList.return_value = []
        media_pool.GetRootFolder.return_value = root
        bin_folder = MagicMock()
        media_pool.AddSubFolder.return_value = bin_folder

        clips_by_name = {name: self._make_bin_clip(name)
                         for name in bin_names}
        bin_folder.GetClipList.side_effect = (
            lambda: list(clips_by_name.values()))
        media_pool.DeleteClips.return_value = True
        # _place_baked_clips consumes a concrete list and verifies its length;
        # a bare MagicMock is not a valid Resolve AppendToTimeline result.
        media_pool.AppendToTimeline.side_effect = (
            lambda clip_infos: [_named_placed_timeline_item()
                                for _ in clip_infos])

        scratch = MagicMock()
        media_pool.CreateEmptyTimeline.return_value = scratch
        project.SetCurrentTimeline.return_value = True

        return {
            "project": project, "timeline": timeline,
            "media_pool": media_pool, "bin_folder": bin_folder,
            "clips_by_name": clips_by_name,
        }

    def _fake_author(self, env):
        """Side-effect for _author_clip_on_track: returns the marker name and
        adds the matching clip to the fake destination bin, mirroring what
        the real bake does."""
        def author(timeline, track_index, pool, folder, doc, line_number, **_kw):
            name = f"CaptionSuite-L{line_number:04d}"
            env["clips_by_name"][name] = self._make_bin_clip(name)
            return name
        return author

    def _run(self, request_json):
        f = io.StringIO()
        with redirect_stdout(f):
            try:
                result = resolve_bridge.author_textplus(request_json)
            except resolve_bridge.BridgeFailure as exc:
                result = {"error": dict(exc.extra,
                                        code=exc.code, message=exc.message)}
        events = [
            json.loads(line)
            for line in f.getvalue().strip().split("\n") if line.strip()
        ]
        return result, events

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_clean_deletes_orphan_bin_clip_and_resumes(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """Orphan in bin (one more clip than the checkpoint committed) +
        mode=clean -> the orphan is deleted via MediaPool.DeleteClips and
        authoring resumes from the checkpoint line."""
        env = self._make_env(
            mock_open, mock_load, mock_verify,
            bin_names=["CaptionSuite-L0001", "Fusion Clip 2"],
        )
        mock_author.side_effect = self._fake_author(env)
        orphan = env["clips_by_name"]["Fusion Clip 2"]
        self._write_checkpoint(1, ["CaptionSuite-L0001"])

        result, events = self._run(
            self._make_request(clip_count=2, resume=True,
                               reconcile_mode="clean"))

        self.assertEqual(result["status"], "done")
        # Orphan deleted; committed clip untouched.
        env["media_pool"].DeleteClips.assert_called_once_with([orphan])
        # Resume proceeds from the checkpoint line.
        self.assertEqual(result["resumedFrom"], 1)
        self.assertEqual([c.args[5] for c in
                          mock_author.call_args_list], [2])
        self.assertEqual(self._read_checkpoint()["completedLines"], 2)
        self.assertEqual(result["reconcile"]["action"], "cleaned")
        steps = [e.get("step") for e in events]
        self.assertIn("reconciling", steps)
        self.assertIn("reconciled", steps)

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_adopt_contiguous_extends_checkpoint_skips_line(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """The canonical D13 leak (exactly one unnamed extra bin clip) +
        mode=adopt -> the checkpoint is extended to cover it and authoring
        continues AFTER it; nothing is deleted."""
        env = self._make_env(
            mock_open, mock_load, mock_verify,
            bin_names=["CaptionSuite-L0001", "Fusion Clip 2"],
        )
        mock_author.side_effect = self._fake_author(env)
        self._write_checkpoint(1, ["CaptionSuite-L0001"])

        result, _ = self._run(
            self._make_request(clip_count=3, resume=True,
                               reconcile_mode="adopt"))

        self.assertEqual(result["status"], "done")
        # Nothing deleted — the orphan was adopted.
        env["media_pool"].DeleteClips.assert_not_called()
        # Checkpoint extended past the adopted line; after line 3 authored,
        # all three lines are complete.
        final = self._read_checkpoint()
        self.assertEqual(final["completedLines"], 3)
        self.assertEqual(final["completedClipIds"],
                         ["CaptionSuite-L0001", "CaptionSuite-L0002",
                          "CaptionSuite-L0003"])
        # ...and the next authored line SKIPS it.
        self.assertEqual(result["resumedFrom"], 2)
        self.assertEqual([c.args[5] for c in
                          mock_author.call_args_list], [3])
        self.assertEqual(result["reconcile"]["action"], "adopted")
        self.assertEqual(result["reconcile"]["adoptedClipIds"],
                         ["CaptionSuite-L0002"])

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_adopt_gap_falls_back_to_clean_with_warning(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """Two unnamed extra bin clips cannot be explained as 'the next line
        was baked once' — adopt falls back to clean with a warning progress
        line, and the orphans are deleted."""
        env = self._make_env(
            mock_open, mock_load, mock_verify,
            bin_names=["CaptionSuite-L0001", "Fusion Clip 2",
                       "Fusion Clip 3"],
        )
        mock_author.side_effect = self._fake_author(env)
        orphans = [env["clips_by_name"]["Fusion Clip 2"],
                   env["clips_by_name"]["Fusion Clip 3"]]
        self._write_checkpoint(1, ["CaptionSuite-L0001"])

        result, events = self._run(
            self._make_request(clip_count=2, resume=True,
                               reconcile_mode="adopt"))

        self.assertEqual(result["status"], "done")
        env["media_pool"].DeleteClips.assert_called_once_with(orphans)
        # Warning progress line emitted...
        fallbacks = [e for e in events if e.get("step") == "reconcile-fallback"]
        self.assertEqual(len(fallbacks), 1)
        # ...resume is back to clean semantics...
        self.assertEqual(result["resumedFrom"], 1)
        self.assertEqual([c.args[5] for c in
                          mock_author.call_args_list], [2])
        # ...and the checkpoint was NOT extended.
        self.assertEqual(self._read_checkpoint()["completedLines"], 2)
        self.assertEqual(result["reconcile"]["fallbackFrom"], "adopt")

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_clean_bin_no_orphans_normal_resume(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """Bin matches the checkpoint exactly -> no deletions, normal resume
        from the checkpoint line."""
        env = self._make_env(
            mock_open, mock_load, mock_verify,
            bin_names=["CaptionSuite-L0001", "CaptionSuite-L0002"],
        )
        mock_author.side_effect = self._fake_author(env)
        self._write_checkpoint(
            2, ["CaptionSuite-L0001", "CaptionSuite-L0002"])

        result, _ = self._run(self._make_request(clip_count=3, resume=True))

        self.assertEqual(result["status"], "done")
        env["media_pool"].DeleteClips.assert_not_called()
        self.assertEqual(result["resumedFrom"], 2)
        self.assertEqual([c.args[5] for c in
                          mock_author.call_args_list], [3])
        self.assertEqual(result["reconcile"]["orphansDetected"], 0)

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_orphaned_timeline_item_deleted_on_clean(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """A placed-but-uncommitted item on the target track (marker beyond
        the checkpoint) is also an orphan and gets deleted on clean."""
        stray_item = MagicMock()
        stray_item.GetName.return_value = "CaptionSuite-L0009"
        env = self._make_env(
            mock_open, mock_load, mock_verify,
            bin_names=["CaptionSuite-L0001"],
            track_items=[stray_item],
        )
        mock_author.side_effect = self._fake_author(env)
        self._write_checkpoint(1, ["CaptionSuite-L0001"])

        result, _ = self._run(self._make_request(clip_count=2, resume=True))

        self.assertEqual(result["status"], "done")
        env["timeline"].DeleteClips.assert_any_call([stray_item])
        self.assertEqual(result["reconcile"]["deletedTimelineItems"], 1)

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_reconcile_report_file_written_with_correct_shape(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """Every reconciled resume writes <timelineId>-reconcile.json next to
        the checkpoint, mirroring ExecutorBinReconcile.swift's shape."""
        env = self._make_env(
            mock_open, mock_load, mock_verify,
            bin_names=["CaptionSuite-L0001", "Fusion Clip 2"],
        )
        mock_author.side_effect = self._fake_author(env)
        self._write_checkpoint(1, ["CaptionSuite-L0001"])

        result, _ = self._run(
            self._make_request(clip_count=2, resume=True))

        self.assertTrue(os.path.exists(self._reconcile_file()))
        with open(self._reconcile_file(), encoding="utf-8") as fh:
            report = json.load(fh)
        for key in ("binClips", "binClipIds", "timelineOwnedItems",
                    "orphansDetected", "action", "reconciledAt"):
            self.assertIn(key, report)
        self.assertEqual(report["binClips"],
                         ["CaptionSuite-L0001", "Fusion Clip 2"])
        self.assertEqual(len(report["binClipIds"]), 2)
        self.assertTrue(all(isinstance(i, str) for i in report["binClipIds"]))
        self.assertEqual(report["orphansDetected"], 1)
        self.assertEqual(report["action"], "cleaned")
        self.assertTrue(report["reconciledAt"].endswith("Z"))
        # The result payload carries the same report.
        self.assertEqual(result["reconcile"], report)

    @patch("resolve_bridge._reconcile_bin_on_resume")
    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_non_resume_run_never_reconciles(
        self, mock_open, mock_load, mock_verify, mock_author, mock_reconcile,
    ):
        """Non-resume runs are unaffected: no reconciliation, no deletions,
        no reconcile report file, no reconcile key in the result."""
        env = self._make_env(
            mock_open, mock_load, mock_verify,
            bin_names=[],  # empty bin; a fresh run authors into it
        )
        mock_author.side_effect = self._fake_author(env)

        result, events = self._run(self._make_request(clip_count=2))

        self.assertEqual(result["status"], "done")
        mock_reconcile.assert_not_called()
        env["media_pool"].DeleteClips.assert_not_called()
        self.assertNotIn("reconcile", result)
        self.assertFalse(any(e.get("step") in ("reconciling", "reconciled")
                             for e in events))
        self.assertFalse(os.path.exists(self._reconcile_file()))

    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_invalid_reconcile_mode_structured_error(
        self, mock_open, mock_load, mock_verify,
    ):
        """An unknown reconcileMode fails loud before touching anything."""
        self._make_env(mock_open, mock_load, mock_verify, bin_names=[])
        self._write_checkpoint(1, ["CaptionSuite-L0001"])

        result, _ = self._run(
            self._make_request(clip_count=2, resume=True,
                               reconcile_mode="yolo"))

        self.assertEqual(result["error"]["code"], "bad-reconcile-mode")

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_reconcile_delete_failure_is_structured(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """A fail-quiet MediaPool.DeleteClips on an orphan fails loud."""
        env = self._make_env(
            mock_open, mock_load, mock_verify,
            bin_names=["CaptionSuite-L0001", "Fusion Clip 2"],
        )
        env["media_pool"].DeleteClips.return_value = False
        self._write_checkpoint(1, ["CaptionSuite-L0001"])

        result, _ = self._run(self._make_request(clip_count=2, resume=True))

        self.assertEqual(result["error"]["code"], "reconcile-clean-failed")

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_stale_bin_prefix_maps_by_identity_not_position(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """A prior COMPLETED run left clips in the app-dedicated bin; a later
        fresh run was killed mid-way. The checkpoint's committed clip sits
        AFTER the stale entries, so naive positional mapping ("first k
        entries") would mis-map stale content onto lines 1..k and delete the
        run's REAL work. Identity mapping via recorded media ids must keep
        the committed clip and sweep only the stale ones."""
        env = self._make_env(
            mock_open, mock_load, mock_verify,
            bin_names=["Old Clip A", "Old Clip B", "CaptionSuite-L0001"],
        )
        mock_author.side_effect = self._fake_author(env)
        stale = [
            env["clips_by_name"]["Old Clip A"],
            env["clips_by_name"]["Old Clip B"],
        ]
        self._write_checkpoint(1, ["CaptionSuite-L0001"])

        result, events = self._run(
            self._make_request(clip_count=2, resume=True))

        self.assertEqual(result["status"], "done")
        # Stale clips deleted; the checkpoint's OWN clip survives.
        env["media_pool"].DeleteClips.assert_called_once_with(stale)
        # Resume proceeds from the genuinely-committed line — not from the
        # stale prefix.
        self.assertEqual(result["resumedFrom"], 1)
        self.assertEqual([c.args[5] for c in
                          mock_author.call_args_list], [2])
        self.assertEqual(result["reconcile"]["action"], "cleaned")
        self.assertEqual(self._read_checkpoint()["completedLines"], 2)

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_holed_bin_invalidates_checkpoint_and_falls_back_to_full_run(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """A user deleted pool items, leaving holes: the checkpoint's
        committed clip is no longer in the bin. Resume must NOT silently map
        surviving clips onto wrong lines — the checkpoint is invalidated,
        everything left is swept as orphans, and the run re-authors from
        line 1."""
        env = self._make_env(
            mock_open, mock_load, mock_verify,
            bin_names=["Fusion Clip 9"],  # committed L0001 is GONE
        )
        mock_author.side_effect = self._fake_author(env)
        leftover = env["clips_by_name"]["Fusion Clip 9"]
        self._write_checkpoint(1, ["CaptionSuite-L0001"])

        result, events = self._run(
            self._make_request(clip_count=2, resume=True))

        self.assertEqual(result["status"], "done")
        # Fail safe: full re-author.
        self.assertEqual(result["resumedFrom"], 0)
        self.assertEqual([c.args[5] for c in
                          mock_author.call_args_list], [1, 2])
        # The unaccounted leftover is cleaned...
        env["media_pool"].DeleteClips.assert_called_once_with([leftover])
        # ...the reconcile report records WHY...
        self.assertEqual(result["reconcile"]["action"], "invalidated")
        self.assertIn("invalidatedReason", result["reconcile"])
        # ...and the invalidated progress event was emitted.
        self.assertTrue(
            any(e.get("step") == "resume-invalidated" for e in events))
        self.assertEqual(self._read_checkpoint()["completedLines"], 2)

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_old_format_checkpoint_without_media_ids_invalidates(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """A checkpoint predating binMediaIds recording cannot prove that its
        committed prefix matches the bin contents — positional trust is
        exactly what mis-maps stale/holed bins, so it fails safe to a clean
        full run instead."""
        env = self._make_env(
            mock_open, mock_load, mock_verify,
            bin_names=["CaptionSuite-L0001"],
        )
        mock_author.side_effect = self._fake_author(env)
        self._write_checkpoint(1, ["CaptionSuite-L0001"], media_ids=None,
                               clip_hashes=None)

        result, events = self._run(
            self._make_request(clip_count=2, resume=True))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["resumedFrom"], 0)
        self.assertEqual([c.args[5] for c in
                          mock_author.call_args_list], [1, 2])
        self.assertEqual(result["reconcile"]["action"], "invalidated")

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_validated_resume_records_media_ids_in_checkpoints(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """Every checkpoint written by the executor records binMediaIds
        parallel to completedClipIds so FUTURE resumes can validate identity
        instead of trusting positions."""
        env = self._make_env(
            mock_open, mock_load, mock_verify,
            bin_names=["CaptionSuite-L0001", "Fusion Clip 2"],
        )

        def author(timeline, track_index, pool, folder, doc, line_number,
                   **_kw):
            name = f"CaptionSuite-L{line_number:04d}"
            clip = MagicMock()
            clip.GetName.return_value = name
            clip.GetMediaId.return_value = 777000 + line_number
            env["clips_by_name"][name] = clip
            return name

        mock_author.side_effect = author
        self._write_checkpoint(1, ["CaptionSuite-L0001"])

        result, _ = self._run(self._make_request(clip_count=3, resume=True))

        self.assertEqual(result["status"], "done")
        final = self._read_checkpoint()
        self.assertEqual(final["completedClipIds"],
                         ["CaptionSuite-L0001", "CaptionSuite-L0002",
                          "CaptionSuite-L0003"])
        self.assertEqual(final["binMediaIds"],
                         [self._media_id("CaptionSuite-L0001"),
                          "777002", "777003"])



# ---------------------------------------------------------------------------
# Clear-and-reuse policy hardening (ARCHITECTURE.md §6 bridge rule 7)
# ---------------------------------------------------------------------------

class TestClearAndReusePolicy(unittest.TestCase):
    """Clear-and-reuse behavior for the execute path of author-textplus."""

    TOKEN = "fake-composite-token"

    def _make_env(self, mock_open, mock_load, mock_verify, track_name="Animate"):
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_verify.return_value = True

        tracks = ["Video 1", track_name]
        timeline.GetTrackCount.side_effect = lambda _t: len(tracks)
        timeline.GetTrackName.side_effect = lambda _t, idx: (
            tracks[idx - 1] if 0 < idx <= len(tracks) else None)
        timeline.GetItemListInTrack.return_value = []

        media_pool = MagicMock()
        project.GetMediaPool.return_value = media_pool
        root = MagicMock()
        root.GetSubFolderList.return_value = []
        media_pool.GetRootFolder.return_value = root
        bin_folder = MagicMock()
        media_pool.AddSubFolder.return_value = bin_folder

        return project, timeline, media_pool, bin_folder

    def _clip(self, name):
        clip = MagicMock()
        clip.GetName.return_value = name
        return clip

    # -- execute path of author-textplus ---------------------------------------

    def _make_doc_request(self, **extra):
        clips = [{
            "startFrame": 0,
            "endFrame": 24,
            "text": "line",
            "keyframes": {"End": {
                "entries": [{"frame": 0, "value": 0.5}],
                "isStepped": True,
            }},
            "overlayKeyframes": None,
        }]
        payload = {
            "expectedToken": self.TOKEN,
            "animationDocument": json.dumps({"clips": clips}),
            "execute": True,
        }
        payload.update(extra)
        return json.dumps(payload)

    def _run_execute(self, request_json):
        f = io.StringIO()
        with redirect_stdout(f):
            try:
                result = resolve_bridge.author_textplus(request_json)
            except resolve_bridge.BridgeFailure as exc:
                result = {"error": dict(exc.extra,
                                        code=exc.code, message=exc.message)}
        return result

    def _make_execute_env(self, mock_open, mock_load, mock_verify,
                          track_items=None, bin_names=None):
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_verify.side_effect = lambda *a, **k: True

        tracks = ["Video 1"]
        timeline.GetTrackCount.side_effect = lambda _t: len(tracks)
        timeline.GetTrackName.side_effect = lambda _t, idx: tracks[idx - 1]
        timeline.AddTrack.side_effect = lambda _t: (
            tracks.append(f"Video {len(tracks) + 1}"), True)[1]
        timeline.SetTrackName.side_effect = lambda _t, i, n: (
            tracks.__setitem__(i - 1, n), True)[1]
        state = {"items": list(track_items or [])}
        timeline.GetItemListInTrack.side_effect = (
            lambda _t, idx: list(state["items"]) if idx == len(tracks)
            else [])
        timeline.DeleteClips.side_effect = lambda clips, *_a, **_k: (
            state.__setitem__(
                "items",
                [c for c in state["items"] if id(c) not in {id(x) for x in clips}]),
            True)[1]

        media_pool = MagicMock()
        project.GetMediaPool.return_value = media_pool
        root = MagicMock()
        root.GetSubFolderList.return_value = []
        media_pool.GetRootFolder.return_value = root
        bin_folder = MagicMock()
        media_pool.AddSubFolder.return_value = bin_folder

        clips_by_name = {}
        for name in (bin_names or []):
            clip = MagicMock()
            clip.GetName.return_value = name
            clips_by_name[name] = clip
        bin_folder.GetClipList.side_effect = (
            lambda: list(clips_by_name.values()))
        media_pool.AppendToTimeline.return_value = [_named_placed_timeline_item()]

        scratch = MagicMock()
        media_pool.CreateEmptyTimeline.return_value = scratch
        project.SetCurrentTimeline.return_value = True

        return {
            "project": project, "timeline": timeline,
            "media_pool": media_pool, "bin_folder": bin_folder,
            "clips_by_name": clips_by_name, "track_state": state,
        }

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_execute_require_empty_blocks_non_owned(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """execute:true + requireEmptyTrack=true + a non-owned clip on the
        freshly created target track -> structured block error, no baking."""
        env = self._make_execute_env(
            mock_open, mock_load, mock_verify,
            track_items=[self._clip("My Graphics")],
        )

        result = self._run_execute(self._make_doc_request(requireEmptyTrack=True))

        self.assertEqual(result["error"]["code"], "non-owned-clips-block-track")
        self.assertEqual(result["error"]["blockingClips"], ["My Graphics"])
        mock_author.assert_not_called()

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_execute_clean_bin_returns_cleared_count(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """execute:true + cleanBin=true sweeps owned/orphaned pool items from
        the destination bin before fresh authoring and reports the count."""

        def author(_tl, _ti, _pool, folder, _doc, line_number, **_kw):
            name = f"CaptionSuite-L{line_number:04d}"
            clip = MagicMock()
            clip.GetName.return_value = name
            env["clips_by_name"][name] = clip
            return name

        mock_author.side_effect = author
        stale_owned = MagicMock()
        stale_owned.GetName.return_value = "CaptionSuite-L0001"
        orphan = MagicMock()
        orphan.GetName.return_value = "Fusion Clip 9"
        env = self._make_execute_env(mock_open, mock_load, mock_verify)
        env["clips_by_name"]["CaptionSuite-L0001"] = stale_owned
        env["clips_by_name"]["Fusion Clip 9"] = orphan
        env["media_pool"].DeleteClips.return_value = True

        result = self._run_execute(self._make_doc_request(cleanBin=True))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["clearedBinClips"], 2)
        deleted = env["media_pool"].DeleteClips.call_args[0][0]
        self.assertIn(stale_owned, deleted)
        self.assertIn(orphan, deleted)

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_execute_default_leaves_non_owned_track_item_alone(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """execute:true without requireEmptyTrack: a non-owned item on the
        target track is left untouched and the run proceeds."""
        foreign = MagicMock()
        foreign.GetName.return_value = "Keep Me"
        env = self._make_execute_env(
            mock_open, mock_load, mock_verify, track_items=[foreign])

        def author(_tl, _ti, _pool, folder, _doc, line_number, **_kw):
            name = f"CaptionSuite-L{line_number:04d}"
            clip = MagicMock()
            clip.GetName.return_value = name
            env["clips_by_name"][name] = clip
            return name

        mock_author.side_effect = author

        result = self._run_execute(self._make_doc_request())

        self.assertEqual(result["status"], "done")
        self.assertEqual(env["track_state"]["items"], [foreign])


# ---------------------------------------------------------------------------
# Persistent-Title window-baked authoring (docs/PERSISTENT-TITLE-DESIGN.md)
# ---------------------------------------------------------------------------

class TestPackWindows(unittest.TestCase):
    """Pure window packing: greedy consecutive grouping under a frame cap
    derived from max_window_seconds * fps."""

    def _clip(self, start, end, cid=None):
        return {
            "clipId": cid or f"c{start}-{end}",
            "startFrame": start,
            "endFrame": end,
            "text": "cue",
            "keyframes": {"End": {"entries": [{"frame": 0, "value": 1.0}],
                                  "isStepped": True}},
        }

    # Default: 4.8 s * 24 fps = 115 frames (rounded).

    def test_empty_input(self):
        self.assertEqual(resolve_bridge._pack_windows([]), [])

    def test_all_clips_fit_in_one_window(self):
        clips = [self._clip(0, 24), self._clip(24, 48), self._clip(48, 72)]
        windows = resolve_bridge._pack_windows(clips)
        self.assertEqual(len(windows), 1)
        self.assertEqual(windows[0], clips)

    def test_exact_boundary_stays_together(self):
        """A window spanning EXACTLY max frames (115) does not overflow."""
        clips = [self._clip(0, 59), self._clip(59, 115)]
        windows = resolve_bridge._pack_windows(clips)
        self.assertEqual(len(windows), 1)
        self.assertEqual(len(windows[0]), 2)

    def test_overflow_by_one_frame_splits(self):
        """Spanning max+1 frames starts a new window."""
        clips = [self._clip(0, 59), self._clip(59, 116)]
        windows = resolve_bridge._pack_windows(clips)
        self.assertEqual(len(windows), 2)
        self.assertEqual(windows[0], [clips[0]])
        self.assertEqual(windows[1], [clips[1]])

    def test_single_oversized_clip_fails_before_authoring(self):
        """A cue beyond Resolve's insert cap must never reach authoring."""
        big = self._clip(0, 240)
        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._pack_windows([big])
        self.assertEqual(ctx.exception.code, "window-duration-exceeds-cap")

    def test_oversized_clip_rejects_the_whole_document(self):
        big = self._clip(0, 240)
        nxt = self._clip(240, 264)
        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._pack_windows([big, nxt])
        self.assertEqual(ctx.exception.code, "window-duration-exceeds-cap")

    def test_greedy_packing_of_many_cues(self):
        clips = [self._clip(i * 24, (i + 1) * 24) for i in range(8)]
        windows = resolve_bridge._pack_windows(clips)
        # Cumulative spans: 24..96 stay (<=115); the 5th pushes to 120 -> split.
        self.assertEqual([[len(w) for w in windows]], [[4, 4]])
        flattened = [c for w in windows for c in w]
        self.assertEqual(flattened, clips)

    def test_custom_fps_derives_frame_cap(self):
        clips = [self._clip(0, 40), self._clip(40, 80)]
        # 4.8 s * 12 fps = 57.6 -> 58 frames cap.
        windows = resolve_bridge._pack_windows(clips, fps=12)
        self.assertEqual(len(windows), 2)

    def test_bad_window_seconds_structured_error(self):
        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._pack_windows([], max_window_seconds="NaN")
        self.assertEqual(ctx.exception.code, "bad-windowing")

    def test_rescale_clip_doc_converts_keyframes_to_scratch_rate(self):
        clip = self._clip(134, 349)
        clip["keyframes"]["End"]["entries"] = [
            {"frame": 0, "value": 0.0},
            {"frame": 214, "value": 1.0},
        ]
        converted = resolve_bridge._rescale_clip_doc_for_fps(
            clip, source_fps=24.0, target_fps=59.94)
        self.assertEqual((converted["startFrame"], converted["endFrame"]),
                         (54, 140))
        self.assertEqual(
            [e["frame"] for e in converted["keyframes"]["End"]["entries"]],
            [0, 86],
        )
        self.assertEqual((clip["startFrame"], clip["endFrame"]), (134, 349))

    def test_place_scales_source_range_for_fractional_rate(self):
        # A single (last-in-batch) clip has no next clip to span to, so it
        # falls back to its OWN target-rate length (134), ceiled into the
        # 24fps scratch timebase: ceil(134 * 24/59.94) == 54.
        media_pool = MagicMock()
        bin_folder = MagicMock()
        source = MagicMock()
        placed = _named_placed_timeline_item()
        media_pool.AppendToTimeline.return_value = [placed]
        doc = self._clip(0, 134)

        count = resolve_bridge._place_baked_clips(
            media_pool, bin_folder, [doc], ["CaptionSuite-L0001"], [source],
            track_index=2, timeline_start_frame=216000,
            source_fps=24.0, target_fps=59.94,
        )

        self.assertEqual(count, 1)
        info = media_pool.AppendToTimeline.call_args.args[0][0]
        self.assertEqual(info["endFrame"], 54)
        self.assertEqual(info["recordFrame"], 216000)

    def test_place_spans_source_range_to_next_clips_start_to_close_gaps(self):
        # Two clips back to back at fractional rate 59.94: the FIRST clip's
        # source range is sized to reach the NEXT clip's start (not its own
        # length), CEILed so the conformed duration is never shorter than
        # that span — this is what closes the 1-3 frame black gaps a human
        # found between every caption on a live 59.94fps timeline
        # (docs/research/animate-59-94-boundary-gap-2026-08-31.md). doc1
        # spans target frames 0..134 and doc2 starts at 134 and ends at
        # 300, so doc1's span-to-next (134) happens to equal its own
        # length here — the real point of this test is doc2, the LAST clip
        # in the batch, which has no successor to span to and correctly
        # falls back to its OWN length (166), ceiled to 67.
        media_pool = MagicMock()
        bin_folder = MagicMock()
        source1, source2 = MagicMock(), MagicMock()
        placed1, placed2 = (_named_placed_timeline_item(),
                            _named_placed_timeline_item())
        media_pool.AppendToTimeline.return_value = [placed1, placed2]
        doc1 = self._clip(0, 134)
        doc2 = self._clip(134, 300)

        count = resolve_bridge._place_baked_clips(
            media_pool, bin_folder, [doc1, doc2],
            ["CaptionSuite-L0001", "CaptionSuite-L0002"], [source1, source2],
            track_index=2, timeline_start_frame=216000,
            source_fps=24.0, target_fps=59.94,
        )

        self.assertEqual(count, 2)
        infos = media_pool.AppendToTimeline.call_args.args[0]
        # doc1 spans to doc2's start (134 target frames), same as its own
        # length here, so ceil(134 * 24/59.94) == 54.
        self.assertEqual(infos[0]["endFrame"], 54)
        self.assertEqual(infos[0]["recordFrame"], 216000)
        # doc2 is last-in-batch: falls back to its own length (166),
        # ceil(166 * 24/59.94) == 67.
        self.assertEqual(infos[1]["endFrame"], 67)
        self.assertEqual(infos[1]["recordFrame"], 216134)

    def test_placement_refuses_an_unowned_timeline_item(self):
        """A fail-quiet SetName must not be accepted as a completed run."""
        media_pool = MagicMock()
        bin_folder = MagicMock()
        source = MagicMock()
        placed = MagicMock()
        placed.SetName.return_value = False
        media_pool.AppendToTimeline.return_value = [placed]

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._place_baked_clips(
                media_pool, bin_folder, [self._clip(0, 24)],
                ["CaptionSuite-L0001"], [source],
                track_index=2, timeline_start_frame=0,
            )

        self.assertEqual(ctx.exception.code, "ownership-marker-failed")

    def test_placement_requires_a_readable_matching_marker(self):
        """A successful-looking write without a verified readback is unsafe."""
        media_pool = MagicMock()
        bin_folder = MagicMock()
        source = MagicMock()
        placed = MagicMock()
        placed.SetName.return_value = None
        placed.GetName.side_effect = RuntimeError("Resolve getter failed")
        media_pool.AppendToTimeline.return_value = [placed]

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._place_baked_clips(
                media_pool, bin_folder, [self._clip(0, 24)],
                ["CaptionSuite-L0001"], [source],
                track_index=2, timeline_start_frame=0,
            )

        self.assertEqual(ctx.exception.code, "ownership-marker-failed")

    def test_placement_requires_an_exact_result_count(self):
        """Extra returned items would otherwise be left unmarked."""
        media_pool = MagicMock()
        bin_folder = MagicMock()
        source = MagicMock()
        media_pool.AppendToTimeline.return_value = [MagicMock(), MagicMock()]

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._place_baked_clips(
                media_pool, bin_folder, [self._clip(0, 24)],
                ["CaptionSuite-L0001"], [source],
                track_index=2, timeline_start_frame=0,
            )

        self.assertEqual(ctx.exception.code, "placement-count-mismatch")


class TestVisibilityGate(unittest.TestCase):
    """Blend-input stepped-spline gating keeps each cue branch visible only
    during its own slice of the window comp."""

    def _gate_table(self, start_local, end_local, window_length):
        comp, tool = MagicMock(), MagicMock()
        resolve_bridge._attach_visibility_gate(
            comp, tool, start_local, end_local, window_length)
        comp.BezierSpline.assert_called_once_with({})
        self.assertIs(getattr(tool, "Blend"),
                      comp.BezierSpline.return_value)
        return (comp.BezierSpline.return_value.SetKeyFrames
                .call_args[0][0])

    def test_mid_window_cue_has_hidden_leading_key(self):
        table = self._gate_table(24, 48, 115)
        self.assertEqual(set(table.keys()), {0.0, 24.0, 48.0})
        self.assertEqual(table[0.0][1], 0.0)
        self.assertEqual(table[24.0][1], 1.0)
        self.assertEqual(table[48.0][1], 0.0)

    def test_cue_at_comp_start_needs_no_leading_key(self):
        table = self._gate_table(0, 24, 115)
        self.assertEqual(set(table.keys()), {0.0, 24.0})
        self.assertEqual(table[0.0][1], 1.0)
        self.assertEqual(table[24.0][1], 0.0)


class TestAuthorCueToolsInComp(unittest.TestCase):
    """One cue -> base Text+ (+ optional overlay) with window-local shifted
    curves, trailing pins, and Blend gates; validation fails before any
    tool is created."""

    def _make_comp(self):
        comp = MagicMock()
        tools = []
        splines = []

        def add_tool(name, *_a, **_k):
            tool = MagicMock()
            tools.append(tool)
            tool.name = name
            return tool

        def bezier(*_a, **_k):
            spline = MagicMock()
            splines.append(spline)
            return spline

        comp.AddTool.side_effect = add_tool
        comp.BezierSpline.side_effect = bezier
        return comp, tools, splines

    def _cue_doc(self, **overrides):
        doc = {
            "clipId": "c001",
            "startFrame": 100,
            "endFrame": 134,
            "text": "grace is not earned",
            "keyframes": {"End": {
                "entries": [{"frame": 0, "value": 0.0},
                            {"frame": 20, "value": 1.0}],
                "isStepped": True,
            }},
            "overlayKeyframes": None,
        }
        doc.update(overrides)
        return doc

    def test_base_tool_authored_with_shifted_curves_and_gate(self):
        comp, tools, splines = self._make_comp()

        resolve_bridge._author_cue_tools_in_comp(
            comp, self._cue_doc(), 100, 115)

        textpluses = [t for t in tools if t.name == "TextPlus"]
        self.assertEqual(len(textpluses), 1)
        base = textpluses[0]
        base.SetInput.assert_any_call("StyledText", "grace is not earned")

        tables = [s.SetKeyFrames.call_args[0][0] for s in splines]
        # End reveal: entries shifted to window-local (offset 0 here) +
        # trailing pin at the cue's last visible local frame (33).
        reveal = next(t for t in tables if set(t.keys()) == {0.0, 20.0, 33.0})
        self.assertEqual(reveal[33.0][1], 1.0)
        # Blend gate: visible exactly [0, 34).
        gate = next(t for t in tables if set(t.keys()) == {0.0, 34.0})
        self.assertEqual(gate[0.0][1], 1.0)
        self.assertEqual(gate[34.0][1], 0.0)
        self.assertNotIn("Blend", base.__dict__)

    def test_curves_shifted_for_late_cue_in_window(self):
        comp, tools, splines = self._make_comp()
        cue = self._cue_doc(startFrame=124, endFrame=148)  # offset 24

        resolve_bridge._author_cue_tools_in_comp(comp, cue, 100, 115)

        tables = [s.SetKeyFrames.call_args[0][0] for s in splines]
        reveal = next(
            t for t in tables if set(t.keys()) == {24.0, 44.0, 47.0})
        self.assertEqual(reveal[24.0][1], 0.0)
        self.assertEqual(reveal[44.0][1], 1.0)
        self.assertEqual(reveal[47.0][1], 1.0)  # trailing pin (last visible)
        gate = next(t for t in tables if set(t.keys()) == {0.0, 24.0, 48.0})
        self.assertEqual((gate[0.0][1], gate[24.0][1], gate[48.0][1]),
                         (0.0, 1.0, 0.0))

    def test_overlay_creates_second_gated_tool(self):
        comp, tools, splines = self._make_comp()
        cue = self._cue_doc(overlayKeyframes={
            "Start": {"entries": [{"frame": 0, "value": 0.0}],
                      "isStepped": True},
            "End": {"entries": [{"frame": 8, "value": 0.55}],
                    "isStepped": True},
        })

        resolve_bridge._author_cue_tools_in_comp(
            comp, cue, 100, 115)

        textpluses = [t for t in tools if t.name == "TextPlus"]
        self.assertEqual(len(textpluses), 2)
        textpluses[1].SetInput.assert_any_call(
            "StyledText", "grace is not earned")
        self.assertEqual(len(splines), 4)  # base End, ov Start+End, gate
        # Reveal splines attach to TextPlus inputs; visibility attaches to the
        # transparent-background Merge that gates the whole cue branch.
        self.assertIs(getattr(textpluses[0], "End"), splines[0])
        self.assertIs(getattr(textpluses[1], "Start"), splines[1])
        self.assertIs(getattr(textpluses[1], "End"), splines[2])
        gate = [t for t in tools if t.name == "Merge"][-1]
        self.assertIs(getattr(gate, "Blend"), splines[3])
        for textplus in textpluses:
            self.assertNotIn("Blend", textplus.__dict__)

    def test_overlay_start_keys_same_frame_as_end_window_local(self):
        """Window-baked executor: the same-frame Start keying (no
        one-frame-early lead) applies in WINDOW-LOCAL frames (after the
        cue offset shift) — Start and End key at the same onset frame."""
        comp, tools, splines = self._make_comp()
        cue = self._cue_doc(startFrame=124, endFrame=158, overlayKeyframes={
            "Start": {"entries": [
                {"frame": 0, "value": 0.0},
                {"frame": 10, "value": 0.3}],
                "isStepped": True},
            "End": {"entries": [
                {"frame": 0, "value": 0.4},
                {"frame": 10, "value": 1.0}],
                "isStepped": True},
        })

        resolve_bridge._author_cue_tools_in_comp(comp, cue, 100, 115)

        # splines: base End, ov Start, ov End, cue gate
        start_table = splines[1].SetKeyFrames.call_args[0][0]
        self.assertEqual(set(start_table.keys()), {24.0, 34.0})
        self.assertEqual(start_table[24.0][1], 0.0)
        # Value leads by half a char cell of the cue text (19 chars).
        self.assertAlmostEqual(start_table[34.0][1], 0.3 - 0.5 / 19)
        end_table = splines[2].SetKeyFrames.call_args[0][0]
        self.assertIn(34.0, end_table)

    def test_overlay_mirrors_base_layout_inputs(self):
        """Window-baked parity with the multi-clip builder: identical layout
        inputs on both layers so the highlight never shifts (zero-movement
        invariant)."""
        comp, tools, splines = self._make_comp()
        cue = self._cue_doc(overlayKeyframes={
            "Start": {"entries": [{"frame": 0, "value": 0.0}],
                      "isStepped": True},
            "End": {"entries": [{"frame": 8, "value": 0.55}],
                    "isStepped": True},
        })

        resolve_bridge._author_cue_tools_in_comp(
            comp, cue, 100, 115)

        base, overlay = [t for t in tools if t.name == "TextPlus"]
        mirrored = [c.args[0] for c in overlay.SetInput.call_args_list
                    if len(c.args) == 2
                    and c.args[0] in resolve_bridge._LAYOUT_MIRROR_INPUTS]
        for name in ("Center", "Pivot", "Size", "Font",
                     "HorizontalLeftCenterRight", "VerticalTopCenterBottom"):
            self.assertIn(name, mirrored)
        # The base tool itself never receives mirror-only inputs.
        base_mirror_only = [
            c.args[0] for c in base.SetInput.call_args_list
            if len(c.args) == 2 and c.args[0] in ("LayoutWidth",
                                                  "LayoutHeight",
                                                  "HorizontalLeftCenterRight")]
        self.assertEqual(base_mirror_only, [])

    def test_plain_reveal_never_mirrors_layout_inputs(self):
        """No overlay -> no mirroring: plain reveal clips keep the original
        single-tool authoring shape."""
        comp, tools, splines = self._make_comp()

        resolve_bridge._author_cue_tools_in_comp(
            comp, self._cue_doc(), 100, 115)

        base = next(t for t in tools if t.name == "TextPlus")
        mirror_only = [c.args[0] for c in base.SetInput.call_args_list
                       if len(c.args) == 2
                       and c.args[0] in resolve_bridge._LAYOUT_MIRROR_INPUTS]
        self.assertEqual(mirror_only, [])

    def test_style_settings_applied_before_content(self):
        comp, tools, splines = self._make_comp()
        settings = {"Font": "Helvetica"}

        resolve_bridge._author_cue_tools_in_comp(
            comp, self._cue_doc(), 100, 115, style_settings=settings)

        base = next(t for t in tools if t.name == "TextPlus")
        calls = [(c[0], c) for c in base.mock_calls]
        load_idx = next(i for i, (n, _) in enumerate(calls)
                        if n.endswith("LoadSettings"))
        text_idx = next(i for i, (n, c) in enumerate(calls)
                        if n.endswith("SetInput") and c.args
                        and c.args[0] == "StyledText")
        base.LoadSettings.assert_called_once_with(settings)
        self.assertLess(load_idx, text_idx)

    def test_missing_end_keyframes_fails_before_any_tool(self):
        comp, tools, splines = self._make_comp()
        cue = self._cue_doc(keyframes={"Start": {
            "entries": [{"frame": 0, "value": 0.0}], "isStepped": True}})

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._author_cue_tools_in_comp(comp, cue, 100, 115)

        self.assertEqual(ctx.exception.code, "missing-keyframes")
        comp.AddTool.assert_not_called()


class TestAuthorWindowBakedClip(unittest.TestCase):
    """One window -> ONE baked Fusion clip named CaptionSuite-W####; all cue
    tools authored inside one undo bracket BEFORE CreateFusionClip; scratch
    track swept afterwards."""

    def _run_author(self, window_clips, window_number=3):
        mgr = MagicMock()
        comp = mgr.comp
        mgr.media_out.ID = "MediaOut"
        # Snapshot MediaOut's Input so tests can prove whether it was
        # rewired (attribute assignment, not SetInput).
        mgr.media_out_input_before = mgr.media_out.Input
        created_tools = []
        mgr.created_tools = created_tools
        comp.GetToolList.return_value = {9: mgr.media_out}

        def add_tool(name, *_a, **_k):
            tool = MagicMock()
            created_tools.append((name, tool))
            setattr(mgr, f"tool_{len(mgr.mock_calls)}", tool)
            return tool

        comp.AddTool.side_effect = add_tool

        timeline = mgr.timeline
        timeline.InsertFusionTitleIntoTimeline.return_value = mgr.title_item
        mgr.title_item.GetFusionCompByIndex.return_value = comp
        timeline.CreateFusionClip.return_value = mgr.baked_item
        mgr.baked_item.GetMediaPoolItem.return_value = mgr.pool_item
        timeline.GetItemListInTrack.return_value = [mgr.title_item]

        media_pool, bin_folder = MagicMock(), MagicMock()

        name = resolve_bridge._author_window_baked_clip(
            timeline, 1, media_pool, bin_folder, window_clips, window_number)
        return mgr, timeline, comp, name

    def _window(self):
        def cue(i):
            return {
                "clipId": f"c{i}",
                "startFrame": i * 24,
                "endFrame": (i + 1) * 24,
                "text": f"cue {i}",
                "keyframes": {"End": {"entries": [{"frame": 0, "value": 0.0}],
                                      "isStepped": True}},
            }
        return [cue(0), cue(1)]

    def test_bakes_one_clip_with_w_marker(self):
        mgr, timeline, comp, name = self._run_author(self._window())
        self.assertEqual(name, "CaptionSuite-W0003")
        mgr.pool_item.SetClipProperty.assert_called_once_with(
            "Clip Name", "CaptionSuite-W0003")
        timeline.CreateFusionClip.assert_called_once_with([mgr.title_item])

    def test_final_merge_feeds_media_out(self):
        """Every cue tool must be merged into ONE chain that MediaOut
        consumes — orphaned tools never render (invisible-highlight root
        cause). Two cues -> chain of 3 tools -> 2 Merges; MediaOut gets the
        last Merge. Wiring must use Output-attribute assignment (SetInput
        with a tool object is a fail-quiet no-op on 21.0.4.5)."""
        window = self._window()
        overlay_window = [dict(c, overlayKeyframes={
            "Start": {"entries": [{"frame": 0, "value": 0.0}],
                      "isStepped": True},
            "End": {"entries": [{"frame": 0, "value": 0.5}],
                    "isStepped": True},
        }) for c in window]
        mgr, _, comp, _ = self._run_author(overlay_window)

        # 2 cues with overlays -> 5 Merges: one base/overlay Merge and one
        # transparent visibility-gate Merge per cue, plus the outer chain
        # Merge that adds cue 2 to cue 1.
        merges = [t for name, t in mgr.created_tools if name == "Merge"]
        self.assertEqual(len(merges), 5)
        # MediaOut.Input was rewired exactly once — to the LAST Merge's
        # Output — and never via the broken SetInput shape.
        self.assertIs(mgr.media_out.Input, merges[-1].Output)
        self.assertIsNot(mgr.media_out.Input, mgr.media_out_input_before)
        mgr.media_out.SetInput.assert_not_called()

    def test_undo_bracket_wraps_all_cues_before_bake(self):
        mgr, timeline, comp, _ = self._run_author(self._window())
        calls = [c[0] for c in mgr.mock_calls]
        start = calls.index("comp.StartUndo")
        end = calls.index("comp.EndUndo")
        bake = calls.index("timeline.CreateFusionClip")
        self.assertLess(start, end)
        self.assertLess(end, bake)
        comp.StartUndo.assert_called_once_with("Animate window 3")
        comp.EndUndo.assert_called_with(False)

    def test_scratch_track_swept_even_on_success(self):
        mgr, timeline, _, _ = self._run_author(self._window())
        timeline.DeleteClips.assert_called_once_with([mgr.title_item], False)

    def test_unreachable_comp_structured_error(self):
        timeline = MagicMock()
        item = MagicMock()
        item.GetFusionCompByIndex.return_value = None
        timeline.InsertFusionTitleIntoTimeline.return_value = item

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._author_window_baked_clip(
                timeline, 1, MagicMock(), MagicMock(), self._window(), 1)
        self.assertEqual(ctx.exception.code, "no-comp")


class TestAuthorPersistentTitle(unittest.TestCase):
    """mode_author_persistent_title: response shape, progress cadence, token
    errors, window-granular checkpoints/resume, and W-prefix markers."""

    TOKEN = "fake-composite-token"
    TIMELINE_ID = "tl-persistent-test"

    def setUp(self):
        self.runstate_dir = tempfile.mkdtemp(prefix="capproj-persistent-")
        self.addCleanup(shutil.rmtree, self.runstate_dir, ignore_errors=True)

    def _checkpoint_file(self):
        return os.path.join(self.runstate_dir, f"{self.TIMELINE_ID}.json")

    def _read_checkpoint(self):
        with open(self._checkpoint_file(), encoding="utf-8") as fh:
            return json.load(fh)

    def _write_checkpoint(self, windows, window_ids, token=TOKEN,
                          media_ids=None, clip_hashes=None):
        ckpt = {
            "completedWindows": windows,
            "completedLines": windows,
            "completedClipIds": window_ids,
            "lastToken": token,
            "lastCheckpointAt": "2026-08-25T12:00:00Z",
            "pid": 12345,
        }
        if media_ids is not None:
            ckpt["binMediaIds"] = media_ids
        if clip_hashes is not None:
            ckpt["clipHashes"] = clip_hashes
        with open(self._checkpoint_file(), "w", encoding="utf-8") as fh:
            json.dump(ckpt, fh)

    def _make_request(self, clip_count=6, resume=False, token=TOKEN,
                      document=True, **extra):
        clips = [
            {
                "clipId": f"c{i:03d}",
                "startFrame": i * 24,
                "endFrame": (i + 1) * 24,
                "text": f"line {i}",
                "keyframes": {"End": {
                    "entries": [{"frame": 0, "value": 0.5}],
                    "isStepped": True,
                }},
                "overlayKeyframes": None,
            }
            for i in range(clip_count)
        ]
        payload = {
            "expectedToken": token,
            "trackName": "Animate",
            "binName": "CaptionSuite",
        }
        if document:
            payload["animationDocument"] = {"formatVersion": 1,
                                            "clips": clips}
        if resume:
            payload["resume"] = True
            payload["runstateDir"] = self.runstate_dir
            payload["timelineId"] = self.TIMELINE_ID
        payload.update(extra)
        return payload

    def _make_env(self, mock_open, mock_load, mock_verify, window_count=2):
        """Resolve API mocks shaped like the multi-clip executor tests. With
        6 x 24-frame cues and the default 115-frame cap, packing yields two
        windows ([cues 1-4], [cues 5-6]) — pass window_count matching."""
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_verify.side_effect = lambda *a, **k: True

        tracks = ["Video 1"]
        timeline.GetTrackCount.side_effect = lambda _t: len(tracks)
        timeline.GetTrackName.side_effect = lambda _t, idx: tracks[idx - 1]
        timeline.AddTrack.side_effect = lambda _t: (
            tracks.append(f"Video {len(tracks) + 1}"), True)[1]
        timeline.SetTrackName.side_effect = lambda _t, i, n: (
            tracks.__setitem__(i - 1, n), True)[1]
        state = {"items": []}
        timeline.GetItemListInTrack.side_effect = (
            lambda _t, idx: list(state["items"]) if idx == len(tracks) else [])
        timeline.DeleteClips.side_effect = lambda clips, *_a, **_k: (
            state.__setitem__(
                "items",
                [c for c in state["items"]
                 if id(c) not in {id(x) for x in clips}]),
            True)[1]

        media_pool = MagicMock()
        project.GetMediaPool.return_value = media_pool
        root = MagicMock()
        root.GetSubFolderList.return_value = []
        media_pool.GetRootFolder.return_value = root
        bin_folder = MagicMock()
        media_pool.AddSubFolder.return_value = bin_folder

        clips_by_name = {}

        def get_bin_clips():
            return list(clips_by_name.values())

        bin_folder.GetClipList.side_effect = get_bin_clips

        def bake_side_effect(_tl, _ti, _pool, _folder, _win, win_num,
                             **_kw):
            name = f"CaptionSuite-W{win_num:04d}"
            clip = MagicMock()
            clip.GetName.return_value = name
            clips_by_name[name] = clip
            return name

        placed_items = []

        def append_to_timeline(infos):
            made = [_named_placed_timeline_item() for _ in infos]
            placed_items.extend(made)
            return made

        media_pool.AppendToTimeline.side_effect = append_to_timeline

        scratch = MagicMock()
        media_pool.CreateEmptyTimeline.return_value = scratch
        project.SetCurrentTimeline.return_value = True

        return {
            "project": project, "timeline": timeline,
            "media_pool": media_pool, "bin_folder": bin_folder,
            "clips_by_name": clips_by_name, "track_state": state,
            "bake_side_effect": bake_side_effect,
            "placed_items": placed_items,
        }

    def test_scratch_switch_failure_cleans_up(self):
        project = MagicMock()
        project.SetCurrentTimeline.return_value = False
        media_pool = MagicMock()
        scratch = MagicMock()
        media_pool.CreateEmptyTimeline.return_value = scratch

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._setup_scratch_timeline(project, media_pool, None)

        self.assertEqual(ctx.exception.code, "scratch-timeline-failed")
        media_pool.DeleteTimelines.assert_called_once_with([scratch])

    def test_post_bake_placement_failure_preserves_reconciliation_state(self):
        with patch("resolve_bridge._timeline_identity") as mock_identity, \
             patch("resolve_bridge._author_window_baked_clip") as mock_author, \
             patch("resolve_bridge.verify_token") as mock_verify, \
             patch("resolve_bridge.load_resolve") as mock_load, \
             patch("resolve_bridge.open_project_timeline") as mock_open:
            mock_identity.return_value = (
                {"compositeToken": self.TOKEN}, 24.0, 0)
            env = self._make_env(mock_open, mock_load, mock_verify,
                                 window_count=1)
            mock_author.side_effect = env["bake_side_effect"]
            env["media_pool"].AppendToTimeline.side_effect = lambda _infos: []

            result, _ = self._run(self._make_request(clip_count=1))

        self.assertEqual(result["error"]["code"], "placement-incomplete")
        self.assertEqual(result["error"]["resumableAt"], 1)
        # A baked pool item is deliberately left for the existing checkpoint
        # and reconciliation path; this failure does not claim rollback.
        env["media_pool"].DeleteClips.assert_not_called()

    def _run(self, request):
        f = io.StringIO()
        with redirect_stdout(f):
            try:
                result = resolve_bridge.mode_author_persistent_title(request)
            except resolve_bridge.BridgeFailure as exc:
                result = {"error": dict(exc.extra,
                                        code=exc.code, message=exc.message)}
        events = [
            json.loads(line)
            for line in f.getvalue().strip().split("\n") if line.strip()
        ]
        return result, events

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_success_shape_and_two_windows(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        env = self._make_env(mock_open, mock_load, mock_verify)
        mock_author.side_effect = env["bake_side_effect"]

        result, _ = self._run(self._make_request())

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["windowCount"], 2)
        self.assertEqual(result["clipCount"], 6)
        self.assertEqual(result["bakedClipNames"],
                         ["CaptionSuite-W0001", "CaptionSuite-W0002"])
        self.assertEqual(result["resumedFrom"], 0)
        self.assertIn("avgWindowBakeMs", result)
        self.assertEqual(mock_author.call_count, 2)

    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_window_heartbeats_identify_windows(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """Window executor heartbeats use window granularity on the wire."""
        env = self._make_env(mock_open, mock_load, mock_verify)
        mock_author.side_effect = env["bake_side_effect"]

        with patch.object(resolve_bridge, "HEARTBEAT_SECONDS", 0):
            result, events = self._run(self._make_request())

        self.assertEqual(result["status"], "done")
        beats = [event for event in events if event.get("event") == "heartbeat"]
        self.assertTrue(beats)
        self.assertTrue(all("window" in beat for beat in beats))
        self.assertTrue(all("line" not in beat for beat in beats))

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_resume_or_reuse_without_runstate_dir_fails_loud(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        """L3 (window executor): resume/reuseCheckpoint without runstateDir
        is a structured error, never a silent full re-author."""
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        self._make_env(mock_open, mock_load, mock_verify)

        payload = self._make_request(resume=True)
        del payload["runstateDir"]
        result, _ = self._run(payload)
        self.assertEqual(result["error"]["code"],
                         "resume-requires-runstate-dir")

        payload = self._make_request()
        payload["reuseCheckpoint"] = True
        result, _ = self._run(payload)
        self.assertEqual(result["error"]["code"],
                         "resume-requires-runstate-dir")

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_placement_frame_exact_with_w_markers(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        env = self._make_env(mock_open, mock_load, mock_verify)
        mock_author.side_effect = env["bake_side_effect"]

        result, _ = self._run(self._make_request())

        self.assertEqual(result["placedCount"], 2)
        infos = env["media_pool"].AppendToTimeline.call_args[0][0]
        # Window 1: cues 1-4 -> frames 0..96; Window 2: cues 5-6 -> 96..144.
        self.assertEqual(infos[0]["recordFrame"], 0)
        self.assertEqual(infos[0]["endFrame"], 96)
        self.assertEqual(infos[0]["trackIndex"], 2)
        self.assertEqual(infos[1]["recordFrame"], 96)
        self.assertEqual(infos[1]["endFrame"], 48)
        # Ownership markers: each placed instance is renamed with the W
        # prefix (TimelineItem.SetName route — bin-side rename is a no-op).
        self.assertEqual(
            [item.SetName.call_args[0][0] for item in env["placed_items"]],
            ["CaptionSuite-W0001", "CaptionSuite-W0002"],
        )

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_placement_phase_rechecks_identity_after_baking(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        """A timeline edit during scratch authoring aborts before placement."""
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        env = self._make_env(mock_open, mock_load, mock_verify)
        mock_author.side_effect = env["bake_side_effect"]
        calls = 0

        def verify(*_args, **_kwargs):
            nonlocal calls
            calls += 1
            # Initial target check + one check per each of two windows all
            # pass. The explicit placement-boundary check detects the drift.
            if calls == 4:
                raise resolve_bridge.BridgeFailure(
                    "token-mismatch", "timeline changed during authoring")

        mock_verify.side_effect = verify
        result, _ = self._run(self._make_request())

        self.assertEqual(result["error"]["code"], "token-mismatch")
        self.assertEqual(mock_author.call_count, 2)
        env["media_pool"].AppendToTimeline.assert_not_called()

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_progress_lines_per_window(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        env = self._make_env(mock_open, mock_load, mock_verify)
        mock_author.side_effect = env["bake_side_effect"]

        _, events = self._run(self._make_request())

        bakes = [e for e in events if e.get("step") == "baking-window"]
        self.assertEqual(
            bakes,
            [
                {"event": "progress", "step": "baking-window",
                 "pct": round(1 / 2, 4), "window": 1, "total": 2},
                {"event": "progress", "step": "baking-window",
                 "pct": round(2 / 2, 4), "window": 2, "total": 2},
            ],
        )
        self.assertEqual(events[-1]["step"], "done")

    def test_missing_document_structured_error(self):
        result, _ = self._run(self._make_request(document=False))
        self.assertEqual(result["error"]["code"], "missing-document")

    def test_invalid_document_json_structured_error(self):
        result, _ = self._run({"expectedToken": self.TOKEN,
                               "animationDocument": "{nope"})
        self.assertEqual(result["error"]["code"], "invalid-document")

    @patch("resolve_bridge.load_resolve")
    def test_missing_token_structured_error(self, mock_load):
        resolve = MagicMock()
        resolve.GetVersionString.return_value = "20.0"
        pm = MagicMock()
        pm.GetCurrentProject.return_value = MagicMock()
        resolve.GetProjectManager.return_value = pm
        mock_load.return_value = resolve

        req = self._make_request()
        del req["expectedToken"]
        result, _ = self._run(req)
        self.assertEqual(result["error"]["code"], "token-missing")

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_token_mismatch_structured_error(
        self, mock_open, mock_load, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": "real-composite-token"}, 24.0, 0)
        env = self._make_env(
            mock_open, mock_load, MagicMock(return_value=None))
        result, _ = self._run(self._make_request(token="stale-token"))
        self.assertEqual(result["error"]["code"], "token-mismatch")

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_checkpoints_written_per_window(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        env = self._make_env(mock_open, mock_load, mock_verify)

        observed = []

        def bake(timeline, ti, pool, folder, win, win_num, **kw):
            if os.path.exists(self._checkpoint_file()):
                observed.append(
                    self._read_checkpoint()["completedWindows"])
            else:
                observed.append(None)
            return env["bake_side_effect"](
                timeline, ti, pool, folder, win, win_num, **kw)

        mock_author.side_effect = bake
        result, _ = self._run(self._make_request(resume=False, **{
            "runstateDir": self.runstate_dir,
            "timelineId": self.TIMELINE_ID,
        }))

        self.assertEqual(result["status"], "done")
        self.assertEqual(observed, [0, 1])
        final = self._read_checkpoint()
        self.assertEqual(final["completedWindows"], 2)
        self.assertEqual(final["completedClipIds"],
                         ["CaptionSuite-W0001", "CaptionSuite-W0002"])
        self.assertEqual(final["lastToken"], self.TOKEN)
        self.assertEqual(result["checkpointPath"], self._checkpoint_file())

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_resume_reuses_checkpoint_skips_done_windows(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        env = self._make_env(mock_open, mock_load, mock_verify)
        committed_clip = MagicMock(
            **{"GetName.return_value": "CaptionSuite-W0001"})
        env["clips_by_name"]["CaptionSuite-W0001"] = committed_clip
        mock_author.side_effect = env["bake_side_effect"]
        # Real window-content hash of window 1 so prefix-hash validation
        # (M4) passes: same packing as the executor (6 x 24-frame cues,
        # default 4.8 s cap at 24 fps -> [cues 1-4], [cues 5-6]).
        clips = [
            {
                "clipId": f"c{i:03d}",
                "startFrame": i * 24,
                "endFrame": (i + 1) * 24,
                "text": f"line {i}",
                "keyframes": {"End": {
                    "entries": [{"frame": 0, "value": 0.5}],
                    "isStepped": True,
                }},
                "overlayKeyframes": None,
            }
            for i in range(6)
        ]
        windows = resolve_bridge._pack_windows(
            clips, resolve_bridge.DEFAULT_MAX_WINDOW_SECONDS, 24.0)
        self._write_checkpoint(
            1, ["CaptionSuite-W0001"],
            media_ids=[str(committed_clip.GetMediaId())],
            clip_hashes=[resolve_bridge._window_content_hash(windows[0])])

        result, _ = self._run(self._make_request(resume=True))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["resumedFrom"], 1)
        self.assertEqual(result["windowCount"], 2)
        self.assertEqual(mock_author.call_count, 1)
        # Only window 2 was authored.
        self.assertEqual(mock_author.call_args.args[5], 2)
        final = self._read_checkpoint()
        self.assertEqual(final["completedWindows"], 2)

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_resume_checkpoint_token_mismatch_refuses(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        self._make_env(mock_open, mock_load, mock_verify)
        self._write_checkpoint(1, ["CaptionSuite-W0001"],
                               token="stale-token")

        result, _ = self._run(self._make_request(resume=True))

        self.assertEqual(result["error"]["code"],
                         "token-mismatch-checkpoint")
        mock_author.assert_not_called()

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_resume_window_hash_mismatch_falls_back_to_full_run(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        """M4 (window granularity): a document that changed over the
        checkpoint's committed windows invalidates the resume — no baked
        franken-window of old cues under new content; full re-author."""
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        env = self._make_env(mock_open, mock_load, mock_verify)
        committed_clip = MagicMock(
            **{"GetName.return_value": "CaptionSuite-W0001"})
        env["clips_by_name"]["CaptionSuite-W0001"] = committed_clip

        calls = []

        def bake(*args, **kwargs):
            calls.append(args[5])
            return env["bake_side_effect"](*args, **kwargs)

        mock_author.side_effect = bake
        self._write_checkpoint(
            1, ["CaptionSuite-W0001"],
            media_ids=[str(committed_clip.GetMediaId())],
            clip_hashes=["stale-window-hash"])

        result, events = self._run(self._make_request(resume=True))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["resumedFrom"], 0)
        self.assertEqual(calls, [1, 2])
        self.assertTrue(
            any(e.get("step") == "resume-invalidated" and
                e.get("reason") == "prefix-hash-mismatch" for e in events))
        self.assertEqual(self._read_checkpoint()["completedWindows"], 2)

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_exception_midloop_reports_resumable_window(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        env = self._make_env(mock_open, mock_load, mock_verify)

        calls = []

        def bake(*args, **kwargs):
            calls.append(args[5])
            if len(calls) == 2:
                raise RuntimeError("Resolve exploded mid-window")
            return env["bake_side_effect"](*args, **kwargs)

        mock_author.side_effect = bake
        result, _ = self._run(self._make_request(**{
            "runstateDir": self.runstate_dir,
            "timelineId": self.TIMELINE_ID,
        }))

        self.assertEqual(result["error"]["code"], "execution-failed")
        self.assertEqual(result["error"]["resumableAt"], 1)
        self.assertEqual(self._read_checkpoint()["completedWindows"], 1)


# ---------------------------------------------------------------------------
# Ownership prefix generalization (L and W markers clear/reconcile together)
# ---------------------------------------------------------------------------

class TestOwnedPrefixGeneralization(unittest.TestCase):
    """Cleanup helpers must target BOTH marker families: a user switching
    between the multi-clip and persistent-title models must never inherit
    stale work from the other."""

    def _run_clear(self, prefixes):
        timeline = MagicMock()
        l_item = MagicMock(**{"GetName.return_value": "CaptionSuite-L0001"})
        w_item = MagicMock(**{"GetName.return_value": "CaptionSuite-W0001"})
        foreign = MagicMock(**{"GetName.return_value": "My B-roll"})
        scans = [[l_item, w_item, foreign]]
        timeline.GetItemListInTrack.side_effect = (
            lambda _t, _i: list(scans.pop(0) if scans else []))
        deleted = []

        def delete(clips, *_a, **_k):
            deleted.extend(clips)
            return True

        timeline.DeleteClips.side_effect = delete
        cleared = resolve_bridge._clear_owned_clips(
            timeline, 1, prefixes=prefixes)
        return cleared, deleted, foreign

    def test_default_prefixes_clear_both_families(self):
        cleared, deleted, foreign = self._run_clear(
            resolve_bridge.OWNED_PREFIXES)
        self.assertEqual(cleared, 2)
        self.assertNotIn(foreign, deleted)

    def test_line_only_prefix_leaves_windows_alone(self):
        cleared, deleted, _ = self._run_clear(("CaptionSuite-L",))
        self.assertEqual(cleared, 1)
        self.assertTrue(all(
            getattr(c, "GetName", lambda: "")().startswith("CaptionSuite-L")
            for c in deleted))


# ---------------------------------------------------------------------------
# Captured style wiring (stylePayload / stylePath -> LoadSettings)
# ---------------------------------------------------------------------------

class TestApplyCapturedStyle(unittest.TestCase):
    """_apply_captured_style: LoadSettings replay + A5 tool re-location by
    position/role (never by remembered name)."""

    def test_loads_settings_and_keeps_same_handle(self):
        tool = MagicMock()
        tool.ID = "TextPlus"
        comp = MagicMock()
        comp.GetToolList.return_value = {1: tool}

        out = resolve_bridge._apply_captured_style(
            comp, tool, {"Font": "Arial"}, "ctx")

        tool.LoadSettings.assert_called_once_with({"Font": "Arial"})
        self.assertIs(out, tool)

    def test_relocates_by_position_after_load(self):
        """A5 live finding: Fusion may rename/re-register tools after
        LoadSettings(); the same tool-list POSITION wins."""
        old = MagicMock()
        new = MagicMock()
        new.ID = "TextPlus"
        comp = MagicMock()
        # Snapshot before the load vs the list after it.
        comp.GetToolList.side_effect = [{2: old}, {2: new}]

        out = resolve_bridge._apply_captured_style(comp, old, {}, "ctx")

        self.assertIs(out, new)

    def test_relocates_by_role_when_position_changes(self):
        old = MagicMock()
        role_match = MagicMock()
        role_match.ID = "TextPlus"
        spline = MagicMock()
        spline.ID = "BezierSpline"
        comp = MagicMock()
        comp.GetToolList.side_effect = [{1: old}, {3: spline, 4: role_match}]

        out = resolve_bridge._apply_captured_style(comp, old, {}, "ctx")

        self.assertIs(out, role_match)

    def test_no_textplus_left_after_load_structured_error(self):
        old = MagicMock()
        merge = MagicMock()
        merge.ID = "Merge"
        comp = MagicMock()
        comp.GetToolList.side_effect = [{1: old}, {1: merge}]

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._apply_captured_style(comp, old, {}, "ctx")
        self.assertEqual(ctx.exception.code, "textplus-relocate-failed")

    def test_load_exception_is_structured(self):
        tool = MagicMock()
        tool.LoadSettings.side_effect = RuntimeError("fusion exploded")
        comp = MagicMock()
        comp.GetToolList.return_value = {1: tool}

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._apply_captured_style(comp, tool, {}, "ctx")
        self.assertEqual(ctx.exception.code, "style-load-failed")


class TestRequestLevelStyle(unittest.TestCase):
    """stylePayload / stylePath request fields flow into both executors'
    authoring calls; malformed input fails loud BEFORE any mutation."""

    TOKEN = "fake-composite-token"

    PAYLOAD = {
        "Font": "Impact",
        "Style": "Bold",
        "CharacterSpacingX": 1.25,
    }

    def _multi_env_and_request(self, mock_open, mock_load, mock_verify,
                               **extra):
        helper = TestAuthorTextplusExecute()
        env = helper._make_env(mock_open, mock_load, mock_verify,
                               clip_count=1)
        clips = [{
            "startFrame": 0,
            "endFrame": 24,
            "text": "line",
            "keyframes": {"End": {
                "entries": [{"frame": 0, "value": 0.5}],
                "isStepped": True,
            }},
            "overlayKeyframes": None,
        }]
        payload = {
            "expectedToken": self.TOKEN,
            "animationDocument": json.dumps({"clips": clips}),
            "execute": True,
        }
        payload.update(extra)
        return env, json.dumps(payload)

    def _run_author_textplus(self, request_json):
        f = io.StringIO()
        with redirect_stdout(f):
            try:
                return resolve_bridge.author_textplus(request_json)
            except resolve_bridge.BridgeFailure as exc:
                return {"error": dict(exc.extra, code=exc.code,
                                      message=exc.message)}

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_multi_clip_style_payload_forwarded(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        mock_author.side_effect = ["CaptionSuite-L0001"]
        self._multi_env_and_request(
            mock_open, mock_load, mock_verify,
            stylePayload=self.PAYLOAD)

        result = self._run_author_textplus(json.dumps({
            "expectedToken": self.TOKEN,
            "animationDocument": json.dumps({"clips": [{
                "startFrame": 0, "endFrame": 24, "text": "line",
                "keyframes": {"End": {"entries": [
                    {"frame": 0, "value": 0.5}], "isStepped": True}},
                "overlayKeyframes": None,
            }]}),
            "execute": True,
            "stylePayload": self.PAYLOAD,
        }))

        self.assertEqual(result["status"], "done")
        self.assertEqual(
            mock_author.call_args.kwargs.get("request_style"), self.PAYLOAD)

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_no_style_keeps_request_style_none(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        mock_author.side_effect = ["CaptionSuite-L0001"]
        _, request_json = self._multi_env_and_request(
            mock_open, mock_load, mock_verify)

        result = self._run_author_textplus(request_json)

        self.assertEqual(result["status"], "done")
        self.assertIsNone(mock_author.call_args.kwargs.get("request_style"))

    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_malformed_style_payload_structured_error(
        self, mock_open, mock_load, mock_verify,
    ):
        with patch("resolve_bridge._author_clip_on_track") as mock_author:
            _, request_json = self._multi_env_and_request(
                mock_open, mock_load, mock_verify, stylePayload="not-an-object")

            result = self._run_author_textplus(request_json)

        self.assertEqual(result["error"]["code"], "bad-style-payload")
        mock_author.assert_not_called()

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_style_path_reads_preset_file_layout(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        """Convenience form: the bridge reads the .capproj preset file itself
        ({id, name, createdAt, settings, ...}) and extracts `settings`."""
        mock_author.side_effect = ["CaptionSuite-L0001"]
        preset_path = os.path.join(
            tempfile.mkdtemp(prefix="capproj-style-"), "preset.json")
        with open(preset_path, "w", encoding="utf-8") as fh:
            json.dump({
                "id": "ABCD-1234",
                "name": "Sunday Title",
                "createdAt": "2026-08-25T00:00:00Z",
                "settings": self.PAYLOAD,
                "thumbnailDescription": None,
            }, fh)
        self.addCleanup(shutil.rmtree, os.path.dirname(preset_path),
                        ignore_errors=True)

        _, request_json = self._multi_env_and_request(
            mock_open, mock_load, mock_verify, stylePath=preset_path)

        result = self._run_author_textplus(request_json)

        self.assertEqual(result["status"], "done")
        forwarded = mock_author.call_args.kwargs.get("request_style")
        self.assertEqual(forwarded, self.PAYLOAD)

    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_missing_style_path_structured_error(
        self, mock_open, mock_load, mock_verify, mock_author,
    ):
        _, request_json = self._multi_env_and_request(
            mock_open, mock_load, mock_verify,
            stylePath="/nonexistent/styles/ghost.json")

        result = self._run_author_textplus(request_json)

        self.assertEqual(result["error"]["code"], "style-path-unreadable")
        mock_author.assert_not_called()

    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    @patch("resolve_bridge._timeline_identity")
    def test_persistent_title_style_payload_forwarded(
        self, mock_identity, mock_open, mock_load, mock_verify, mock_author,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        helper = TestAuthorPersistentTitle()
        env = helper._make_env(mock_open, mock_load, mock_verify)
        mock_author.side_effect = env["bake_side_effect"]

        request = helper._make_request(stylePayload=self.PAYLOAD)
        result, _ = helper._run(request)

        self.assertEqual(result["status"], "done")
        self.assertEqual(
            mock_author.call_args.kwargs.get("style_settings"), self.PAYLOAD)

    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    @patch("resolve_bridge._timeline_identity")
    def test_persistent_title_document_settings_win_over_request_payload(
        self, mock_identity, mock_open, mock_load, mock_verify, mock_author,
    ):
        """Precedence (documented): a document-embedded styleSettings is more
        specific than the request-level captured preset and wins."""
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        doc_settings = {"Font": "Embedded"}
        helper = TestAuthorPersistentTitle()
        env = helper._make_env(mock_open, mock_load, mock_verify)
        mock_author.side_effect = env["bake_side_effect"]

        request = helper._make_request(stylePayload=self.PAYLOAD)
        # The composer embeds a per-document styleSettings alongside clips.
        request["animationDocument"]["styleSettings"] = doc_settings
        result, _ = helper._run(request)

        self.assertEqual(result["status"], "done")
        self.assertEqual(
            mock_author.call_args.kwargs.get("style_settings"), doc_settings)


class TestMultiClipStyleOrdering(unittest.TestCase):
    """Call-order contract inside per-line authoring: LoadSettings FIRST,
    then StyledText/Start, then modifier STRIP (removing any spline state
    the load brought in), then OUR splines attach — keyframes always win."""

    def test_order_load_text_strip_attach(self):
        mgr = MagicMock()
        comp, tool, spline = mgr.comp, mgr.tool, mgr.spline
        tool.ID = "TextPlus"
        comp.GetToolList.return_value = {1: tool}
        comp.AddTool.side_effect = lambda name, *a, **k: mgr.overlay_tool
        comp.BezierSpline.side_effect = lambda *a, **k: spline

        timeline = mgr.timeline
        timeline.InsertFusionTitleIntoTimeline.return_value = mgr.title_item
        mgr.title_item.GetFusionCompByIndex.return_value = comp
        timeline.CreateFusionClip.return_value = mgr.baked_item
        mgr.baked_item.GetMediaPoolItem.return_value = mgr.pool_item
        timeline.GetItemListInTrack.return_value = [mgr.title_item]

        clip_doc = {
            "startFrame": 100,
            "endFrame": 124,
            "text": "styled line",
            "styleSettings": {"Font": "Impact"},
            "keyframes": {"End": {
                "entries": [{"frame": 0, "value": 0.5}],
                "isStepped": True,
            }},
            "overlayKeyframes": None,
        }

        resolve_bridge._author_clip_on_track(
            timeline, 1, MagicMock(), MagicMock(), clip_doc, 1)

        calls = [(c[0], c) for c in mgr.mock_calls]
        load_idx = next(i for i, (n, _) in enumerate(calls)
                        if n == "tool.LoadSettings")
        text_idx = next(i for i, (n, c) in enumerate(calls)
                        if n == "tool.SetInput" and c.args
                        and c.args[0] == "StyledText")
        strip_idx = next(i for i, (n, _) in enumerate(calls)
                         if n.endswith("GetConnectedOutput"))
        attach_idx = next(i for i, (n, c) in enumerate(calls)
                          if n == "comp.BezierSpline")
        tool.LoadSettings.assert_called_once_with({"Font": "Impact"})
        self.assertLess(load_idx, text_idx)
        self.assertLess(text_idx, strip_idx)
        self.assertLess(strip_idx, attach_idx)


# ---------------------------------------------------------------------------
# Proofread-edit prefix reuse (reuseCheckpoint: true) — both executors
# ---------------------------------------------------------------------------

class TestReuseCheckpointMultiClip(unittest.TestCase):
    """reuseCheckpoint:true re-runs reuse the baked+placed PREFIX of
    unchanged clips and only clear/re-author the changed suffix."""

    TOKEN = "fake-composite-token"
    TIMELINE_ID = "tl-reuse-test"

    def setUp(self):
        self.runstate_dir = tempfile.mkdtemp(prefix="capproj-reuse-")
        self.addCleanup(shutil.rmtree, self.runstate_dir, ignore_errors=True)

    def _checkpoint_file(self):
        return os.path.join(self.runstate_dir, f"{self.TIMELINE_ID}.json")

    def _write_checkpoint(self, clip_ids, clip_hashes=None, token=TOKEN):
        data = {
            "completedLines": len(clip_ids),
            "completedClipIds": clip_ids,
            "lastToken": token,
            "lastCheckpointAt": "2026-08-25T12:00:00Z",
            "pid": 12345,
        }
        if clip_hashes is not None:
            data["clipHashes"] = clip_hashes
        with open(self._checkpoint_file(), "w", encoding="utf-8") as fh:
            json.dump(data, fh)

    def _read_checkpoint(self):
        with open(self._checkpoint_file(), encoding="utf-8") as fh:
            return json.load(fh)

    @staticmethod
    def _clips(texts):
        return [
            {
                "clipId": f"c{i:03d}",
                "startFrame": i * 24,
                "endFrame": (i + 1) * 24,
                "text": text,
                "keyframes": {"End": {
                    "entries": [{"frame": 0, "value": 0.5}],
                    "isStepped": True,
                }},
                "overlayKeyframes": None,
            }
            for i, text in enumerate(texts)
        ]

    def _make_request(self, clips, **extra):
        payload = {
            "expectedToken": self.TOKEN,
            "animationDocument": json.dumps({"clips": clips}),
            "execute": True,
            "runstateDir": self.runstate_dir,
            "timelineId": self.TIMELINE_ID,
            "reuseCheckpoint": True,
        }
        payload.update(extra)
        return json.dumps(payload)

    @staticmethod
    def _placed_marker(name):
        item = MagicMock()
        item.GetName.return_value = name
        return item

    def _make_env(self, mock_open, mock_load, mock_verify, track_items=None,
                  bin_names=None):
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_verify.side_effect = lambda *a, **k: True

        tracks = ["Video 1"]
        timeline.GetTrackCount.side_effect = lambda _t: len(tracks)
        timeline.GetTrackName.side_effect = lambda _t, idx: tracks[idx - 1]
        timeline.AddTrack.side_effect = lambda _t: (
            tracks.append(f"Video {len(tracks) + 1}"), True)[1]
        timeline.SetTrackName.side_effect = lambda _t, i, n: (
            tracks.__setitem__(i - 1, n), True)[1]
        state = {"items": list(track_items or [])}
        timeline.GetItemListInTrack.side_effect = (
            lambda _t, idx: list(state["items"]) if idx == len(tracks) else [])
        timeline.DeleteClips.side_effect = lambda clips, *_a, **_k: (
            state.__setitem__(
                "items",
                [c for c in state["items"]
                 if id(c) not in {id(x) for x in clips}]),
            True)[1]

        media_pool = MagicMock()
        project.GetMediaPool.return_value = media_pool
        root = MagicMock()
        root.GetSubFolderList.return_value = []
        media_pool.GetRootFolder.return_value = root
        bin_folder = MagicMock()
        media_pool.AddSubFolder.return_value = bin_folder

        clips_by_name = {}

        def make_bin_clip(name):
            clip = MagicMock()
            clip.GetName.return_value = name
            clip.GetMediaId.return_value = 9000 + abs(hash(name)) % 1000
            return clip

        for name in (bin_names or []):
            clips_by_name[name] = make_bin_clip(name)
        bin_folder.GetClipList.side_effect = (
            lambda: list(clips_by_name.values()))
        media_pool.DeleteClips.return_value = True

        placed_items = []

        def append_to_timeline(infos):
            # Placement targets the CURRENT timeline (the bridge switched
            # back to the target before placing) — mirror that on the fake
            # track so reuse tests can assert preserved vs replaced items.
            made = [_named_placed_timeline_item() for _ in infos]
            state["items"].extend(made)
            placed_items.extend(made)
            return made

        media_pool.AppendToTimeline.side_effect = append_to_timeline

        scratch = MagicMock()
        media_pool.CreateEmptyTimeline.return_value = scratch
        project.SetCurrentTimeline.return_value = True

        def author(_tl, _ti, _pool, _folder, doc, line_number, **_kw):
            name = f"CaptionSuite-L{line_number:04d}"
            clips_by_name[name] = make_bin_clip(name)
            return name

        return {
            "project": project, "timeline": timeline,
            "media_pool": media_pool, "bin_folder": bin_folder,
            "clips_by_name": clips_by_name, "track_state": state,
            "author_side_effect": author, "placed_items": placed_items,
        }

    def _run(self, request_json):
        f = io.StringIO()
        with redirect_stdout(f):
            try:
                result = resolve_bridge.author_textplus(request_json)
            except resolve_bridge.BridgeFailure as exc:
                result = {"error": dict(exc.extra,
                                        code=exc.code, message=exc.message)}
        events = [
            json.loads(line)
            for line in f.getvalue().strip().split("\n") if line.strip()
        ]
        return result, events

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_all_unchanged_rerun_bakes_nothing(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        clips = self._clips(["a", "b", "c"])
        hashes = [resolve_bridge._clip_content_hash(c) for c in clips]
        ids = [f"CaptionSuite-L{i:04d}" for i in range(1, 4)]
        placed = [self._placed_marker(n) for n in ids]
        env = self._make_env(mock_open, mock_load, mock_verify,
                             track_items=placed, bin_names=ids)
        mock_author.side_effect = env["author_side_effect"]
        self._write_checkpoint(ids, hashes)

        result, events = self._run(self._make_request(clips))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["reused"], 3)
        self.assertEqual(result["reauthored"], 0)
        self.assertEqual(result["placedCount"], 0)
        mock_author.assert_not_called()
        # The original placed instances were left untouched (same objects).
        self.assertEqual(env["track_state"]["items"], placed)
        # Reuse progress line notes the count.
        reuse_events = [e for e in events if e.get("step") == "reuse"]
        self.assertEqual(reuse_events,
                         [{"event": "progress", "step": "reuse",
                           "count": 3}])
        final = self._read_checkpoint()
        self.assertEqual(final["completedClipIds"], ids)
        self.assertEqual(final["clipHashes"], hashes)

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_suffix_edit_reuses_prefix_and_rebakes_suffix(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        old_clips = self._clips(["a", "b", "c"])
        new_clips = self._clips(["a", "b", "CHANGED"])
        ids = [f"CaptionSuite-L{i:04d}" for i in range(1, 4)]
        hashes = [resolve_bridge._clip_content_hash(c) for c in old_clips]
        placed = [self._placed_marker(n) for n in ids]
        env = self._make_env(mock_open, mock_load, mock_verify,
                             track_items=placed, bin_names=ids)
        mock_author.side_effect = env["author_side_effect"]
        self._write_checkpoint(ids, hashes)

        result, _ = self._run(self._make_request(new_clips))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["reused"], 2)
        self.assertEqual(result["reauthored"], 1)
        self.assertEqual(result["clearedOwnedClips"], 1)
        # Only line 3 was re-authored.
        self.assertEqual([c.args[5] for c in mock_author.call_args_list],
                         [3])
        # The prefix markers stayed on the track untouched; the stale suffix
        # instance was cleared and freshly placed.
        self.assertEqual(env["track_state"]["items"][:2], placed[:2])
        self.assertEqual(len(env["track_state"]["items"]), 3)
        self.assertNotIn(placed[2], env["track_state"]["items"])
        infos = env["media_pool"].AppendToTimeline.call_args[0][0]
        self.assertEqual(len(infos), 1)
        self.assertEqual(infos[0]["recordFrame"], 48)
        # Checkpoint now covers the full set with the NEW hash suffix.
        final = self._read_checkpoint()
        self.assertEqual(final["completedClipIds"], ids)
        self.assertEqual(
            final["clipHashes"],
            [resolve_bridge._clip_content_hash(c) for c in new_clips])

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_mid_document_edit_reuses_only_up_to_mismatch(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        old_clips = self._clips(["a", "b", "c"])
        new_clips = self._clips(["a", "MID", "c"])
        ids = [f"CaptionSuite-L{i:04d}" for i in range(1, 4)]
        hashes = [resolve_bridge._clip_content_hash(c) for c in old_clips]
        placed = [self._placed_marker(n) for n in ids]
        env = self._make_env(mock_open, mock_load, mock_verify,
                             track_items=placed, bin_names=ids)
        mock_author.side_effect = env["author_side_effect"]
        self._write_checkpoint(ids, hashes)

        result, _ = self._run(self._make_request(new_clips))

        self.assertEqual(result["status"], "done")
        # Only the FIRST mismatch matters: clip 2 changed, so everything
        # from line 2 onward is re-authored (even the unchanged clip 3).
        self.assertEqual(result["reused"], 1)
        self.assertEqual(result["reauthored"], 2)
        self.assertEqual([c.args[5] for c in mock_author.call_args_list],
                         [2, 3])
        self.assertEqual(env["track_state"]["items"][:1], placed[:1])
        self.assertEqual(len(env["track_state"]["items"]), 3)

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_no_checkpoint_full_run(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        clips = self._clips(["a", "b", "c"])
        env = self._make_env(mock_open, mock_load, mock_verify)
        mock_author.side_effect = env["author_side_effect"]

        result, _ = self._run(self._make_request(clips))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["reused"], 0)
        self.assertEqual(result["reauthored"], 3)
        self.assertEqual(mock_author.call_count, 3)

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_missing_owned_marker_in_preserved_region_fails_loud(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        """The track was edited externally (L0002 removed) — reuse must fail
        loud with reuse-state-invalid instead of guessing."""
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        clips = self._clips(["a", "b", "c"])
        hashes = [resolve_bridge._clip_content_hash(c) for c in clips]
        ids = [f"CaptionSuite-L{i:04d}" for i in range(1, 4)]
        placed = [self._placed_marker(n) for n in
                  ["CaptionSuite-L0001", "CaptionSuite-L0003"]]
        env = self._make_env(mock_open, mock_load, mock_verify,
                             track_items=placed, bin_names=ids)
        mock_author.side_effect = env["author_side_effect"]
        self._write_checkpoint(ids, hashes)

        result, _ = self._run(self._make_request(clips))

        self.assertEqual(result["error"]["code"], "reuse-state-invalid")
        self.assertEqual(result["error"]["missingOwnedMarkers"],
                         ["CaptionSuite-L0002"])
        mock_author.assert_not_called()

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_old_format_checkpoint_without_hashes_full_run(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        """A checkpoint written before clipHashes existed is treated as no
        checkpoint: full run (and a warning on stderr)."""
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        clips = self._clips(["a", "b"])
        ids = [f"CaptionSuite-L{i:04d}" for i in range(1, 3)]
        placed = [self._placed_marker(n) for n in ids]
        env = self._make_env(mock_open, mock_load, mock_verify,
                             track_items=placed, bin_names=ids)
        mock_author.side_effect = env["author_side_effect"]
        self._write_checkpoint(ids, clip_hashes=None)

        result, events = self._run(self._make_request(clips))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["reused"], 0)
        self.assertEqual(result["reauthored"], 2)
        self.assertEqual(mock_author.call_count, 2)
        # Everything was cleared including the stale placed prefix.
        self.assertNotIn(placed[0], env["track_state"]["items"])


        # The rewritten checkpoint carries the new-format field.
        final = self._read_checkpoint()
        self.assertEqual(
            final["clipHashes"],
            [resolve_bridge._clip_content_hash(c) for c in clips])

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_clip_on_track")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_fresh_run_writes_clip_hashes_parallel_to_ids(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        """Every authoring run with runstateDir persists clipHashes parallel
        to completedClipIds — that's what makes the NEXT rerun reusable."""
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        clips = self._clips(["a", "b"])
        env = self._make_env(mock_open, mock_load, mock_verify)
        mock_author.side_effect = env["author_side_effect"]
        payload = json.loads(self._make_request(clips))
        payload.pop("reuseCheckpoint")

        result, _ = self._run(json.dumps(payload))

        self.assertEqual(result["status"], "done")
        final = self._read_checkpoint()
        self.assertEqual(final["completedClipIds"],
                         ["CaptionSuite-L0001", "CaptionSuite-L0002"])
        self.assertEqual(final["clipHashes"],
                         [resolve_bridge._clip_content_hash(c)
                          for c in clips])
        self.assertEqual(len(final["clipHashes"]),
                         len(final["completedClipIds"]))


class TestReuseCheckpointPersistentTitle(unittest.TestCase):
    """reuseCheckpoint:true at WINDOW granularity for the persistent-title
    executor: each window's hash covers its whole cue list, so any cue
    change rebakes exactly that window and everything after it."""

    TOKEN = "fake-composite-token"
    TIMELINE_ID = "tl-reuse-persistent"

    def setUp(self):
        self.runstate_dir = tempfile.mkdtemp(prefix="capproj-reuse-win-")
        self.addCleanup(shutil.rmtree, self.runstate_dir, ignore_errors=True)

    def _checkpoint_file(self):
        return os.path.join(self.runstate_dir, f"{self.TIMELINE_ID}.json")

    def _read_checkpoint(self):
        with open(self._checkpoint_file(), encoding="utf-8") as fh:
            return json.load(fh)

    @staticmethod
    def _clips(texts):
        return [
            {
                "clipId": f"c{i:03d}",
                "startFrame": i * 24,
                "endFrame": (i + 1) * 24,
                "text": text,
                "keyframes": {"End": {
                    "entries": [{"frame": 0, "value": 0.5}],
                    "isStepped": True,
                }},
                "overlayKeyframes": None,
            }
            for i, text in enumerate(texts)
        ]

    def _window_hashes(self, clips):
        windows = resolve_bridge._pack_windows(clips, 4.8, 24.0)
        return [resolve_bridge._window_content_hash(w) for w in windows]

    def _make_request(self, clips, **extra):
        payload = {
            "expectedToken": self.TOKEN,
            "animationDocument": {"formatVersion": 1, "clips": clips},
            "trackName": "Animate",
            "binName": "CaptionSuite",
            "runstateDir": self.runstate_dir,
            "timelineId": self.TIMELINE_ID,
            "reuseCheckpoint": True,
        }
        payload.update(extra)
        return payload

    @staticmethod
    def _placed_marker(name):
        item = MagicMock()
        item.GetName.return_value = name
        return item

    def _make_env(self, mock_open, mock_load, mock_verify, track_items=None,
                  bin_names=None):
        # 6 x 24-frame cues at the default cap pack into two windows.
        resolve, project, timeline = _make_mock_resolve()
        mock_load.return_value = resolve
        mock_open.return_value = (project, timeline)
        mock_verify.side_effect = lambda *a, **k: True

        tracks = ["Video 1"]
        timeline.GetTrackCount.side_effect = lambda _t: len(tracks)
        timeline.GetTrackName.side_effect = lambda _t, idx: tracks[idx - 1]
        timeline.AddTrack.side_effect = lambda _t: (
            tracks.append(f"Video {len(tracks) + 1}"), True)[1]
        timeline.SetTrackName.side_effect = lambda _t, i, n: (
            tracks.__setitem__(i - 1, n), True)[1]
        state = {"items": list(track_items or [])}
        timeline.GetItemListInTrack.side_effect = (
            lambda _t, idx: list(state["items"]) if idx == len(tracks) else [])
        timeline.DeleteClips.side_effect = lambda clips, *_a, **_k: (
            state.__setitem__(
                "items",
                [c for c in state["items"]
                 if id(c) not in {id(x) for x in clips}]),
            True)[1]

        media_pool = MagicMock()
        project.GetMediaPool.return_value = media_pool
        root = MagicMock()
        root.GetSubFolderList.return_value = []
        media_pool.GetRootFolder.return_value = root
        bin_folder = MagicMock()
        media_pool.AddSubFolder.return_value = bin_folder

        clips_by_name = {}

        def make_bin_clip(name):
            clip = MagicMock()
            clip.GetName.return_value = name
            clip.GetMediaId.return_value = 9000 + abs(hash(name)) % 1000
            return clip

        for name in (bin_names or []):
            clips_by_name[name] = make_bin_clip(name)
        bin_folder.GetClipList.side_effect = (
            lambda: list(clips_by_name.values()))
        media_pool.DeleteClips.return_value = True

        placed_items = []

        def append_to_timeline(infos):
            # Same current-timeline placement semantics as the multi-clip
            # env: placed instances land on the fake target track.
            made = [_named_placed_timeline_item() for _ in infos]
            state["items"].extend(made)
            placed_items.extend(made)
            return made

        media_pool.AppendToTimeline.side_effect = append_to_timeline

        scratch = MagicMock()
        media_pool.CreateEmptyTimeline.return_value = scratch
        project.SetCurrentTimeline.return_value = True

        def bake(_tl, _ti, _pool, _folder, _win, win_num, **_kw):
            name = f"CaptionSuite-W{win_num:04d}"
            clips_by_name[name] = make_bin_clip(name)
            return name

        return {
            "project": project, "timeline": timeline,
            "media_pool": media_pool, "bin_folder": bin_folder,
            "clips_by_name": clips_by_name, "track_state": state,
            "bake_side_effect": bake, "placed_items": placed_items,
        }

    def _run(self, request):
        f = io.StringIO()
        with redirect_stdout(f):
            try:
                result = resolve_bridge.mode_author_persistent_title(request)
            except resolve_bridge.BridgeFailure as exc:
                result = {"error": dict(exc.extra,
                                        code=exc.code, message=exc.message)}
        events = [
            json.loads(line)
            for line in f.getvalue().strip().split("\n") if line.strip()
        ]
        return result, events

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_all_windows_unchanged_bakes_nothing(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        clips = self._clips(["a", "b", "c", "d", "e", "f"])
        hashes = self._window_hashes(clips)
        ids = ["CaptionSuite-W0001", "CaptionSuite-W0002"]
        placed = [self._placed_marker(n) for n in ids]
        env = self._make_env(mock_open, mock_load, mock_verify,
                             track_items=placed, bin_names=ids)
        mock_author.side_effect = env["bake_side_effect"]
        with open(self._checkpoint_file(), "w", encoding="utf-8") as fh:
            json.dump({
                "completedWindows": 2,
                "completedLines": 2,
                "completedClipIds": ids,
                "clipHashes": hashes,
                "lastToken": self.TOKEN,
                "lastCheckpointAt": "2026-08-25T12:00:00Z",
                "pid": 12345,
            }, fh)

        result, events = self._run(self._make_request(clips))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["reused"], 2)
        self.assertEqual(result["reauthored"], 0)
        self.assertEqual(result["placedCount"], 0)
        mock_author.assert_not_called()
        self.assertEqual(env["track_state"]["items"], placed)
        reuse_events = [e for e in events if e.get("step") == "reuse"]
        self.assertEqual(reuse_events,
                         [{"event": "progress", "step": "reuse",
                           "count": 2}])

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_last_window_cue_change_rebakes_only_that_window(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        old_clips = self._clips(["a", "b", "c", "d", "e", "f"])
        new_texts = ["a", "b", "c", "d", "e", "EDITED"]
        new_clips = self._clips(new_texts)
        hashes = self._window_hashes(old_clips)
        ids = ["CaptionSuite-W0001", "CaptionSuite-W0002"]
        placed = [self._placed_marker(n) for n in ids]
        env = self._make_env(mock_open, mock_load, mock_verify,
                             track_items=placed, bin_names=ids)
        mock_author.side_effect = env["bake_side_effect"]
        with open(self._checkpoint_file(), "w", encoding="utf-8") as fh:
            json.dump({
                "completedWindows": 2,
                "completedLines": 2,
                "completedClipIds": ids,
                "clipHashes": hashes,
                "lastToken": self.TOKEN,
                "lastCheckpointAt": "2026-08-25T12:00:00Z",
                "pid": 12345,
            }, fh)

        result, _ = self._run(self._make_request(new_clips))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["reused"], 1)
        self.assertEqual(result["reauthored"], 1)
        # Only window 2 was re-baked.
        self.assertEqual([c.args[5] for c in mock_author.call_args_list],
                         [2])
        # Window 1's placed instance stayed untouched; window 2 was replaced.
        self.assertEqual(env["track_state"]["items"][0], placed[0])
        self.assertEqual(len(env["track_state"]["items"]), 2)
        self.assertNotIn(placed[1], env["track_state"]["items"])
        infos = env["media_pool"].AppendToTimeline.call_args[0][0]
        self.assertEqual(len(infos), 1)
        self.assertEqual(infos[0]["recordFrame"], 96)
        final = self._read_checkpoint()
        self.assertEqual(final["completedClipIds"], ids)
        self.assertEqual(final["clipHashes"],
                         self._window_hashes(new_clips))

    @patch("resolve_bridge._timeline_identity")
    @patch("resolve_bridge._author_window_baked_clip")
    @patch("resolve_bridge.verify_token")
    @patch("resolve_bridge.load_resolve")
    @patch("resolve_bridge.open_project_timeline")
    def test_first_cue_change_rebakes_everything(
        self, mock_open, mock_load, mock_verify, mock_author, mock_identity,
    ):
        mock_identity.return_value = (
            {"compositeToken": self.TOKEN}, 24.0, 0)
        old_clips = self._clips(["a", "b", "c", "d", "e", "f"])
        new_clips = self._clips(["EDITED", "b", "c", "d", "e", "f"])
        hashes = self._window_hashes(old_clips)
        ids = ["CaptionSuite-W0001", "CaptionSuite-W0002"]
        placed = [self._placed_marker(n) for n in ids]
        env = self._make_env(mock_open, mock_load, mock_verify,
                             track_items=placed, bin_names=ids)
        mock_author.side_effect = env["bake_side_effect"]
        with open(self._checkpoint_file(), "w", encoding="utf-8") as fh:
            json.dump({
                "completedWindows": 2,
                "completedLines": 2,
                "completedClipIds": ids,
                "clipHashes": hashes,
                "lastToken": self.TOKEN,
                "lastCheckpointAt": "2026-08-25T12:00:00Z",
                "pid": 12345,
            }, fh)

        result, _ = self._run(self._make_request(new_clips))

        self.assertEqual(result["status"], "done")
        self.assertEqual(result["reused"], 0)
        self.assertEqual(result["reauthored"], 2)
        self.assertEqual(mock_author.call_count, 2)
        self.assertNotIn(placed[0], env["track_state"]["items"])


class TestTextPlusOverflowProbe(unittest.TestCase):
    class _Value:
        def __init__(self, data_window):
            self.DataWindow = data_window

    def _tool(self, data_window):
        tool = MagicMock()
        tool.Output.GetValue.return_value = self._Value(data_window)
        return tool

    def test_fully_inside_frame_is_verified(self):
        finding = resolve_bridge._probe_textplus_overflow(
            MagicMock(), self._tool({1: 100, 2: 200, 3: 900, 4: 700}),
            "cue-1", (1920, 1080), fully_revealed_frame=23)
        self.assertEqual(finding["targetResolution"], [1920, 1080])

    def test_each_frame_edge_is_reported(self):
        for window in ((-1, 0, 100, 100), (0, 0, 1921, 100),
                       (0, -1, 100, 100), (0, 0, 100, 1081)):
            with self.subTest(window=window):
                with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
                    resolve_bridge._probe_textplus_overflow(
                        MagicMock(), self._tool(window), "cue-edge",
                        (1920, 1080))
                self.assertEqual(ctx.exception.code, "caption-overflow")
                self.assertIn("Speech Alignment", ctx.exception.message)
                self.assertEqual(ctx.exception.extra["overflowFindings"][0]
                                 ["renderedDataWindow"], list(window))

    def test_missing_or_invalid_data_window_is_not_safe(self):
        for data_window in (None, {1: 0, 2: 0}, [0, 0, float("nan"), 1]):
            with self.subTest(data_window=data_window):
                with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
                    resolve_bridge._probe_textplus_overflow(
                        MagicMock(), self._tool(data_window), "cue-invalid",
                        (1920, 1080))
                self.assertEqual(ctx.exception.code,
                                 "overflow-probe-unavailable")
                self.assertEqual(ctx.exception.extra["overflowProbe"]["status"],
                                 "acknowledgement-required")

    def test_unavailable_fully_revealed_frame_is_not_safe(self):
        class _Comp:
            def SetCurrentTime(self, _frame):
                return False

            @property
            def CurrentTime(self):
                return 0

            @CurrentTime.setter
            def CurrentTime(self, _frame):
                raise RuntimeError("cannot seek")

        with self.assertRaises(resolve_bridge.BridgeFailure) as ctx:
            resolve_bridge._probe_textplus_overflow(
                _Comp(), self._tool([0, 0, 100, 100]), "cue-time",
                (1920, 1080), fully_revealed_frame=23)
        self.assertEqual(ctx.exception.code, "overflow-probe-unavailable")
        self.assertEqual(
            ctx.exception.extra["overflowProbe"]["reason"],
            "fully-revealed-frame-unavailable")
