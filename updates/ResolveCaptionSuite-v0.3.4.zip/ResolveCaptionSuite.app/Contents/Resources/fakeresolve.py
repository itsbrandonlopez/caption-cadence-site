"""Small semantic fake for the Resolve API surface used by animation tests.

This is not a general Resolve emulator.  It models the verified behaviors
that ordinary ``MagicMock`` objects cannot represent: Fusion splines are
created through ``BezierSpline({})``, ``AddTool`` is a tool-registration API,
and assigning a modifier through ``SetInput`` is a fail-quiet no-op on the
supported Resolve build.  The fake is deliberately strict about unsupported
operations so tests do not accidentally certify a made-up API.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


class FakeResolveError(RuntimeError):
    """Raised when a test asks the fake for an unsupported API behavior."""


@dataclass
class FakeSpline:
    """A modifier created by ``comp.BezierSpline({})``."""

    keyframes: dict[float, dict[Any, Any]] = field(default_factory=dict)

    def SetKeyFrames(self, keyframes, _overwrite=True):
        self.keyframes = dict(keyframes)
        return True


@dataclass
class FakeRegisteredSpline:
    """The distinct object produced when a spline is incorrectly AddTool'd."""

    keyframes: dict[float, dict[Any, Any]] = field(default_factory=dict)
    flags: dict[str, Any] = field(default_factory=dict)

    def SetKeyFrames(self, keyframes, _overwrite=True):
        self.keyframes = dict(keyframes)
        return True

    def SetInput(self, name, value):
        # AddTool-created spline tools do not expose the modifier semantics
        # used by the bridge.  In particular StepIn/StepOut do not affect
        # evaluation here, matching the live landmine.
        if name in ("StepIn", "StepOut"):
            self.flags[name] = value
            return False
        raise FakeResolveError(f"unsupported registered-spline input: {name}")


class FakeTextPlus:
    """Text+ tool with explicit fail-quiet ``SetInput`` semantics."""

    ID = "TextPlus"

    def __init__(self, name="TextPlus"):
        self.Name = name
        self.inputs: dict[str, Any] = {}
        self.End = None
        self.Start = None

    def SetInput(self, name, value):
        if isinstance(value, (FakeSpline, FakeRegisteredSpline)):
            # Verified Resolve behavior: SetInput accepts the call but does
            # not connect a modifier.  The bridge must use attribute
            # assignment instead.
            return False
        self.inputs[name] = value
        setattr(self, name, value)
        return True

    def GetInput(self, name):
        return self.inputs.get(name)

    def LoadSettings(self, _payload):
        return True


class FakeComp:
    """Minimal Fusion comp with strict tool-creation paths."""

    def __init__(self):
        self.tools: list[Any] = []

    def BezierSpline(self, _settings):
        spline = FakeSpline()
        return spline

    def AddTool(self, tool_id, _x=0, _y=0):
        if tool_id in ("TextPlus", "Text+"):
            tool = FakeTextPlus(f"TextPlus{len(self.tools) + 1}")
        elif tool_id in ("BezierSpline", "BezierSplineTool"):
            tool = FakeRegisteredSpline()
        else:
            raise FakeResolveError(f"unsupported tool id: {tool_id}")
        self.tools.append(tool)
        return tool

    def GetToolList(self, _selected=False):
        return {index + 1: tool for index, tool in enumerate(self.tools)}


class FakeTimeline:
    """Strict timeline stub for deletion and append contract tests."""

    def __init__(self):
        self.items: list[Any] = []

    def DeleteClips(self, items, *_unsupported):
        if not isinstance(items, list):
            raise FakeResolveError("DeleteClips expects a list of timeline items")
        self.items = [item for item in self.items if item not in items]
        return True

    def AppendToTimeline(self, infos):
        if not isinstance(infos, list):
            raise FakeResolveError("AppendToTimeline expects a list")
        self.items.extend(infos)
        return list(infos)

