"""Pure helpers shared by the Multi-Clip and Window-Baked executors."""

from __future__ import annotations

import hashlib
import json
from typing import Any, Sequence


def clip_content_hash(clip_doc: dict[str, Any]) -> str:
    """Hash only fields that affect rendered clip content."""
    payload = {
        "startFrame": clip_doc.get("startFrame"),
        "endFrame": clip_doc.get("endFrame"),
        "text": clip_doc.get("text"),
        "keyframes": clip_doc.get("keyframes"),
        "overlayKeyframes": clip_doc.get("overlayKeyframes"),
    }
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def window_content_hash(window_clips: Sequence[dict[str, Any]]) -> str:
    """Hash an ordered window from its cue-level content hashes."""
    payload = [clip_content_hash(clip) for clip in window_clips]
    canonical = json.dumps(payload, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def longest_matching_prefix(incoming: Sequence[str], stored: Sequence[str]) -> int:
    """Return the length of the unchanged prefix of two hash sequences."""
    for index, (new_hash, old_hash) in enumerate(zip(incoming, stored)):
        if new_hash != old_hash:
            return index
    return min(len(incoming), len(stored))
