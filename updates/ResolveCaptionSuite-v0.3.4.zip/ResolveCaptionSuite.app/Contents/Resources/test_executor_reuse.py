"""Pure executor reuse contracts, independent of Resolve."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "Resolve"))

import executor_reuse
import resolve_bridge


class TestExecutorReuse(unittest.TestCase):
    def test_presentation_only_clip_id_does_not_change_content_hash(self):
        base = {
            "clipId": "cue-a",
            "startFrame": 10,
            "endFrame": 20,
            "text": "hello",
            "keyframes": {"End": [1]},
            "overlayKeyframes": None,
        }
        renamed = dict(base, clipId="different-id")
        self.assertEqual(
            executor_reuse.clip_content_hash(base),
            executor_reuse.clip_content_hash(renamed),
        )

    def test_window_hash_is_order_sensitive(self):
        first = {"text": "first", "startFrame": 0, "endFrame": 1}
        second = {"text": "second", "startFrame": 1, "endFrame": 2}
        self.assertNotEqual(
            executor_reuse.window_content_hash([first, second]),
            executor_reuse.window_content_hash([second, first]),
        )

    def test_prefix_reuse_stops_at_first_changed_hash(self):
        self.assertEqual(
            executor_reuse.longest_matching_prefix(
                ["a", "b", "changed", "d"], ["a", "b", "old"]),
            2,
        )
        self.assertEqual(
            executor_reuse.longest_matching_prefix(["a"], ["a", "b"]), 1)

    def test_protected_bin_prefix_prefers_reuse_over_checkpoint_length(self):
        checkpoint = {"completedClipIds": ["one", "two", "three"]}
        self.assertEqual(
            resolve_bridge._protected_bin_prefix(True, 1, checkpoint), 1)
        self.assertEqual(
            resolve_bridge._protected_bin_prefix(False, 0, checkpoint), 3)
        self.assertEqual(
            resolve_bridge._protected_bin_prefix(False, 0, None), 0)

    def test_checkpoint_state_is_shared_between_executor_modes(self):
        class Timeline:
            def GetName(self):
                return "Timeline 1"

        state = resolve_bridge._load_executor_checkpoint(
            {"expectedToken": "token"}, Timeline())
        self.assertFalse(state["persist"])
        self.assertFalse(state["wants_resume"])
        self.assertFalse(state["wants_reuse"])
        self.assertIsNone(state["checkpoint"])

    def test_resume_without_runstate_is_rejected_by_shared_helper(self):
        class Timeline:
            def GetName(self):
                return "Timeline 1"

        with self.assertRaises(resolve_bridge.BridgeFailure) as context:
            resolve_bridge._load_executor_checkpoint(
                {"resume": True, "expectedToken": "token"}, Timeline())
        self.assertEqual(context.exception.code, "resume-requires-runstate-dir")
