"""Filesystem contract tests for executor checkpoints."""

import json
import os
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "Resolve"))

import checkpoint_store


class TestCheckpointStore(unittest.TestCase):
    def setUp(self):
        self.runstate_dir = tempfile.mkdtemp(prefix="capproj-checkpoint-store-")

    def tearDown(self):
        shutil.rmtree(self.runstate_dir, ignore_errors=True)

    def test_save_and_load_use_the_shared_sidecar_path(self):
        checkpoint_store.save_checkpoint(
            self.runstate_dir, "timeline-1", {"completedLines": 3})

        path = checkpoint_store.checkpoint_path(self.runstate_dir, "timeline-1")
        self.assertEqual(checkpoint_store.load_checkpoint(self.runstate_dir, "timeline-1"),
                         {"completedLines": 3})
        self.assertTrue(os.path.exists(path))
        self.assertEqual(
            [name for name in os.listdir(self.runstate_dir) if ".tmp" in name], [])

    def test_corrupt_checkpoint_degrades_to_fresh_run(self):
        path = checkpoint_store.checkpoint_path(self.runstate_dir, "timeline-1")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("{not json")

        self.assertIsNone(checkpoint_store.load_checkpoint(self.runstate_dir, "timeline-1"))

    def test_save_replaces_previous_complete_document(self):
        checkpoint_store.save_checkpoint(
            self.runstate_dir, "timeline-1", {"completedLines": 1})
        checkpoint_store.save_checkpoint(
            self.runstate_dir, "timeline-1", {"completedLines": 2})

        with open(checkpoint_store.checkpoint_path(self.runstate_dir, "timeline-1"),
                  encoding="utf-8") as fh:
            self.assertEqual(json.load(fh), {"completedLines": 2})
