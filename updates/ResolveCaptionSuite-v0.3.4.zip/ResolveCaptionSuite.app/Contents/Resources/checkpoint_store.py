"""Durable executor runstate storage shared by bridge execution modes.

The checkpoint format is intentionally JSON and sidecar-only.  This module
owns filesystem behavior; the bridge remains responsible for deciding when a
checkpoint is valid and what its fields mean.
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from typing import Any


def checkpoint_path(runstate_dir: str, timeline_id: str) -> str:
    return os.path.join(runstate_dir, f"{timeline_id}.json")


def load_checkpoint(runstate_dir: str, timeline_id: str) -> dict[str, Any] | None:
    """Load a checkpoint, treating missing/corrupt state as a fresh run."""
    path = checkpoint_path(runstate_dir, timeline_id)
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except FileNotFoundError:
        return None
    except (json.JSONDecodeError, OSError, UnicodeDecodeError) as exc:
        sys.stderr.write(f"warning: ignoring corrupt checkpoint {path}: {exc}\n")
        return None
    return data if isinstance(data, dict) else None


def save_checkpoint(runstate_dir: str, timeline_id: str, checkpoint: dict[str, Any]) -> None:
    """Atomically persist a complete checkpoint beside its final path."""
    os.makedirs(runstate_dir, exist_ok=True)
    path = checkpoint_path(runstate_dir, timeline_id)
    tmp = f"{path}.tmp{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(checkpoint, fh)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


def iso_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
