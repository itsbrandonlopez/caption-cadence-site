# Resolve Caption Suite — DaVinci Resolve Scripts-menu tools
#
# Owned and installed by the Resolve Caption Suite macOS app. The sentinel line and
# APP_VERSION assignment below are read back by the app's installer to identify files
# it owns (install/upgrade/uninstall only ever touches files carrying this marker);
# other files in this directory are never touched. Do not remove either line.
#
# CAPTION-SUITE-OWNED-BY-RESOLVE-CAPTION-SUITE
APP_VERSION = "0.3.2"
#
# Runs INSIDE DaVinci Resolve (Workspace > Scripts > CaptionSuiteTools — Resolve 21
# lists Utility-folder scripts directly under Scripts); Resolve injects the `resolve`,
# `fu`, and `bmd` globals. Stdlib-only, read-only:
# v1 exposes one status command only. Capture-style and word-timing actions
# belong in the macOS app; they are intentionally not presented here.
# Compatible with the system python3 family Resolve embeds (no f-strings-free
# constraint needed, but kept conservative for older interpreters).

def _get_resolve():
    """Return the Resolve API object, tolerating missing injections."""
    resolve = globals().get("resolve")
    if resolve is not None:
        return resolve
    try:
        import fusionscript  # noqa: F401  (only reached when not injected)
        return fusionscript.Resolve()
    except Exception:
        return None


def _format(value):
    if value is None:
        return "unknown"
    text = str(value).strip()
    return text if text else "unknown"


def _timeline_setting(timeline, key):
    try:
        value = timeline.GetSetting(key)
    except Exception:
        return None
    if isinstance(value, str) and not value.strip():
        return None
    return value


def _video_item_count(timeline):
    """Total clips across all video tracks; '?' when the API won't tell us."""
    try:
        track_count = int(timeline.GetTrackCount("video"))
    except Exception:
        return "?"
    total = 0
    for index in range(1, track_count + 1):
        try:
            items = timeline.GetItemListInTrack("video", index)
            total += len(items) if items else 0
        except Exception:
            pass
    return str(total)


def _ui_and_dispatcher():
    """Locate UIManager + a window dispatcher across Resolve's injection variants.

    Resolve 21 does not reliably inject a usable `bmd` here (it can arrive as
    the raw fusionscript module, which has UIDispatcher but no UIDispatch), so
    fall back to importing fusionscript directly and its scriptapp("Fusion").
    """
    fu = globals().get("fu")
    if fu is None:
        try:
            import fusionscript
            fu = fusionscript.scriptapp("Fusion")
        except Exception:
            return None, None
    if fu is None:
        return None, None
    ui = getattr(fu, "UIManager", None)
    if ui is None:
        return None, None

    factories = []
    bmd = globals().get("bmd")
    if bmd is not None:
        factories.extend([
            getattr(bmd, "UIDispatcher", None),
            getattr(bmd, "UIDispatch", None),
        ])
    try:
        import fusionscript
        factory = getattr(fusionscript, "UIDispatcher", None)
        if factory is not None:
            factories.append(factory)
    except Exception:
        pass
    for factory in factories:
        if factory is None:
            continue
        try:
            return ui, factory(ui)
        except Exception:
            continue
    return None, None


def _show_message(title, message):
    """Small modal message dialog via Resolve's UIManager, print as fallback."""
    ui, dispatch = _ui_and_dispatcher()
    if dispatch is not None:
        try:
            window = dispatch.AddWindow(
                {
                    "ID": "CaptionSuiteMessage",
                    "WindowTitle": title,
                    "Geometry": [200, 200, 560, 320],
                    "Spacing": 10,
                },
                [
                    # NOTE: this build's UIManager exposes VGroup/HGroup (the
                    # BMD naming); VStack/HStack are None and raise
                    # TypeError("'NoneType' object is not callable").
                    ui.VGroup({"Weight": 1.0, "Spacing": 10}, [
                        ui.Label({
                            "ID": "Message",
                            "Text": message,
                            "WordWrap": True,
                            "Weight": 1.0,
                        }),
                        ui.HGroup({"Weight": 0.0, "Alignment": "Right"}, [
                            ui.Button({"ID": "OKButton", "Text": "OK"}),
                        ]),
                    ]),
                ],
            )

            def _close(event):
                dispatch.ExitLoop()

            window.On.OKButton.Clicked = _close
            window.On.CaptionSuiteMessage.Close = _close
            window.Show()
            dispatch.RunLoop()
            window.Hide()
            return
        except Exception as exc:
            # Surface WHY the dialog path failed instead of failing silently.
            print("Caption Suite: UIManager dialog failed: %r" % (exc,))
    # Headless / UIManager-unavailable fallback (e.g. Console render contexts).
    print("%s\n%s" % (title, message))


def show_project_status():
    """Show the current project and timeline summary (read-only)."""
    lines = []
    resolve = _get_resolve()
    if resolve is None:
        lines.append("Could not reach DaVinci Resolve's scripting API.")
        lines.append("Check Preferences > System > General > External scripting.")
    else:
        project = None
        try:
            manager = resolve.GetProjectManager()
            project = manager.GetCurrentProject() if manager is not None else None
        except Exception:
            project = None
        # Resolve 21 quirk: resolve.GetCurrentProject() can return None even with a
        # project open — the project-manager route above is the reliable one.
        if project is None:
            lines.append("No project is currently open.")
        else:
            lines.append("Project: %s" % _format(project.GetName()))
            timeline = None
            try:
                timeline = project.GetCurrentTimeline()
            except Exception:
                timeline = None
            if timeline is None:
                lines.append("Timeline: none open")
            else:
                lines.append("Timeline: %s" % _format(timeline.GetName()))
                lines.append("Frame rate: %s fps" % _format(
                    _timeline_setting(timeline, "timelineFrameRate")))
                try:
                    start_frame = timeline.GetStartFrame()
                except Exception:
                    start_frame = None
                lines.append("Start frame: %s" % _format(start_frame))
                lines.append("Video clip items: %s" % _video_item_count(timeline))
    _show_message("Caption Suite — Project Status", "\n".join(lines))


# Resolve executes this file top-to-bottom when the menu entry is clicked and
# auto-invokes nothing — without this block clicking the entry did nothing.
if __name__ == "__main__":
    show_project_status()
