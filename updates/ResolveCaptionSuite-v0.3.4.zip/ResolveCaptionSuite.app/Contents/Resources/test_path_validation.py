#!/usr/bin/env python3
"""Test cases for path validation in project file handling."""

import json
import os
import tempfile
import unittest
from unittest.mock import MagicMock, patch

# Add the project root to Python path so we can import resolve_bridge
import sys
sys.path.insert(0, '/Users/brandon/Desktop/Gigs/ResolveCaptionSuite')

from App.Resolve.resolve_bridge import _resolve_style_payload, BridgeFailure


class TestPathValidation(unittest.TestCase):
    """Test cases for path validation in project file handling."""

    def test_valid_style_path(self):
        """Test that valid style paths are accepted."""
        # Create a temporary preset file
        with tempfile.TemporaryDirectory() as temp_dir:
            preset_path = os.path.join(temp_dir, "test.preset")
            
            # Create a valid .capproj style file
            preset_data = {
                "id": "test-123",
                "name": "Test Preset",
                "createdAt": "2026-08-25T00:00:00Z",
                "settings": {"Font": "Arial", "Size": 24},
                "thumbnailDescription": None,
            }
            
            with open(preset_path, "w", encoding="utf-8") as f:
                json.dump(preset_data, f)
            
            # Test with a valid path
            request = {"stylePath": preset_path}
            result = _resolve_style_payload(request)
            
            # Should return the settings
            self.assertEqual(result, {"Font": "Arial", "Size": 24})

    def test_invalid_path_traversal(self):
        """Test that path traversal attempts are rejected."""
        # Create a temporary directory structure
        with tempfile.TemporaryDirectory() as temp_dir:
            preset_path = os.path.join(temp_dir, "test.preset")
            
            # Create a valid .capproj style file
            preset_data = {
                "id": "test-123",
                "name": "Test Preset",
                "createdAt": "2026-08-25T00:00:00Z",
                "settings": {"Font": "Arial", "Size": 24},
                "thumbnailDescription": None,
            }
            
            with open(preset_path, "w", encoding="utf-8") as f:
                json.dump(preset_data, f)
            
            # Test with a path traversal attempt (should fail)
            request = {"stylePath": os.path.join(temp_dir, "..", "some_file")}
            
            with self.assertRaises(BridgeFailure) as context:
                _resolve_style_payload(request)
                
            # Should fail with style-path-invalid error
            self.assertEqual(context.exception.code, "style-path-invalid")

    def test_invalid_path_outside_scope(self):
        """Test that paths outside the working directory are rejected."""
        # Test with a path pointing to system files (should fail)
        request = {"stylePath": "/etc/passwd"}
        
        with self.assertRaises(BridgeFailure) as context:
            _resolve_style_payload(request)
            
        # Should fail with style-path-invalid error
        self.assertEqual(context.exception.code, "style-path-invalid")

    def test_style_payload_still_works(self):
        """Test that direct stylePayload still works."""
        request = {
            "stylePayload": {"Font": "Arial", "Size": 24}
        }
        
        result = _resolve_style_payload(request)
        
        # Should return the payload directly
        self.assertEqual(result, {"Font": "Arial", "Size": 24})

    def test_invalid_style_path_type(self):
        """Test that invalid stylePath types are rejected."""
        # Test with non-string path
        request = {"stylePath": 123}
        
        with self.assertRaises(BridgeFailure) as context:
            _resolve_style_payload(request)
            
        # Should fail with bad-style-payload error
        self.assertEqual(context.exception.code, "bad-style-payload")

    def test_nonexistent_path(self):
        """Test that nonexistent paths are rejected."""
        request = {"stylePath": "/nonexistent/file.capproj"}
        
        with self.assertRaises(BridgeFailure) as context:
            _resolve_style_payload(request)
            
        # Should fail with style-path-unreadable error
        self.assertEqual(context.exception.code, "style-path-unreadable")


if __name__ == "__main__":
    unittest.main()