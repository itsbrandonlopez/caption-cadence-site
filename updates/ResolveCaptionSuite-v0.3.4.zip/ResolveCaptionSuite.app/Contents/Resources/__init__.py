# Tests for resolve_bridge.py modes
