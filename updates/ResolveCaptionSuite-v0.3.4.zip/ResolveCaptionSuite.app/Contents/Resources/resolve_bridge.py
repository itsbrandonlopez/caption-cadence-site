#!/usr/bin/env python3
"""resolve_bridge.py — Resolve Caption Suite's push-channel bridge.

One invocation = one JSON request on stdin = NDJSON responses on stdout =
meaningful exit code (ARCHITECTURE.md §2, bridge rule 1).

Protocol (every line is a single JSON object, printed with explicit flush):

    {"event": "progress",  "step": "...", "pct": 0.42}     # incremental work
    {"event": "heartbeat", "t": 1771900000.123}            # liveness only
    {"event": "result", "ok": true,  "mode": "...", "data": {...}}
    {"event": "result", "ok": false, "mode": "...",
     "error": {"code": "...", "message": "..."}}

stderr carries human-readable diagnostics only; it is never part of the
protocol.

Exit codes:
    0   success (a final result line with ok=true was printed)
    2   usage error (no mode, or unknown mode)
    3   structured mode failure (a final result line with ok=false)
    4   unexpected internal error (also reported as a structured line)

Phase-0 rule baked in: EVERY stdout write uses flush=True. Unflushed print()
on a pipe batches output into one burst at exit — five heartbeats meant to
arrive 0.3s apart all arrived simultaneously without it (D12 follow-up).
"""

import json
import math
import os
import select
import signal
import sys
import threading
import time
from collections import OrderedDict
from datetime import datetime, timezone
from typing import Any, Dict, List, Union

from checkpoint_store import (
    checkpoint_path as _checkpoint_path,
    iso_now as _iso_now,
    load_checkpoint as _load_checkpoint,
    save_checkpoint as _save_checkpoint,
)
from executor_reuse import (
    clip_content_hash as _clip_content_hash,
    longest_matching_prefix as _longest_matching_prefix,
    window_content_hash as _window_content_hash,
)


JSONMapping = Dict[str, Any]
JSONRequest = Union[str, JSONMapping]

# Resolve version floor per ARCHITECTURE.md §2 bridge rule 4: fail loudly on
# versions we have not probed rather than silently misbehaving. Phase 0 ran
# against Resolve 20; older majors are unprobed.
MIN_RESOLVE_MAJOR = 19


class BridgeFailure(Exception):
    """A structured, expected failure of one mode.

    Carries a machine-readable code plus user-facing message; printed as a
    result line with ok=false and reflected in the exit code. `extra` merges
    additional machine-readable keys into the error payload (e.g.
    `resumableAt` for checkpointed execution failures).
    """

    def __init__(self, code, message, extra=None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.extra = dict(extra) if extra else {}


def _parse_request(request_json: JSONRequest, *, error_code="request-unparseable") -> JSONMapping:
    """Normalize a direct handler argument to the dispatcher request shape.

    ``main`` parses stdin once before dispatching, while tests and library
    callers invoke handlers directly with a JSON string. Keeping the
    compatibility shim here prevents individual modes from drifting and
    avoids the historical capture-style dict re-parse bug.
    """
    if isinstance(request_json, dict):
        return request_json
    try:
        request = json.loads(request_json)
    except (TypeError, json.JSONDecodeError) as exc:
        raise BridgeFailure(error_code, f"stdin isn't valid JSON: {exc}") from exc
    if not isinstance(request, dict):
        raise BridgeFailure(
            "request-not-object",
            "The bridge request must be a JSON object.",
        )
    return request


_shutdown_requested = False
_operation_id = None


def _handle_sigterm(_signum, _frame):
    """Record termination without interrupting the current bridge operation."""
    global _shutdown_requested
    _shutdown_requested = True


def _install_signal_handlers():
    signal.signal(signal.SIGTERM, _handle_sigterm)
    signal.signal(signal.SIGINT, _handle_sigterm)


def emit(obj):
    """Print one protocol line. Explicit flush is NON-NEGOTIABLE."""
    if _operation_id:
        obj = dict(obj)
        obj["operationId"] = _operation_id
    sys.stdout.write(json.dumps(obj, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def emit_progress(step, pct=None, **extra):
    obj = {"event": "progress", "step": step}
    if pct is not None:
        obj["pct"] = round(pct, 4)
    obj.update(extra)
    emit(obj)


def emit_heartbeat():
    emit({"event": "heartbeat", "t": time.time()})


def emit_result(mode, data):
    emit({"event": "result", "ok": True, "mode": mode, "data": data})


def emit_error(mode, code, message, extra=None):
    error = {"code": code, "message": message}
    if extra:
        error.update(extra)
    emit({
        "event": "result",
        "ok": False,
        "mode": mode,
        "error": error,
    })


# --------------------------------------------------------------------------
# Resolve connectivity
# --------------------------------------------------------------------------

def load_resolve():
    """Connect to a running Resolve via external scripting.

    Requires RESOLVE_SCRIPT_API / RESOLVE_SCRIPT_LIB in the environment (the
    app sets both when spawning us). Fails with an actionable structured
    error instead of a traceback when anything in the chain is missing.
    """
    import ctypes

    api = os.environ.get("RESOLVE_SCRIPT_API")
    lib = os.environ.get("RESOLVE_SCRIPT_LIB")
    if not api or not lib:
        raise BridgeFailure(
            "resolve-env-missing",
            "RESOLVE_SCRIPT_API/RESOLVE_SCRIPT_LIB are not set — "
            "the app must provide Resolve's scripting paths.",
        )
    if not os.path.isdir(api):
        raise BridgeFailure(
            "resolve-not-installed",
            "Resolve scripting API not found — is DaVinci Resolve installed?",
        )

    sys.path.append(os.path.join(api, "Modules"))
    # macOS installs keep fusionscript.so inside the app bundle
    # (Contents/Libraries/Fusion/), not under {API}/Modules — CDLL preload
    # alone loads it without making it importable.
    sys.path.append(os.path.dirname(lib))
    try:
        # Preloading the shared library lets fusionscript locate it even when
        # installed at a nonstandard path (App Store builds move it).
        ctypes.CDLL(lib)
        import fusionscript  # noqa: PLC0415 — import path assembled above
    except OSError as exc:
        raise BridgeFailure(
            "resolve-lib-unloadable",
            "Couldn't load Resolve's scripting library (check the "
            "RESOLVE_SCRIPT_LIB environment variable).",
        ) from exc
    except ImportError as exc:
        raise BridgeFailure(
            "resolve-module-missing",
            "fusionscript module unavailable under Resolve's scripting "
            "Modules directory.",
        ) from exc

    resolve = fusionscript.scriptapp("Resolve")
    if resolve is None:
        raise BridgeFailure(
            "resolve-not-running",
            "Couldn't attach to a running DaVinci Resolve — is it open, and "
            "is external scripting enabled (Preferences > System > General)?",
        )
    return resolve


def check_version(resolve):
    """Bridge rule 4: unsupported versions fail loudly, up front."""
    version = resolve.GetVersionString() or ""
    try:
        major = int(version.split(".")[0])
    except ValueError:
        raise BridgeFailure(
            "resolve-version-unparseable",
            f"Couldn't parse Resolve version {version!r}.",
        ) from None
    if major < MIN_RESOLVE_MAJOR:
        raise BridgeFailure(
            "resolve-version-unsupported",
            f"Resolve {version} is below the supported floor "
            f"(>= {MIN_RESOLVE_MAJOR}). Please update DaVinci Resolve.",
        )
    return version


def open_project_timeline(resolve):
    # Resolve 21 builds return None from the direct call even with a project
    # open; the project-manager route is correct on every probed version.
    project = None
    project_manager = resolve.GetProjectManager()
    if project_manager is not None:
        project = project_manager.GetCurrentProject()
    if project is None:
        raise BridgeFailure(
            "no-project-open",
            "No project is open in Resolve — open one and retry.",
        )
    timeline = project.GetCurrentTimeline()
    if timeline is None:
        raise BridgeFailure(
            "no-timeline-open",
            f"Project {project.GetName()!r} has no focused timeline — "
            "open one and retry.",
        )
    return project, timeline


def _ensure_edit_page(resolve):
    """Fusion comp/tool access (InsertFusionTitleIntoTimeline, a tool's
    SaveSettings(), etc.) has been live-observed to fail with an opaque
    `TypeError: 'NoneType' object is not callable` when Resolve's active page
    isn't Edit — e.g. right after Pull Audio, which switches Resolve to the
    Deliver page to run its render job, and the user never manually switches
    back before the next Fusion-touching action. Best-effort: older Resolve
    majors may not expose OpenPage, and a failure here should never block the
    actual operation — worst case, the caller's own Fusion calls fail with
    their existing, more specific error.
    """
    try:
        resolve.OpenPage("edit")
    except (AttributeError, TypeError):
        pass


def _create_scratch_timeline(media_pool, target_resolution=None):
    """Create the shared scratch timeline, sized to the REAL target
    timeline.

    `CreateEmptyTimeline(name)` always inherits the PROJECT's default
    Master Settings resolution — a settings dict passed to it is silently
    ignored on this Resolve major (live-verified 2026-08-26 under several
    plausible key names). The fix is `SetSetting` on the newly created,
    still-EMPTY timeline, which does take: `useCustomSettings=1` followed
    by timelineResolutionWidth/Height all return True and read back
    correctly (live-verified 2026-08-27). An earlier note here claimed
    SetSetting "returns False too" and routed the fix through
    `comp.SetPrefs(Comp.FrameFormat…)` instead — that was wrong on both
    counts: SetPrefs changes the comp's own frame format but does NOT
    change the resolution `CreateFusionClip` bakes at, so captions kept
    coming out 1920x1080 on a 1080x1920 edit (the live-reported "fusion
    clips are 16x9 and my timeline is 9x16"). The baked clip inherits the
    resolution of the TIMELINE it is baked on, so that is what has to
    match.

    `target_resolution` is `(width, height)` or None (None = leave at the
    project default, which is already correct for a timeline that doesn't
    override it).
    """
    creator = getattr(media_pool, "CreateEmptyTimeline", None)
    if not callable(creator):
        return None
    scratch = creator(SCRATCH_TIMELINE_NAME)
    if scratch is None or not target_resolution:
        return scratch
    width, height = target_resolution
    if not width or not height:
        return scratch
    # Order matters: the resolution overrides are ignored unless the
    # timeline is first switched off "use project settings".
    for key, value in (("useCustomSettings", "1"),
                       ("timelineResolutionWidth", str(int(width))),
                       ("timelineResolutionHeight", str(int(height)))):
        try:
            scratch.SetSetting(key, value)
        except Exception:
            pass  # best-effort: a wrong-aspect bake still beats no captions
    return scratch


def _apply_comp_frame_format(comp, target_resolution):
    """Align a freshly created comp's own frame format with the REAL target
    timeline's resolution (width, height), so the comp is authored and
    previewed at the shape it will be rendered at.

    NOT the aspect-ratio fix, despite an earlier comment here claiming it
    was: `comp.SetPrefs` does change `Comp.FrameFormat.Width/Height`, but
    live-verified 2026-08-27 it does NOT change the resolution
    `CreateFusionClip` bakes at — with only this in place, captions still
    came out 1920x1080 on a 1080x1920 edit. The baked clip inherits the
    resolution of the TIMELINE it is baked on, so the real fix is sizing
    the scratch timeline itself (`_create_scratch_timeline`). This stays
    because a comp whose frame format disagrees with its timeline is a
    confusing thing to hand a user or a later debugging session.
    Best-effort: an unreadable target resolution, or an older Fusion
    without this pref, leaves the comp as-is rather than blocking
    authoring over cosmetics.
    """
    if not target_resolution:
        return
    width, height = target_resolution
    if not width or not height:
        return
    try:
        comp.SetPrefs({
            "Comp.FrameFormat.Width": width,
            "Comp.FrameFormat.Height": height,
        })
    except Exception:
        pass


def _timeline_resolution(timeline):
    """(width, height) from the timeline's own settings, or None if either
    is unreadable — see `_apply_comp_frame_format`."""
    try:
        width = timeline.GetSetting("timelineResolutionWidth")
        height = timeline.GetSetting("timelineResolutionHeight")
    except Exception:
        return None
    try:
        return (int(width), int(height))
    except (TypeError, ValueError):
        return None


def _timeline_item_count(timeline):
    """Total clip items across all video tracks — part of the identity token."""
    total = 0
    track_count = int(timeline.GetTrackCount("video") or 0)
    for idx in range(1, track_count + 1):
        items = timeline.GetItemListInTrack("video", idx) or {}
        total += len(items)
    return total


# --------------------------------------------------------------------------
# Modes
# --------------------------------------------------------------------------

def _timeline_identity_key(timeline):
    """Cheap identity check for one timeline object — `GetUniqueId()` when
    available (same mechanism `_timeline_identity` uses for the full
    verification token), name otherwise. Used by
    `_verify_current_timeline_is` to confirm `SetCurrentTimeline` actually
    landed where it claims to (a fail-quiet API returning True is not
    proof — see that function's doc comment)."""
    try:
        unique_id = timeline.GetUniqueId()
        if unique_id:
            return unique_id
    except (AttributeError, TypeError):
        pass
    return timeline.GetName()


def _verify_current_timeline_is(project, expected_timeline):
    """`SetCurrentTimeline` returning True is not proof placement will
    actually land where intended — if the user (or Resolve itself) changes
    the current timeline again in the window between this switch-back and
    the `AppendToTimeline` call that follows it, clips could silently place
    onto a DIFFERENT timeline (or nowhere, if that timeline no longer
    exists) while this run still reports success. This is the strongest
    documented lead for "clips baked but never appeared on my timeline"
    that isn't the locked-track case (already handled separately) — no
    prior probe reproduced it directly, so this fails loud rather than
    silently trusting the fail-quiet switch.
    """
    current = project.GetCurrentTimeline()
    if current is None:
        raise BridgeFailure(
            "placement-target-lost",
            "Switched back to the target timeline for placement, but "
            "Resolve now reports no current timeline at all — placement "
            "would land nowhere. Re-open the timeline in Resolve and try "
            "again.",
        )
    if _timeline_identity_key(current) != _timeline_identity_key(expected_timeline):
        raise BridgeFailure(
            "placement-target-mismatch",
            "Switched back to the target timeline for placement, but "
            f"Resolve's current timeline is now {current.GetName()!r} — "
            "something (a click in Resolve's UI, or another operation) "
            "changed it in between. Nothing was placed on the wrong "
            "timeline; re-open the correct one in Resolve and try again.",
        )


def _timeline_identity(project, timeline):
    """The composite identity token pieces shared by `info` and token
    verification in mutating modes (ARCHITECTURE.md §2 rule 5)."""
    fps_raw = timeline.GetSetting("timelineFrameRate")
    try:
        fps = float(fps_raw)
    except (TypeError, ValueError):
        raise BridgeFailure(
            "fps-unparseable",
            f"Timeline frame rate {fps_raw!r} isn't a number.",
        ) from None

    unique_id = None
    try:
        unique_id = timeline.GetUniqueId()
    except (AttributeError, TypeError):
        pass  # older Resolve majors may not expose it; name remains as fallback identity

    start_frame = int(timeline.GetStartFrame())
    item_count = _timeline_item_count(timeline)
    project_name = project.GetName()
    timeline_name = timeline.GetName()

    composite = (
        f"{project_name}|{unique_id or timeline_name}"
        f"|start={start_frame}|fps={fps}|items={item_count}"
    )

    token = {
        "projectName": project_name,
        "timelineName": timeline_name,
        "timelineId": unique_id,
        "startFrame": start_frame,
        "fps": fps,
        "itemCount": item_count,
        "compositeToken": composite,
    }
    return token, fps, start_frame


def _composite_token_without_item_count(token):
    """Strip the trailing `|items=N` segment off a composite identity token
    string (always the last segment — see `_timeline_identity`)."""
    return token.rsplit("|items=", 1)[0]


def verify_token(request, project, timeline, *, ignore_item_count=False):
    """Verify a timeline identity token. Mutating modes call this before
    committing work. The caller echoes back the compositeToken it got from a
    recent `info` call; mismatch = fail loud, never silent misplacement.

    `ignore_item_count=True` compares every field except item count —
    for a multi-call operation whose EARLIER step already, legitimately,
    changed the timeline's item count (live-verified: Capture Style's
    capture/discard phases reuse the token minted before `insert` ran, and
    `insert` itself adds a clip — with item count included, every capture/
    discard call would deterministically token-mismatch against its own
    insert, which is exactly the "Timeline changed since the caller's
    `info` snapshot" error a real user hit here). Project/timeline
    identity/start/fps are still compared — this only stops the check from
    being fooled by a mutation the operation caused itself.
    """
    expected = request.get("expectedToken")
    if not expected:
        raise BridgeFailure(
            "token-missing",
            "This mode mutates the timeline and requires an identity token — "
            "call `info` first and pass its token.compositeToken back as "
            "`expectedToken`.",
        )
    current = _timeline_identity(project, timeline)[0]["compositeToken"]
    expected_compare = _composite_token_without_item_count(expected) if ignore_item_count else expected
    current_compare = _composite_token_without_item_count(current) if ignore_item_count else current
    if expected_compare != current_compare:
        raise BridgeFailure(
            "token-mismatch",
            "Timeline changed since the caller's `info` snapshot "
            f"(expected {expected!r}, now {current!r}) — refusing to act on "
            "a stale view. Re-run `info` and retry.",
        )


# Ownership marker prefixes: every clip this app authors onto the animate
# track carries one, so environment setup can clear stale app-owned work
# without ever touching the editor's own content. `-L` marks the per-line
# multi-clip model, `-W` the window-baked persistent-title model
# (docs/PERSISTENT-TITLE-DESIGN.md); cleanup targets BOTH so a switch of
# models never strands stale work on the user's track.
OWNED_CLIP_PREFIX = "CaptionSuite-L"
OWNED_WINDOW_PREFIX = "CaptionSuite-W"
OWNED_PREFIXES = (OWNED_CLIP_PREFIX, OWNED_WINDOW_PREFIX)

ANIMATE_TRACK_NAME = "CaptionSuite Animate"


def _matches_any_prefix(name, prefixes):
    return bool(name) and any(
        str(name).startswith(prefix) for prefix in prefixes)


# --------------------------------------------------------------------------
# Multi-Clip per-line authoring (ARCHITECTURE.md §6)
#
# Ported from the field-proven builders in the Resolve Plugins repo
# (fusion_textplus.py / placement.py) — no external import dependency;
# invariants are non-negotiable per §6:
#   strip modifiers before spline attach; trailing pin to 1.0;
#   line-local baselines; author fully before baking; undo-bracketed writes.
# --------------------------------------------------------------------------

def _find_or_create_textplus(comp):
    """Find an existing TextPlus tool in the comp, or create one."""
    tools = comp.GetToolList(False) or {}
    for tool in tools.values():
        if getattr(tool, "ID", None) == "TextPlus":
            return tool
    tool = comp.AddTool("TextPlus")
    if not tool:
        raise BridgeFailure(
            "textplus-create-failed",
            "Couldn't create a TextPlus tool (fail-quiet API returned None).",
        )
    return tool


def _find_media_out(comp):
    """Find the comp's MediaOut tool (the only render exit a Resolve title
    comp has — Fusion renders ONLY what feeds it)."""
    for tool in (comp.GetToolList(False) or {}).values():
        if getattr(tool, "ID", None) == "MediaOut":
            return tool
    raise BridgeFailure(
        "no-mediaout",
        "The Fusion comp exposes no MediaOut tool — nothing can render.",
    )


def _merge_over(comp, tail_tool, top_tool, context):
    """Composite `top_tool` OVER `tail_tool` via a new Merge and return the
    Merge (the chain's new tail).

    Live finding (2026-08-25, Resolve 21.0.4.5): comp.AddTool does NOT
    auto-connect anything into the dataflow — a second TextPlus added to an
    inserted Text+ comp is orphaned and never renders, because MediaOut keeps
    consuming only its original input. Every extra tool MUST be merged into
    the chain feeding MediaOut (base -> Background, overlay -> Foreground).
    Connection MUST use attribute assignment with .Output — SetInput with a
    tool object is a fail-quiet NO-OP on this build (mis-wiring surfaces at
    bake/render time, which is why the wiring happens under the same undo
    bracket as authoring). Proven pattern (highlight_placement.py):
        merge.Background = base_tool.Output
        merge.Foreground = overlay_tool.Output
        media_out.Input = merge_tool.Output
    """
    merge = comp.AddTool("Merge")
    if not merge:
        raise BridgeFailure(
            "overlay-merge-failed",
            f"{context}: couldn't create a Merge tool "
            "(fail-quiet API returned None).",
        )
    merge.Background = tail_tool.Output
    merge.Foreground = top_tool.Output
    return merge


def _resolve_style_payload(request):
    """Resolve the optional request-level captured style to the RAW
    SaveSettings dict that Text+ LoadSettings() expects.

    Two accepted forms (BOTH executor modes):

    - ``stylePayload``: object — the app reads the .capproj preset file and
      sends ONLY its ``settings`` member; the bridge stays decoupled from the
      .capproj on-disk layout.
    - ``stylePath``: str — convenience/testing alternative; the bridge reads
      the preset file itself ({id, name, createdAt, settings, ...}) and
      extracts ``settings``.

    Returns None when neither field is present. Malformed input fails loud
    with a structured error BEFORE any timeline mutation happens.
    """
    payload = request.get("stylePayload")
    if payload is not None:
        if not isinstance(payload, dict):
            raise BridgeFailure(
                "bad-style-payload",
                f"stylePayload must be a JSON object (the raw SaveSettings "
                f"dict), got {type(payload).__name__}.",
            )
        return payload

    path = request.get("stylePath")
    if not path:
        return None
    if not isinstance(path, str):
        raise BridgeFailure(
            "bad-style-payload",
            f"stylePath must be a string path, got "
            f"{type(path).__name__}.",
        )
    
    # Validate the path to prevent path traversal and injection attacks
    normalized_path = os.path.normpath(path)
    
    # Check for path traversal attempts (e.g., containing "..")
    if ".." in normalized_path.split(os.sep):
        raise BridgeFailure(
            "style-path-invalid",
            f"Invalid stylePath {path!r}: path traversal attempt detected.",
        )
    
    # Ensure the path is within allowed directories (e.g., app's working directory)
    try:
        # Get the absolute path of the requested file
        abs_path = os.path.abspath(path)
        
        # Get the absolute path of working directory to ensure we're not 
        # trying to access files outside our allowed scope
        working_dir = os.getcwd()
        abs_working_dir = os.path.abspath(working_dir)
        
        # Check that the requested file is within our working directory
        if not abs_path.startswith(abs_working_dir + os.sep):
            raise BridgeFailure(
                "style-path-invalid",
                f"Invalid stylePath {path!r}: path is outside allowed scope.",
            )
    except Exception:
        # If we cannot determine the absolute paths, fail safe
        raise BridgeFailure(
            "style-path-invalid",
            f"Invalid stylePath {path!r}: cannot verify path location.",
        )
    
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except OSError as exc:
        raise BridgeFailure(
            "style-path-unreadable",
            f"Couldn't read stylePath {path!r}: {exc}",
        ) from exc
    except json.JSONDecodeError as exc:
        raise BridgeFailure(
            "style-path-unparseable",
            f"stylePath {path!r} isn't valid JSON: {exc}",
        ) from exc
    settings = data.get("settings") if isinstance(data, dict) else None
    if not isinstance(settings, dict):
        raise BridgeFailure(
            "bad-style-payload",
            f"The preset file at {path!r} carries no \"settings\" object "
            "(expected the .capproj style layout "
            "{id, name, createdAt, settings, ...}).",
        )
    return settings


def _resolve_overlay_style_payload(request, fallback_style_payload=None):
    """Resolve the optional highlight-overlay style payload.

    If `highlightStylePayload` is absent, reuse the base style payload so the
    previous one-style behavior keeps working.
    """
    payload = request.get("highlightStylePayload")
    if payload is not None:
        if not isinstance(payload, dict):
            raise BridgeFailure(
                "bad-highlight-style-payload",
                f"highlightStylePayload must be a JSON object (the raw "
                f"SaveSettings dict), got {type(payload).__name__}.",
            )
        return payload
    return fallback_style_payload


def _tool_key(tool):
    """Stable identity for a Fusion tool across separate remote-proxy calls.

    Fusion hands back a NEW `BlackmagicFusion.PyRemoteObject` proxy on every
    lookup, so two proxies for the SAME tool are different Python objects and
    `a is b` is False. Live incident (2026-08-27): `_apply_captured_style`
    compared tools with `is` in all three of its relocation rungs, so for the
    highlight overlay the "same object still registered" check missed, the
    position snapshot came back empty, and — the damaging one — the
    `exclude` guard failed to recognise the base tool. The role-match rung
    then returned the BASE TextPlus as if it were the overlay: the window
    splines and the highlight colour were applied to the base, both Merge
    inputs became the same tool, the real overlay was left orphaned, and the
    render showed one highlighted word at a time with no white
    already-revealed words behind it.

    A tool's `Name` is unique within a comp and readable off any proxy, which
    makes it the identity to compare on. Returns None when unreadable, and
    callers treat None as "no match" rather than as a wildcard.
    """
    try:
        name = tool.Name
    except Exception:
        return None
    return str(name) if name is not None else None


def _same_tool(a, b):
    """True when two proxies refer to the same comp tool (see `_tool_key`)."""
    key_a = _tool_key(a)
    return key_a is not None and key_a == _tool_key(b)


def _apply_captured_style(comp, tool, payload, context, exclude=()):
    """Replay a captured SaveSettings payload onto `tool` and return a VALID
    TextPlus handle afterwards.

    Phase 0 A5 (VERIFICATION-RESULTS.md): LoadSettings() replays with full
    fidelity, BUT Fusion may RENAME replayed auxiliary tools (a captured
    spline came back as 'Template_1WriteOnEnd' next to the original) to avoid
    namespace collisions. The target TextPlus itself can likewise end up
    re-registered under a different list position/handle, so after the load
    we re-locate it by TOOL-LIST POSITION first, then by ROLE (its ID
    attribute) — never by a remembered name.

    Call-order contract (KEYFRAMES WIN OVER LOADED STATE): LoadSettings runs
    FIRST because it overwrites EVERY input incl. text and may re-attach
    captured spline modifiers; callers then set StyledText/Start, STRIP
    modifiers (removing any spline state the load brought in), and only then
    attach their own splines. Keep that ordering intact.
    """
    position_key = None
    try:
        for key, candidate in (comp.GetToolList(False) or {}).items():
            if _same_tool(candidate, tool):
                position_key = key
                break
    except Exception:
        pass  # fail-quiet snapshot; role-based relocation still applies

    try:
        tool.LoadSettings(payload)
    except Exception as exc:
        raise BridgeFailure(
            "style-load-failed",
            f"{context}: LoadSettings() raised: {exc}",
        ) from exc
    # Note: LoadSettings is a fail-quiet API — its return value is not
    # treated as authoritative here; a silent no-op shows up downstream as
    # unstyled output, which the live smoke test guards against.

    tools = {}
    try:
        tools = dict(comp.GetToolList(False) or {})
    except Exception:
        pass
    if not tools:
        # Unreadable or empty tool-list snapshot (fail-quiet API): keep the
        # original handle — the load itself already succeeded, and the very
        # next SetInput calls will surface a genuinely broken tool loudly.
        return tool
    # Same object still registered -> nothing moved, reuse it.
    for candidate in tools.values():
        if _same_tool(candidate, tool):
            return tool
    # Same tool-list POSITION (A5: match by position, not name).
    if position_key is not None and position_key in tools:
        relocated = tools[position_key]
        if getattr(relocated, "ID", None) == "TextPlus":
            return relocated
    # Last resort: role match. With multi-tool comps (base + overlay per
    # cue), a TextPlus role is no longer unique — never steal an `exclude`
    # handle (the other tools this authoring pass already owns).
    for candidate in tools.values():
        if getattr(candidate, "ID", None) == "TextPlus" \
                and not any(_same_tool(candidate, x) for x in exclude):
            return candidate
    raise BridgeFailure(
        "textplus-relocate-failed",
        f"{context}: couldn't re-locate the TextPlus after LoadSettings() "
        "— the comp holds no TextPlus-role tool anymore.",
    )


def _parse_hex_color(value):
    """Parse '#RRGGBB'/'#RGB' into (r, g, b) floats in 0..1 (Text+ fill
    color inputs Red1/Green1/Blue1). None passes through; anything else
    fails loud BEFORE any timeline mutation.

    Tolerates the shapes a copy-pasted swatch realistically arrives in:
    surrounding quotes (some apps' "copy as hex" wraps the value), and an
    8-digit #RRGGBBAA (common from browser/design-tool color pickers) —
    the alpha channel is dropped since the Text+ fill input this feeds has
    none.
    """
    if value is None:
        return None
    text = str(value).strip().strip("\"'").strip().lstrip("#").strip()
    if len(text) == 8:
        text = text[:6]  # drop AA; #RRGGBBAA is a common copy-paste shape
    if len(text) not in (3, 6):
        raise BridgeFailure(
            "bad-highlight-color",
            f"highlightColor {value!r} must be a #RRGGBB hex string.",
        )
    try:
        if len(text) == 3:
            return tuple(
                int(ch * 2, 16) / 255.0 for ch in text)
        return tuple(
            int(text[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    except ValueError:
        raise BridgeFailure(
            "bad-highlight-color",
            f"highlightColor {value!r} isn't valid hex.",
        ) from None


def _apply_highlight_color(tool, rgb):
    """Set a TextPlus's FILL color (the 'Color 1' swatch under Character
    styling) — what makes the highlight overlay visually distinct from the
    base layer. Input IDs are Red1/Green1/Blue1 ('Red 1' etc. in the UI);
    must run AFTER any LoadSettings, which overwrites every input."""
    if not rgb:
        return
    for input_name, channel in zip(("Red1", "Green1", "Blue1"), rgb):
        tool.SetInput(input_name, float(channel))


# Every input that determines where a Text+ places its line and how wide it
# renders: position/anchor (Layout tab), the layout box, and the font
# metrics that set the block's width. The highlight overlay MUST end up
# with the exact same values as its base tool or the two layers render at
# different scales/positions.
#
# Live finding (2026-08-25, Resolve 21.0.4.5): the base TextPlus comes from
# InsertFusionTitleIntoTimeline — Resolve's TITLE TEMPLATE, whose default
# Size is 0.09 — while the overlay comes from comp.AddTool("TextPlus"),
# whose default Size is 0.08. Without a captured style to overwrite both,
# every highlighted word rendered ~11% smaller than its base counterpart
# and offset toward center, so the line visibly shifted at each highlight
# step. Mirroring this input set base -> overlay makes both layers occupy
# identical geometry from frame one.
#
# Reveal stability needs no extra anchoring on 21.0.4.5 (live-measured):
# Text+ lays out the FULL StyledText once and Start/End only gate which
# characters render, so a revealing layer keeps its left edge pixel-static
# and windowed words land at their true in-line positions. Copying these
# inputs pins BOTH layers to the SAME static layout, which is the invariant
# the composite depends on; forcing a specific anchor value (e.g. fixed-
# left) was probed and rejected — non-center H Anchor values re-position
# the block against Layout Center with edge clipping instead of pinning it.
_LAYOUT_MIRROR_INPUTS = (
    # Position + anchor (Layout tab)
    "Center", "Pivot",
    "HorizontalLeftCenterRight", "VerticalTopCenterBottom",
    "CenterOnBaseOfFirstLine",
    # Layout box / frame
    "LayoutType", "LayoutSize", "LayoutWidth", "LayoutHeight",
    "Width", "Height",
    # Font metrics — they set the block width the reveal grows within
    # (`Style` is the font weight — live diff: title-template TextPlus
    # carries 'Semibold' while a fresh AddTool TextPlus defaults to
    # 'Bold', whose wider glyphs shifted every highlight word ~25px).
    "Font", "Style", "Size",
    "CharacterSpacing", "WordSpacing", "LineSpacing",
)


def _mirror_layout_inputs(src_tool, dst_tool):
    """Copy every layout-determining input from `src_tool` onto `dst_tool`
    so both render their line at the same position and scale.

    Point inputs come back from GetInput as {1: x, 2: y, 3: z} tables;
    SetInput wants a tuple for those, so dicts are converted. Failures are
    skipped per-input (fail-quiet API surface) — a mirrored subset still
    beats an unmirrored overlay, and the E2E frame check catches real
    divergence.
    """
    for name in _LAYOUT_MIRROR_INPUTS:
        try:
            value = src_tool.GetInput(name)
        except Exception:
            continue
        if value is None:
            continue
        if isinstance(value, dict):
            value = (value.get(1), value.get(2))
        try:
            dst_tool.SetInput(name, value)
        except Exception:
            pass


def _strip_spline_modifiers(tool, input_names=("Start", "End")):
    """Strip existing modifiers from inputs before attaching new splines.

    Per invariant: modifiers persist across runs — a spline attached in an
    earlier pass stays attached and silently animates a later one, so this
    MUST run before every fresh spline attach. A plain static value (not a
    connected modifier) is left alone.
    """
    for name in input_names:
        current = getattr(tool, name, None)
        if current is None:
            continue
        try:
            output = current.GetConnectedOutput()
            source_tool = output.GetTool() if output is not None else None
            if source_tool is not None:
                source_tool.Delete()
        except AttributeError:
            pass  # not a connected modifier — nothing to strip


def _curve_entries(curve):
    """Normalize a keyframe curve from the AnimationDocument.

    Accepts {"entries": [{"frame", "value"}...], "isStepped": bool} (the
    Swift shape) or a bare list of entries. Returns (entries, stepped).
    """
    if isinstance(curve, dict):
        return list(curve.get("entries") or []), bool(curve.get("isStepped", True))
    return list(curve or []), True


def _lead_start_entries(entries, text=""):
    """Lead each overlay Start entry's VALUE back by half a character
    cell, keying Start on the SAME onset frames as End.

    Live findings (2026-08-25, frame-export evidence):
    - Values (the chop mechanism): Text+ highlights a character only when
      char_start > Start (STRICT), so a Start value of exactly the word's
      start fraction always drops the leading glyph ('o' of "over") as a
      white fragment — a static Start keyed at frame 0 reproduces the
      chop pixel-identically, ruling out spline timing. Leading the value
      by half a char cell (0.5 / len(text)) pulls the leading glyph in
      while still excluding the preceding space/word.
    - Timing: Start must NOT be keyed a frame earlier than End. During
      that frame Start already points at the next word while End still
      ends the previous word -> empty window -> base shows through as a
      one-frame white gap at every transition (live-verified).
    """
    total = max(len(text or ""), 1)
    half_cell = 0.5 / total
    led = []
    for entry in entries:
        frame = int(entry["frame"])
        value = float(entry["value"])
        if value > 0.0:
            value = max(value - half_cell, 0.0)
        led.append({"frame": frame, "value": value})
    return led


def _attach_stepped_spline(comp, tool, input_name, entries, stepped=True,
                           clip_length_frames=None, trailing_pin_value=1.0):
    """Build a BezierSpline from entries and attach it to the input.

    entries: list of {"frame": int, "value": float} — comp-local frames
    (line-local baseline; the Swift composer converts before sending).
    When clip_length_frames is given, a TRAILING KEYFRAME pinned to
    trailing_pin_value is forced at the clip's last VISIBLE frame
    (clip_length_frames - 1 — a Bezier curve drifts after its last
    keyframe and un-reveals text, confirmed pitfall; it intentionally
    overrides any entry that happens to land on the same frame), and any
    entry keyed at or beyond clip_length_frames is clamped to that same
    last visible frame so completion is always reachable on screen.

    Construction matches the field-proven pattern in Resolve Plugins'
    fusion_textplus.py exactly: the modifier is created with the
    comp.BezierSpline({}) CONSTRUCTOR (AddTool registers a spline as a
    full comp TOOL instead, whose evaluation ignores the per-key StepIn/
    StepOut flags -> linear ramps between word onsets), attached to the
    input via ATTRIBUTE ASSIGNMENT (SetInput with a tool/modifier object
    is a fail-quiet no-op on this build), and only THEN handed its
    keyframe table.
    """
    if not entries and clip_length_frames is None:
        raise BridgeFailure(
            "missing-keyframes",
            f"Cannot attach a spline to {input_name!r}: no keyframe entries.",
        )
    try:
        spline = comp.BezierSpline({})
    except Exception:
        spline = None
    if not spline:
        raise BridgeFailure(
            "spline-create-failed",
            f"Couldn't create a BezierSpline for {input_name!r} "
            "(fail-quiet API returned None).",
        )
    flags = {"StepIn": True, "StepOut": True} if stepped else None
    # Comp-local frames are 0..clip_length-1, so anything keyed AT or beyond
    # clip_length_frames never displays. Clamp every such entry (and the
    # trailing pin) to the last VISIBLE frame so completion is always
    # reachable on screen (live finding, 2026-08-25).
    max_visible_frame = (
        float(clip_length_frames) - 1.0
        if clip_length_frames is not None else None)
    table = {}
    for entry in entries:
        frame = float(entry["frame"])
        if (max_visible_frame is not None
                and frame > max_visible_frame):
            frame = max_visible_frame
        row = {1: float(entry["value"])}
        if flags is not None:
            row["Flags"] = dict(flags)
        table[frame] = row
    if max_visible_frame is not None:
        row = {1: float(trailing_pin_value)}
        if flags is not None:
            row["Flags"] = dict(flags)
        table[max_visible_frame] = row
    # Proven order (fusion_textplus.py): attach FIRST, keyframes SECOND.
    setattr(tool, input_name, spline)
    spline.SetKeyFrames(table, True)
    return spline


SPEECH_ALIGNMENT_OVERFLOW_GUIDANCE = (
    "Return to Speech Alignment, adjust Caption Layout, apply it, and "
    "animate again."
)


def _probe_textplus_overflow(comp, tool, identifier, target_resolution,
                             fully_revealed_frame=None):
    """Verify a configured Text+ while its raw Fusion comp is reachable.

    This is deliberately the only authoritative overflow check.  DataWindow
    is Fusion's rendered-pixel extent (left, bottom, right, top), so compare
    it with the actual target timeline raster, not the captured style frame.
    Missing or malformed remote data is a blocking acknowledgement-required
    result; it is never interpreted as safe.
    """
    width, height = target_resolution or (None, None)
    if not isinstance(width, int) or not isinstance(height, int) \
            or width <= 0 or height <= 0:
        raise BridgeFailure(
            "overflow-probe-unavailable",
            f"Caption {identifier}: exact overflow probe could not use the "
            "target timeline resolution. " + SPEECH_ALIGNMENT_OVERFLOW_GUIDANCE,
            extra={"overflowProbe": {
                "status": "acknowledgement-required",
                "identifier": str(identifier),
                "reason": "invalid-or-missing-target-resolution",
                "targetResolution": [width, height],
            }},
        )

    # The animation curves are attached before this call.  Move the raw comp
    # to its final visible frame so GetValue() evaluates the fully revealed
    # caption.  Resolve builds differ in which spelling they expose; both
    # are best-effort because the DataWindow read below remains authoritative.
    if fully_revealed_frame is not None:
        frame = int(fully_revealed_frame)
        positioned = False
        setter = getattr(comp, "SetCurrentTime", None)
        if callable(setter):
            try:
                # Resolve commonly returns None for a successful setter, so
                # only an explicit False is a failure.
                positioned = setter(frame) is not False
            except Exception:
                positioned = False
        if not positioned:
            try:
                comp.CurrentTime = frame
                positioned = True
                # When a readable remote property is available, reject a
                # setter that silently landed on another frame.
                current = getattr(comp, "CurrentTime", None)
                if isinstance(current, (int, float)) and int(current) != frame:
                    positioned = False
            except Exception:
                positioned = False
        if not positioned:
            raise BridgeFailure(
                "overflow-probe-unavailable",
                f"Caption {identifier}: Resolve could not evaluate the "
                "fully revealed frame. " + SPEECH_ALIGNMENT_OVERFLOW_GUIDANCE,
                extra={"overflowProbe": {
                    "status": "acknowledgement-required",
                    "identifier": str(identifier),
                    "reason": "fully-revealed-frame-unavailable",
                    "targetResolution": [width, height],
                }},
            )

    try:
        value = tool.Output.GetValue()
        data_window = value.DataWindow
    except Exception as exc:
        raise BridgeFailure(
            "overflow-probe-unavailable",
            f"Caption {identifier}: Resolve did not provide a readable "
            f"Text+ DataWindow ({type(exc).__name__}). "
            + SPEECH_ALIGNMENT_OVERFLOW_GUIDANCE,
            extra={"overflowProbe": {
                "status": "acknowledgement-required",
                "identifier": str(identifier),
                "reason": "missing-data-window",
                "targetResolution": [width, height],
            }},
        ) from exc

    values = None
    if isinstance(data_window, dict):
        values = [data_window.get(k) for k in (1, 2, 3, 4)]
        if any(v is None for v in values):
            values = [data_window.get(k) for k in
                      ("left", "bottom", "right", "top")]
    elif isinstance(data_window, (list, tuple)):
        values = list(data_window[:4])
    try:
        if values is None or len(values) != 4:
            raise ValueError("expected four coordinates")
        bounds = [float(v) for v in values]
        if not all(math.isfinite(v) for v in bounds):
            raise ValueError("coordinates are not finite")
    except (TypeError, ValueError) as exc:
        raise BridgeFailure(
            "overflow-probe-unavailable",
            f"Caption {identifier}: Resolve returned an invalid Text+ "
            "DataWindow. " + SPEECH_ALIGNMENT_OVERFLOW_GUIDANCE,
            extra={"overflowProbe": {
                "status": "acknowledgement-required",
                "identifier": str(identifier),
                "reason": "invalid-data-window",
                "renderedDataWindow": data_window,
                "targetResolution": [width, height],
            }},
        ) from exc

    left, bottom, right, top = bounds
    finding = {
        "identifier": str(identifier),
        "renderedDataWindow": bounds,
        "targetResolution": [width, height],
        "message": SPEECH_ALIGNMENT_OVERFLOW_GUIDANCE,
    }
    if left < 0 or bottom < 0 or right > width or top > height:
        raise BridgeFailure(
            "caption-overflow",
            f"Caption {identifier} renders outside the {width}×{height} "
            "target frame. " + SPEECH_ALIGNMENT_OVERFLOW_GUIDANCE,
            extra={"overflowFindings": [finding], "overflowProbe": {
                "status": "verified-overflow",
                "findings": [finding],
            }},
        )
    return finding


def _author_clip_on_track(timeline, track_index, media_pool, bin_folder,
                          clip_doc, line_number, request_style=None,
                          highlight_style=None,
                          highlight_color=None, target_resolution=None,
                          probe_findings=None):
    """Author ONE AnimatedClip as a TextPlus and bake it into a Fusion clip.

    `target_resolution` is the REAL target timeline's (width, height),
    used to keep this comp's own frame format consistent with the timeline
    it bakes on. The bake resolution itself comes from that scratch
    timeline, which the caller sized to match (`_create_scratch_timeline`);
    live-reported bug when it did not: a 9:16 real timeline in a
    16:9-default project baked every caption at 16:9.

    `request_style` is the optional request-level captured style payload (raw
    SaveSettings dict from stylePayload/stylePath); the clip's own embedded
    `styleSettings` takes precedence when both are present.

    `highlight_style` is the optional second style payload for the highlight
    overlay TextPlus; when absent, the base style is reused.

    `highlight_color` is the optional #RRGGBB fill color for the highlight
    overlay tool ONLY (the .capproj preset's HighlightWindowParams
    .highlightColor) — without a distinct color the composited overlay is
    pixel-identical to the base layer and the preset degrades to plain
    reveal.

    `timeline` must be a timeline whose video track `track_index` is safe to
    host the raw Text+ while its comp is reachable (a dedicated scratch
    timeline in production). NOT because InsertFusionTitleIntoTimeline is
    destructive to existing clips — PERSISTENT-TITLE-DESIGN.md F2 live-
    verified it is not (no ripple, no split, playhead inside an existing
    clip). The real reason: F2 also found it always lands at track 1's end
    and never targets any other track or position — useless for placing
    many lines at exact caption timings on a specific track, which is
    exactly what a scratch timeline sidesteps (bake in isolation, discard
    the wrapper, then use AppendToTimeline — a different, position-
    controllable API — for the real placement). The baked clip lands in the
    media pool's current folder, so the caller points the pool at
    `bin_folder` first; placement onto the real animate track is the
    executor's job via AppendToTimeline (non-destructive, frame-exact).

    Authoring is a one-way door: EVERYTHING (text, style, splines) is set
    here, under one undo bracket, BEFORE CreateFusionClip — a baked Fusion
    clip's comp is unreachable from the API afterwards.

    Returns the baked clip's ownership-marker name (CaptionSuite-L####).
    """
    try:
        start_frame = int(clip_doc.get("startFrame") or 0)
        end_frame = int(clip_doc.get("endFrame") or 0)
    except (TypeError, ValueError):
        raise BridgeFailure(
            "bad-clip-frames",
            f"Line {line_number}: startFrame/endFrame must be integers.",
        ) from None
    text = str(clip_doc.get("text") or "")
    # Comp/tool time is clip-local starting near 0 — the LINE's own
    # duration is the baseline (invariant: line-local baselines), never
    # anything read off the hosting timeline.
    clip_length = max(end_frame - start_frame, 1)
    clip_name = f"{OWNED_CLIP_PREFIX}{line_number:04d}"

    keyframes = clip_doc.get("keyframes")
    if not isinstance(keyframes, dict) or "End" not in keyframes:
        raise BridgeFailure(
            "missing-keyframes",
            f"Line {line_number}: animation document has no 'End' "
            "keyframe curve.",
        )
    end_curve = keyframes["End"]
    end_entries, end_stepped = _curve_entries(end_curve)
    if not end_entries:
        raise BridgeFailure(
            "missing-keyframes",
            f"Line {line_number}: 'End' keyframe curve has no entries.",
        )

    if bin_folder is not None:
        try:
            media_pool.SetCurrentFolder(bin_folder)
        except Exception:
            pass  # best-effort; worst case the clip lands in the current folder

    title_item = timeline.InsertFusionTitleIntoTimeline("Text+")
    if not title_item:
        raise BridgeFailure(
            "title-insert-failed",
            f"Line {line_number}: couldn't insert a Text+ title "
            "(fail-quiet API returned None).",
        )
    try:
        comp = title_item.GetFusionCompByIndex(1)
        if not comp:
            raise BridgeFailure(
                "no-comp",
                f"Line {line_number}: the inserted title's Fusion comp is "
                "not reachable.",
            )
        _apply_comp_frame_format(comp, target_resolution)
        tool = _find_or_create_textplus(comp)

        # Undo-bracketed writes around ALL comp mutations (invariant);
        # EndUndo(False) so a scratch comp doesn't accumulate permanent
        # entries in Fusion's undo stack across hundreds of lines.
        comp.StartUndo(f"Animate line {line_number}")
        try:
            style_settings = clip_doc.get("styleSettings") or request_style
            if style_settings:
                # Deliberate ORDER (keyframes win over loaded state):
                # LoadSettings FIRST (it overwrites EVERY input incl. text
                # and may re-attach captured spline modifiers), THEN
                # StyledText/Start, THEN strip modifiers (removing any
                # spline state the load brought in), THEN attach our own
                # splines. See _apply_captured_style for the A5 relocation.
                tool = _apply_captured_style(
                    comp, tool, style_settings, f"Line {line_number}")
            tool.SetInput("StyledText", text)
            tool.SetInput("Start", 0.0)
            _strip_spline_modifiers(tool, ("Start", "End"))
            _attach_stepped_spline(
                comp, tool, "End", end_entries,
                stepped=end_stepped, clip_length_frames=clip_length,
            )
            if probe_findings is not None:
                finding = _probe_textplus_overflow(
                    comp, tool, f"CaptionSuite-L{line_number:04d}",
                    target_resolution, fully_revealed_frame=clip_length - 1)
                probe_findings.append(finding)

            overlay_curves = clip_doc.get("overlayKeyframes")
            if overlay_curves:
                # Highlight-window preset: a SECOND TextPlus in the SAME
                # comp showing the same text, windowed via animated
                # Start/End so only the active word renders.
                overlay_tool = comp.AddTool("TextPlus")
                if not overlay_tool:
                    raise BridgeFailure(
                        "overlay-create-failed",
                        f"Line {line_number}: couldn't create the highlight "
                        "overlay TextPlus.",
                    )
                overlay_style = highlight_style or style_settings
                if overlay_style:
                    # Base and overlay can now carry distinct captured
                    # styles. `exclude` keeps A5 role-match relocation from
                    # stealing the base tool's handle in a multi-TextPlus
                    # comp.
                    overlay_tool = _apply_captured_style(
                        comp, overlay_tool, overlay_style,
                        f"Line {line_number} overlay", exclude=[tool])
                overlay_tool.SetInput("StyledText", text)
                _strip_spline_modifiers(overlay_tool, ("Start", "End"))
                start_curve = overlay_curves.get("Start")
                if start_curve:
                    s_entries, s_stepped = _curve_entries(start_curve)
                    if s_entries:
                        # Start value leads by half a char cell, keyed on
                        # the same frames as End (see _lead_start_entries).
                        _attach_stepped_spline(
                            comp, overlay_tool, "Start",
                            _lead_start_entries(s_entries, text),
                            stepped=s_stepped,
                        )
                end_curve_ov = overlay_curves.get("End")
                if end_curve_ov:
                    o_entries, o_stepped = _curve_entries(end_curve_ov)
                    _attach_stepped_spline(
                        comp, overlay_tool, "End", o_entries,
                        stepped=o_stepped, clip_length_frames=clip_length,
                    )
                # Composite the overlay into the render chain (root cause of
                # the invisible-highlight bug): AddTool does NOT connect the
                # new tool into the dataflow, and Fusion renders only what
                # feeds MediaOut. base -> Background, overlay -> Foreground;
                # MediaOut then consumes the Merge — via Output-attribute
                # assignment (SetInput with a tool object is a fail-quiet
                # no-op on 21.0.4.5). Same undo bracket as all other comp
                # mutations.
                # `highlight_color` is ALREADY a parsed (r, g, b) tuple —
                # the request-level parse happens once, up front, so a bad
                # value fails before any timeline mutation. Only the
                # per-clip override is still a raw hex string, so only it
                # gets parsed here. Parsing the fallback again fed a tuple
                # straight back into _parse_hex_color and raised
                # "highlightColor (1.0, 0.83..., 0.0) must be a #RRGGBB hex
                # string" — live-reported, and intermittent precisely
                # because a per-clip override masked it.
                _apply_highlight_color(
                    overlay_tool,
                    _parse_hex_color(clip_doc.get("highlightColor"))
                    or highlight_color)
                # Zero-movement invariant: the overlay must render its line
                # at EXACTLY the base's geometry (the template TextPlus and
                # a fresh AddTool TextPlus carry different default Size —
                # 0.09 vs 0.08 on 21.0.4.5 — which made every highlight
                # word jump). Mirror the base's layout inputs AFTER style +
                # color so identical values win regardless of either.
                _mirror_layout_inputs(tool, overlay_tool)
                media_out = _find_media_out(comp)
                merge = _merge_over(comp, tool, overlay_tool,
                                    f"Line {line_number}")
                media_out.Input = merge.Output
        finally:
            comp.EndUndo(False)

        baked_item = timeline.CreateFusionClip([title_item])
        if not baked_item:
            raise BridgeFailure(
                "bake-failed",
                f"Line {line_number}: CreateFusionClip returned None.",
            )
        pool_item = baked_item.GetMediaPoolItem()
        if not pool_item:
            raise BridgeFailure(
                "bake-failed",
                f"Line {line_number}: baked clip has no MediaPoolItem.",
            )
        pool_item.SetClipProperty("Clip Name", clip_name)
        return clip_name
    finally:
        # Always sweep the raw/baked items off the hosting track so the
        # next line's insert never lands on top of a leftover.
        try:
            leftover = timeline.GetItemListInTrack("video", track_index)
            if leftover:
                timeline.DeleteClips(list(leftover), False)
        except Exception as exc:
            # Cleanup is best-effort and must not replace an authoring/bake
            # failure with a cleanup failure.
            sys.stderr.write(f"warning: scratch item cleanup raised: {exc}\n")


def _ensure_track_unlocked(timeline, track_index, track_name):
    """`AppendToTimeline` is a well-known silent-fail case against a locked
    track (Resolve just returns nothing placed — no exception, no reason
    given, which is exactly the "clips baked but never land on the
    timeline" symptom this closes). This track is entirely app-owned (its
    only content is what this bridge itself places and clears — see
    `_clear_owned_clips`), so unlocking it automatically is safe: it can
    never touch a track outside the ones this executor created for itself.
    Older Resolve majors may not expose the lock API at all — best-effort,
    never fails the run over it.
    """
    try:
        locked = timeline.GetIsTrackLocked("video", track_index)
    except (AttributeError, TypeError):
        return
    if not locked:
        return
    try:
        unlocked = timeline.SetTrackLock("video", track_index, False)
    except (AttributeError, TypeError):
        unlocked = False
    if not unlocked:
        raise BridgeFailure(
            "track-locked",
            f"Track {track_index} ({track_name!r}) is locked and couldn't "
            "be unlocked automatically — unlock it in Resolve's timeline "
            "track header and try again. A locked track silently accepts "
            "no placed clips (Resolve gives no error for this), which is "
            "why baked clips never appeared on the timeline.",
        )


def _find_or_create_named_track(timeline, track_name):
    """Find the video track named `track_name` or add + rename one."""
    track_index = None
    track_count = int(timeline.GetTrackCount("video") or 0)
    for idx in range(1, track_count + 1):
        name = None
        try:
            name = timeline.GetTrackName("video", idx)
        except (AttributeError, TypeError):
            pass  # older majors may not expose track names
        if name == track_name:
            track_index = idx
            break

    if track_index is not None:
        _ensure_track_unlocked(timeline, track_index, track_name)
        return track_index

    if not timeline.AddTrack("video"):
        raise BridgeFailure(
            "track-add-failed",
            f"Couldn't add a video track for {track_name!r} "
            "(fail-quiet API returned False).",
        )
    new_count = int(timeline.GetTrackCount("video") or 0)
    if new_count <= track_count:
        raise BridgeFailure(
            "track-add-failed",
            "Video track was not created (track count unchanged).",
        )
    track_index = new_count
    renamed = False
    try:
        renamed = timeline.SetTrackName("video", track_index, track_name)
    except (AttributeError, TypeError):
        pass
    if not renamed:
        raise BridgeFailure(
            "track-rename-failed",
            f"Added video track {track_index} but couldn't rename it to "
            f"{track_name!r}.",
        )
    emit_progress("track-created", None, trackIndex=track_index)
    return track_index


def _find_or_create_bin(media_pool, bin_name):
    """Find a media-pool bin named `bin_name` under the pool root, or
    create it."""
    root_folder = None
    for getter in ("GetRootFolder", "GetRootMediaPool"):
        candidate = getattr(media_pool, getter, None)
        if callable(candidate):
            root_folder = candidate()
            break
    if root_folder is None:
        raise BridgeFailure(
            "bin-root-unavailable",
            "This Resolve build exposes neither GetRootFolder nor "
            "GetRootMediaPool on its media pool — cannot locate or create "
            f"bin {bin_name!r}.",
        )
    for folder in (root_folder.GetSubFolderList() or []):
        if folder.GetName() == bin_name:
            return folder
    bin_folder = media_pool.AddSubFolder(root_folder, bin_name)
    if not bin_folder:
        raise BridgeFailure(
            "bin-create-failed",
            f"Couldn't create media pool bin {bin_name!r} "
            "(fail-quiet API returned None).",
        )
    emit_progress("bin-created", None, binName=bin_name)
    return bin_folder


def _clear_owned_clips(timeline, track_index, prefixes=OWNED_PREFIXES,
                       preserve=None):
    """Delete only app-owned clips (CaptionSuite-L* / CaptionSuite-W*) from
    the track, then VERIFY the deletion took (bridge rule 7: fail loud,
    never leave stale app-owned work behind for placement to stack onto).

    `preserve` is an optional set of ownership-marker names to LEAVE in
    place (proofread-edit prefix reuse: unchanged clips keep their already
    baked+placed instances). Preserved items are neither deleted nor
    treated as deletion survivors.

    Post-clear verification re-scans the target track: any owned-marker item
    that survives despite a True return from DeleteClips is a silent API lie
    and aborts the run with `owned-clip-delete-failed`.
    """
    preserved = set(preserve or ())
    cleared = 0
    items = list(timeline.GetItemListInTrack("video", track_index) or [])
    owned = [
        item for item in items
        if _matches_any_prefix(item.GetName(), prefixes)
        and str(item.GetName() or "") not in preserved
    ]
    for clip in owned:
        clip_name = clip.GetName()
        # Live-verified on 21.0.4.5: Timeline.DeleteClips takes ONLY the
        # clip list — passing a trackType/trackIndex makes it fail-quiet
        # return False even for a valid item.
        try:
            deleted = timeline.DeleteClips([clip])
        except Exception as exc:
            raise BridgeFailure(
                "owned-clip-delete-failed",
                f"Deleting owned clip {clip_name!r} on track {track_index} "
                f"raised: {exc}",
            ) from exc
        if not deleted:
            raise BridgeFailure(
                "owned-clip-delete-failed",
                f"Deleting owned clip {clip_name!r} on track {track_index} "
                "returned False (fail-quiet API).",
            )
        cleared += 1

    # Post-clear verification: re-scan the track and refuse to continue if
    # ANY owned-clip-looking item remains (deletion silently failed).
    survivors = [
        item for item in (
            timeline.GetItemListInTrack("video", track_index) or [])
        if _matches_any_prefix(item.GetName(), prefixes)
        and str(item.GetName() or "") not in preserved
    ]
    if survivors:
        survivor_names = []
        for item in survivors:
            try:
                survivor_names.append(str(item.GetName() or "<unnamed>"))
            except Exception:
                survivor_names.append("<unreadable>")
        raise BridgeFailure(
            "owned-clip-delete-failed",
            f"Post-clear verification found {len(survivors)} owned clip(s) "
            f"still on track {track_index} ({', '.join(survivor_names)}) "
            "despite DeleteClips reporting success — the deletion did not "
            "take. Nothing was authored; resolve manually and retry.",
            extra={"leftoverOwnedClips": survivor_names},
        )
    return cleared


def _non_owned_blocking_clips(timeline, track_index, prefixes=OWNED_PREFIXES):
    """Items on the target track WITHOUT an ownership marker — content the
    app must never touch (bridge rule 7)."""
    blockers = []
    for item in (timeline.GetItemListInTrack("video", track_index) or []):
        try:
            name = item.GetName() or ""
        except Exception:
            name = ""
        if not _matches_any_prefix(name, prefixes):
            blockers.append((name or "<unnamed>", item))
    return blockers


def _enforce_empty_target_track(timeline, track_index):
    """requireEmptyTrack: after clearing owned clips, refuse to proceed when
    any NON-owned clip remains on the target track."""
    blockers = _non_owned_blocking_clips(timeline, track_index)
    if blockers:
        raise BridgeFailure(
            "non-owned-clips-block-track",
            f"requireEmptyTrack: {len(blockers)} non-owned clip(s) remain "
            f"on track {track_index} "
            f"({', '.join(name for name, _ in blockers)}) — this app never "
            "deletes content it didn't create. Remove the listed clips "
            "manually, pick another trackName, or retry without "
            "requireEmptyTrack.",
            extra={"blockingClips": [name for name, _ in blockers]},
        )


def _looks_like_fusion_orphan_name(name):
    """Unnamed baked-Fusion-clip pool name ('Fusion Clip 12') — the generic
    label Resolve gives baked comps that cannot be renamed bin-side."""
    text = str(name or "")
    if not text.startswith("Fusion Clip "):
        return False
    return text[len("Fusion Clip "):].isdigit()


def _clean_owned_bin(media_pool, bin_folder, protect_prefix=0,
                     prefixes=OWNED_PREFIXES):
    """cleanBin option: best-effort cleanup of app-owned pool items in the
    app-dedicated destination bin (count-based like D13 reconciliation).

    Deletes entries whose names carry an ownership prefix, plus unnamed
    'Fusion Clip N' orphans beyond `protect_prefix` (the first protect_prefix
    entries map onto a resume checkpoint's committed lines, so they stay).
    Returns the number of deleted pool items; fails loud when the delete
    itself fails, mirroring reconciliation semantics.
    """
    entries = _bin_entry_list(bin_folder)
    doomed = []
    for position, entry in enumerate(entries):
        name = entry["name"]
        if _matches_any_prefix(name, prefixes):
            doomed.append(entry)
            continue
        if position < protect_prefix:
            continue  # count-based: committed-checkpoint prefix is protected
        if _looks_like_fusion_orphan_name(name):
            doomed.append(entry)
    if not doomed:
        return 0
    clips = [entry["clip"] for entry in doomed]
    names = [entry["name"] or "<unnamed>" for entry in doomed]
    try:
        ok = bool(media_pool.DeleteClips(clips))
    except Exception as exc:
        raise BridgeFailure(
            "owned-bin-clean-failed",
            f"Deleting {len(clips)} app-owned bin clip(s) "
            f"({', '.join(names)}) raised: {exc}",
        ) from exc
    if not ok:
        raise BridgeFailure(
            "owned-bin-clean-failed",
            f"Deleting {len(clips)} app-owned bin clip(s) "
            f"({', '.join(names)}) returned False (fail-quiet API).",
        )
    emit_progress("bin-cleaned", None, deleted=len(clips))
    return len(clips)


SCRATCH_TIMELINE_NAME = "CaptionSuite Scratch (auto)"


def _bin_clip_list(bin_folder):
    try:
        return list(bin_folder.GetClipList() or [])
    except Exception:
        return []


def _new_bin_clips(before, after):
    """Clips present in `after` but not in `before` (by identity)."""
    return [c for c in after if not any(c is b for b in before)]


def _bin_entry_list(bin_folder):
    """Rich clip enumeration for reconciliation: [{"name", "id", "clip"}].

    `id` is Resolve's media-pool item ID (GetMediaId) when exposed — the
    only stable per-clip identity the API offers, since baked Fusion clips
    keep generic names that cannot be renamed bin-side. Timeline items
    surfacing in the pool (e.g. a leftover scratch timeline) are excluded:
    they are not baked work and would corrupt positional counting.
    """
    entries = []
    for clip in _bin_clip_list(bin_folder):
        try:
            if str(clip.GetClipProperty("Type") or "").lower() == "timeline":
                continue
        except Exception:
            pass  # fail-quiet getter — treat it as a regular clip
        name = ""
        try:
            name = clip.GetName() or ""
        except Exception:
            pass  # fail-quiet getter — keep the entry with a blank name
        clip_id = None
        try:
            clip_id = str(clip.GetMediaId())
        except Exception:
            pass  # older builds may not expose GetMediaId
        entries.append({"name": name, "id": clip_id, "clip": clip})
    return entries


def _bin_entries_by_id(bin_entries):
    """Index bin entries by media-pool id (first occurrence wins)."""
    by_id = {}
    for entry in bin_entries:
        if entry["id"] is not None and entry["id"] not in by_id:
            by_id[entry["id"]] = entry
    return by_id


def _timeline_frame_rate(timeline, fallback=24.0):
    """Read a timeline's frame rate, keeping the fallback for old mocks."""
    try:
        raw = timeline.GetSetting("timelineFrameRate")
        if not isinstance(raw, (int, float, str)):
            return float(fallback)
        value = float(raw)
        if value > 0:
            return value
    except (AttributeError, TypeError, ValueError):
        pass
    return float(fallback)


def _rescale_clip_doc_for_fps(clip_doc, source_fps, target_fps):
    """Convert target-timeline frame coordinates into scratch-timebase ones.

    Resolve's empty scratch timelines inherit the project rate (24fps here),
    while the real target may be 23.976/29.97/59.94. Fusion keyframes are
    authored on the scratch timeline, so leaving target-rate frame numbers in
    them makes both the reveal timing and the baked source duration wrong.
    """
    try:
        source_fps = float(source_fps)
        target_fps = float(target_fps)
    except (TypeError, ValueError):
        return dict(clip_doc)
    if source_fps <= 0 or target_fps <= 0:
        return dict(clip_doc)
    scale = source_fps / target_fps
    if abs(scale - 1.0) < 1e-9:
        return dict(clip_doc)

    def frame(value):
        try:
            return int(round(float(value) * scale))
        except (TypeError, ValueError):
            return value

    converted = dict(clip_doc)
    if "startFrame" in converted:
        converted["startFrame"] = frame(converted["startFrame"])
    if "endFrame" in converted:
        converted["endFrame"] = frame(converted["endFrame"])
    curves = converted.get("keyframes")
    if isinstance(curves, dict):
        converted["keyframes"] = {
            name: _rescale_curve_for_fps(curve, frame)
            for name, curve in curves.items()
        }
    overlay_curves = converted.get("overlayKeyframes")
    if isinstance(overlay_curves, dict):
        converted["overlayKeyframes"] = {
            name: _rescale_curve_for_fps(curve, frame)
            for name, curve in overlay_curves.items()
        }
    return converted


def _rescale_curve_for_fps(curve, frame):
    if not isinstance(curve, dict):
        return curve
    entries = curve.get("entries")
    if not isinstance(entries, list):
        return dict(curve)
    converted = dict(curve)
    converted["entries"] = [
        {**entry, "frame": frame(entry.get("frame"))}
        if isinstance(entry, dict) else entry
        for entry in entries
    ]
    return converted


def _validated_resume_prefix(checkpoint, bin_entries):
    """Map a checkpoint's committed clips onto ACTUAL bin entries by the
    media ids recorded when each clip was baked (`binMediaIds`, parallel to
    completedClipIds).

    Returns the matched entries in commit order, [] for an empty checkpoint,
    or None when the positional identity CANNOT be trusted:
    - the checkpoint predates binMediaIds recording (old format),
    - a recorded id is missing from the bin (user deleted pool items —
      a "hole"; positional truncation would mis-map surviving clips),
    - a recorded id is None (GetMediaId unavailable at bake time).

    Callers must fail safe on None: abandon the resumed prefix and fall
    back to a clean/full run rather than guess.
    """
    completed = [str(c) for c in (checkpoint.get("completedClipIds") or [])]
    if not completed:
        return []
    stored_ids = checkpoint.get("binMediaIds")
    if not isinstance(stored_ids, list) or len(stored_ids) != len(completed):
        return None
    by_id = _bin_entries_by_id(bin_entries)
    matched = []
    for stored_id in stored_ids:
        if stored_id is None:
            return None
        entry = by_id.get(str(stored_id))
        if entry is None:
            return None
        matched.append(entry)
    return matched


def _place_baked_clips(media_pool, bin_folder, clip_docs, names, pool_items,
                       track_index, timeline_start_frame,
                       source_fps=24.0, target_fps=24.0):
    """Place freshly baked clips onto the real animate track.

    Frame-exact and non-destructive (proven route): AppendToTimeline with
    explicit recordFrame/trackIndex never ripples. Each placed instance is
    renamed to its ownership marker via TimelineItem.SetName — confirmed
    live on 21.0.4.5 that SetClipProperty CANNOT rename a baked Fusion
    clip's pool item (returns False), so the marker lives on the placed
    instance, where environment cleanup looks for it. Returns placed count.

    `timeline_start_frame` is the REAL timeline's `GetStartFrame()` and is
    REQUIRED, not optional. The animation document's startFrame/endFrame are
    TIMELINE-RELATIVE (0-based): `AnimationComposer` builds them straight
    from the `.capproj` cue seconds, which `mode_info`/`pull-subtitles`
    themselves emit relative to the timeline start — the composer is never
    even given a start frame. `recordFrame`, though, is ABSOLUTE. Live
    incident (2026-08-27): passing the relative frame through verbatim
    placed all 27 captions at absolute frames 4..1046 on a timeline
    starting at 86400 — i.e. exactly one hour (86400 f @ 24 fps) before its
    own start, off the visible edit entirely. The user's report was "I see
    the fusion clips [in the bin]. They aren't in my timeline… new video
    tracks were made as well but never populated": the track WAS created
    and populated, an hour early. Clip-local in/out stay 0-based (the baked
    source is exactly the clip's own length), so only recordFrame shifts.
    """
    if not clip_docs:
        return 0  # all-reuse rerun: nothing fresh to place

    by_name = {}
    for clip in _bin_clip_list(bin_folder):
        by_name.setdefault(clip.GetName(), clip)

    try:
        rate = float(source_fps) / float(target_fps)
    except (TypeError, ValueError, ZeroDivisionError):
        rate = 1.0

    clip_infos = []
    for index, (clip_doc, name, pool_item) in enumerate(
            zip(clip_docs, names, pool_items)):
        if pool_item is None:
            # Fallback: match by name (works whenever renaming DID take).
            pool_item = by_name.get(name)
        if pool_item is None:
            raise BridgeFailure(
                "placement-missing-clip",
                f"Baked clip {name!r} not found in the destination bin — "
                "cannot place it.",
            )
        start_frame = int(clip_doc.get("startFrame") or 0)
        end_frame = int(clip_doc.get("endFrame") or 0)
        own_length = max(end_frame - start_frame, 1)
        record_relative = start_frame
        if abs(rate - 1.0) < 1e-9:
            source_length = own_length
        else:
            # The baked Fusion source is authored on the scratch timeline's
            # timebase. Resolve conforms that source range when it is
            # appended to a different-rate target timeline, so passing
            # target-rate frame counts straight through under- or
            # over-shoots the intended target-rate span (24fps cannot
            # represent every 59.94fps duration exactly). Span each clip to
            # the START of the NEXT authored clip in this batch (still in
            # target-rate frames, computed directly from the composer's own
            # numbers, not from Resolve's conform) and CEIL the source range
            # so the conformed duration is never SHORTER than that span —
            # closing the gap rather than risking one. This previously used
            # each clip's OWN length with FLOOR specifically to guarantee no
            # overlap with the NEXT clip (fixing an earlier silently-dropped-
            # clip bug); spanning to the next clip's actual start achieves
            # the same non-overlap guarantee while also closing the 1-3
            # frame black gaps CEILing a clip's own length would have left
            # between every pair of clips at 59.94fps.
            if index + 1 < len(clip_docs):
                next_start_frame = int(clip_docs[index + 1].get("startFrame") or 0)
                target_span = max(next_start_frame - start_frame, 1)
            else:
                target_span = own_length
            source_length = max(int(math.ceil(target_span * rate)), 1)
        clip_infos.append({
            "mediaPoolItem": pool_item,
            "startFrame": 0,
            "endFrame": source_length,  # exclusive, in source timebase
            "recordFrame": timeline_start_frame + record_relative,
            "trackIndex": track_index,
            "mediaType": 1,  # video only
        })

    placed = media_pool.AppendToTimeline(clip_infos) or []
    # A short result is reported by the caller as ``placement-incomplete`` so
    # its resumable checkpoint context is preserved.  An overlong result has
    # no safe correspondence to requested clips: at least one returned item
    # would remain unmarked, so stop before claiming success.
    if len(placed) > len(clip_infos):
        raise BridgeFailure(
            "placement-count-mismatch",
            f"Resolve returned {len(placed)} placed item(s) for "
            f"{len(clip_infos)} requested clip(s). The run stopped before "
            "claiming success; inspect the dedicated animate track before "
            "retrying.",
        )
    for item, name in zip(placed, names):
        try:
            renamed = item.SetName(name)
        except Exception as exc:
            raise BridgeFailure(
                "ownership-marker-failed",
                f"Placed clip {name!r} but Resolve raised while assigning its "
                f"ownership marker: {exc}. The run stopped before claiming "
                "success; inspect the dedicated animate track before retrying.",
            ) from exc
        # `TimelineItem.SetName` is a fail-quiet API. An unmarked item is
        # indistinguishable from user content on a later run, so accepting a
        # False result here would allow an interrupted placement to be
        # duplicated instead of being surfaced for recovery.
        if renamed is False:
            raise BridgeFailure(
                "ownership-marker-failed",
                f"Placed clip {name!r} but Resolve refused its ownership "
                "marker (SetName returned False). The run stopped before "
                "claiming success; inspect the dedicated animate track before "
                "retrying.",
            )
        try:
            observed_name = item.GetName()
        except Exception as exc:
            raise BridgeFailure(
                "ownership-marker-failed",
                f"Placed clip {name!r} but Resolve would not read back its "
                f"ownership marker: {exc}. The run stopped before claiming "
                "success; inspect the dedicated animate track before retrying.",
            ) from exc
        if observed_name != name:
            raise BridgeFailure(
                "ownership-marker-failed",
                f"Placed clip {name!r} but Resolve reports its name as "
                f"{observed_name!r}. The run stopped before claiming success; "
                "inspect the dedicated animate track before retrying.",
            )
    return len(placed)


def _disable_subtitle_tracks(timeline):
    """Turn off every subtitle track on the timeline, AFTER captions have
    been verified onto their video track.

    The animated captions replace whatever Resolve's own subtitle track was
    showing; leaving that track enabled double-exposes the same words, one
    styled and one not. Only runs on the success path — a failed or partial
    run must leave the user's existing subtitles visible, since they're
    still the only captions on the timeline.

    Disable, never delete: the subtitle track is the user's source text and
    the thing they'd re-run from.

    Video-track states are snapshotted and restored around the call. A user
    live-reported that this step also switched off the VIDEO track holding
    the freshly placed captions — the exact opposite of the intent, and
    worse than not running at all, since it hides the work the run just
    did. That could not be reproduced here (isolated and full-executor runs
    both left every video track enabled), so rather than guess at the
    Resolve-side cause, this makes the failure mode impossible: anything
    that flips a video track during this call is put straight back. The
    restore is verified, and a track that refuses to come back is reported
    rather than silently left off.

    Returns (disabled_subtitle_indices, restored_video_indices).
    """
    restored_video = []
    try:
        video_count = int(timeline.GetTrackCount("video") or 0)
    except Exception:
        video_count = 0
    before = {}
    for index in range(1, video_count + 1):
        try:
            before[index] = timeline.GetIsTrackEnabled("video", index)
        except Exception:
            continue

    switched_off = []
    try:
        count = int(timeline.GetTrackCount("subtitle") or 0)
    except Exception:
        count = 0
    for index in range(1, count + 1):
        try:
            if not timeline.GetIsTrackEnabled("subtitle", index):
                continue
            if timeline.SetTrackEnable("subtitle", index, False):
                switched_off.append(index)
        except Exception:
            continue  # best-effort: never fail a completed run over track visibility

    for index, was_enabled in before.items():
        try:
            if timeline.GetIsTrackEnabled("video", index) == was_enabled:
                continue
            timeline.SetTrackEnable("video", index, was_enabled)
            if timeline.GetIsTrackEnabled("video", index) == was_enabled:
                restored_video.append(index)
            else:
                sys.stderr.write(
                    f"warning: video track {index} was switched off while "
                    "disabling subtitle tracks and could not be restored — "
                    "re-enable it in Resolve's track header\n")
        except Exception:
            continue

    return switched_off, restored_video


def _delete_scratch_timeline(project, media_pool, scratch):
    """Best-effort removal of the scratch timeline; warns on stderr."""
    for attempt in (
        lambda: media_pool.DeleteTimelines([scratch]),
        lambda: project.DeleteTimeline(scratch),
    ):
        try:
            if attempt():
                return
        except (AttributeError, TypeError):
            continue
        except Exception as exc:
            sys.stderr.write(
                f"warning: scratch timeline cleanup raised: {exc}\n")
            return
    sys.stderr.write(
        "warning: this Resolve build exposes no timeline-deletion API — "
        f"the scratch timeline {SCRATCH_TIMELINE_NAME!r} must be removed "
        "manually.\n")


def _setup_scratch_timeline(project, media_pool, target_resolution):
    """Create and select a scratch timeline, cleaning it if selection fails."""
    scratch = _create_scratch_timeline(media_pool, target_resolution)
    if not scratch:
        raise BridgeFailure(
            "scratch-timeline-failed",
            "Couldn't create a scratch timeline for authoring "
            "(fail-quiet API).",
        )
    try:
        switched = project.SetCurrentTimeline(scratch)
    except Exception:
        try:
            _delete_scratch_timeline(project, media_pool, scratch)
        except Exception as cleanup_exc:
            sys.stderr.write(
                f"warning: scratch timeline cleanup raised: {cleanup_exc}\n")
        raise
    if not switched:
        try:
            _delete_scratch_timeline(project, media_pool, scratch)
        except Exception as cleanup_exc:
            sys.stderr.write(
                f"warning: scratch timeline cleanup raised: {cleanup_exc}\n")
        raise BridgeFailure(
            "scratch-timeline-failed",
            "Couldn't switch to the scratch timeline.",
        )
    return scratch


def _cleanup_scratch_timeline(project, media_pool, scratch):
    """Run scratch cleanup without allowing it to replace the primary error."""
    try:
        _delete_scratch_timeline(project, media_pool, scratch)
    except Exception as exc:
        sys.stderr.write(f"warning: scratch timeline cleanup raised: {exc}\n")


def _reconcile_report_path(runstate_dir, timeline_id):
    return os.path.join(runstate_dir, f"{timeline_id}-reconcile.json")


def _owned_marker(line_number):
    return f"{OWNED_CLIP_PREFIX}{line_number:04d}"


def _reconcile_bin_on_resume(media_pool, bin_folder, target_track_items,
                             checkpoint, mode="clean", timeline=None,
                             track_index=None, prefix=OWNED_CLIP_PREFIX,
                             marker_for=_owned_marker,
                             validate_identity=True):
    """D13 reconciliation: align actual owned artifacts with the checkpoint
    before a resumed author run continues from it.

    Identity strategy (D13 live finding, Resolve 21.0.4.5): baked Fusion
    clips CANNOT be renamed bin-side (SetClipProperty returns False), so bin
    clips carry no reliable marker. Positional identity is therefore
    VALIDATED, not assumed:

    - the destination bin is app-dedicated (created by setup) — every clip
      in it is app-owned work,
    - each checkpoint records the media-pool ids of its baked clips
      (binMediaIds, parallel to completedClipIds); a committed prefix whose
      ids are all still present in the bin maps onto those EXACT entries,
    - anything unverifiable — an old-format checkpoint without binMediaIds,
      a recorded id missing from the bin (user deleted pool items), or a
      bin holding stale clips from an earlier run — FAILS SAFE: the whole
      prefix is treated as orphaned, the checkpoint's progress is discarded,
      and the run falls back to a clean full re-author with a warning.

    Timeline-side placed items DO carry markers (TimelineItem.SetName
    works), so placed-but-uncommitted orphans are identified by name.

    mode="clean"  (default): delete orphaned bin clips via
                  MediaPool.DeleteClips and orphaned target-track items;
    mode="adopt": treat contiguous orphans as extra completed lines —
                  extend completedClipIds/completedLines in-place and let
                  the run continue AFTER them. Only valid when the orphans
                  are explainable as "the next N lines were fully baked"
                  (contiguous ownership markers on the track, and at most
                  one unnamed bin orphan — the canonical single-kill D13
                  leak). Any gap falls back to clean with a warning.

    Mutates `checkpoint` when adopting. Returns the report dict written to
    <runstateDir>/<timelineId>-reconcile.json by the caller.
    """
    completed = [str(c) for c in (checkpoint.get("completedClipIds") or [])]

    bin_entries = _bin_entry_list(bin_folder)
    tl_owned = []
    for item in list(target_track_items or []):
        try:
            name = item.GetName() or ""
        except Exception:
            continue
        if name.startswith(prefix):
            tl_owned.append((name, item))

    # Identity validation BEFORE any positional accounting: the "first
    # len(completed) entries" mapping is only safe when those entries are
    # provably THIS run's committed clips. Each checkpoint records the
    # media-pool ids of its baked clips (binMediaIds); anything unverifiable
    # — a pre-recording checkpoint, a deleted pool item (hole), or stale
    # clips from an earlier completed run sharing the bin — fails safe: the
    # whole bin/track prefix is treated as orphaned, the checkpoint's
    # progress is discarded, and the run re-authors from line 1.
    # (Reuse-only runs skip this gate: their prefix identity is enforced
    # structurally via ownership markers + content hashes, and their
    # checkpoints may legitimately predate binMediaIds.)
    matched_entries = (
        _validated_resume_prefix(checkpoint, bin_entries)
        if completed and validate_identity else [])
    invalidated_reason = None
    if matched_entries is None:
        invalidated_reason = (
            "checkpoint's committed clips cannot be verified against the "
            "destination bin (missing/old-format binMediaIds, or a recorded "
            "media id is no longer present)"
        )
        sys.stderr.write(
            f"warning: resume invalidated — {invalidated_reason}. "
            "Falling back to a clean full run.\n")
        checkpoint["completedClipIds"] = []
        checkpoint["completedLines"] = 0
        completed = []

    committed = set(completed)
    # Placed-but-uncommitted: markers the checkpoint doesn't cover.
    tl_orphans = [(n, it) for n, it in tl_owned if n not in committed]
    # Baked-but-uncommitted: with a validated identity mapping, anything the
    # checkpoint does NOT claim is an orphan no matter WHERE it sits in the
    # bin (stale clips from earlier runs may precede the committed ones);
    # without one, fall back to the count-based beyond-the-prefix slice.
    if matched_entries:
        matched_clips = {id(e["clip"]) for e in matched_entries}
        bin_orphans = [e for e in bin_entries
                       if id(e["clip"]) not in matched_clips]
    else:
        bin_orphans = bin_entries[len(completed):]
    orphan_count = len(bin_orphans) + len(tl_orphans)

    report = {
        "binClips": [e["name"] for e in bin_entries],
        "binClipIds": [e["id"] for e in bin_entries],
        "timelineOwnedItems": [name for name, _ in tl_owned],
        "orphansDetected": orphan_count,
        "action": "cleaned",
        "reconciledAt": _iso_now(),
    }
    if invalidated_reason is not None:
        report["action"] = "invalidated"
        report["invalidatedReason"] = invalidated_reason

    if orphan_count == 0:
        emit_progress("reconciled", None, action=report["action"],
                      orphans=0)
        return report

    next_line = len(completed) + 1
    sorted_tl = sorted(tl_orphans, key=lambda pair: pair[0])
    contiguous = all(
        name == marker_for(next_line + i)
        for i, (name, _) in enumerate(sorted_tl)
    )
    adopt_ok = (
        mode == "adopt"
        and contiguous
        and (len(bin_orphans) == len(tl_orphans)
             or (len(tl_orphans) == 0 and len(bin_orphans) == 1))
    )

    if adopt_ok:
        adopted_ids = [
            marker_for(next_line + i) for i in range(len(bin_orphans))
        ]
        checkpoint["completedClipIds"] = completed + adopted_ids
        checkpoint["completedLines"] = len(checkpoint["completedClipIds"])
        # Keep binMediaIds parallel so the adopted lines stay
        # identity-verifiable for future resumes.
        if isinstance(checkpoint.get("binMediaIds"), list):
            checkpoint["binMediaIds"] = (
                checkpoint["binMediaIds"][:len(completed)]
                + [entry["id"] for entry in bin_orphans])
        checkpoint["lastCheckpointAt"] = _iso_now()
        report["action"] = "adopted"
        report["adoptedClipIds"] = adopted_ids
        emit_progress("reconciled", None, action="adopted",
                      adopted=len(adopted_ids))
        return report

    if mode == "adopt":
        message = (
            f"{orphan_count} orphaned artifact(s) are not contiguous with "
            f"the checkpoint ({len(completed)} committed lines) — falling "
            "back to clean; the orphaned work will be re-authored."
        )
        sys.stderr.write(f"warning: {message}\n")
        emit_progress("reconcile-fallback", None, reason="gap",
                      orphans=orphan_count)
        report["fallbackFrom"] = "adopt"

    deleted_bins = 0
    if bin_orphans:
        clips = [entry["clip"] for entry in bin_orphans]
        try:
            ok = bool(media_pool.DeleteClips(clips))
        except Exception as exc:
            raise BridgeFailure(
                "reconcile-clean-failed",
                f"Deleting {len(clips)} orphaned bin clip(s) raised: {exc}",
            ) from exc
        if not ok:
            raise BridgeFailure(
                "reconcile-clean-failed",
                f"Deleting {len(clips)} orphaned bin clip(s) returned False "
                "(fail-quiet API).",
            )
        deleted_bins = len(clips)

    deleted_tls = 0
    if tl_orphans and timeline is not None and track_index is not None:
        for _, item in tl_orphans:
            # Same live finding as _clear_owned_clips: no trackIndex arg.
            try:
                ok = bool(timeline.DeleteClips([item]))
            except Exception as exc:
                raise BridgeFailure(
                    "reconcile-clean-failed",
                    f"Deleting an orphaned target-track item raised: {exc}",
                ) from exc
            if not ok:
                raise BridgeFailure(
                    "reconcile-clean-failed",
                    "Deleting an orphaned target-track item returned False "
                    "(fail-quiet API).",
                )
            deleted_tls += 1

    report["deletedBinClips"] = deleted_bins
    report["deletedTimelineItems"] = deleted_tls
    emit_progress("reconciled", None, action=report["action"],
                  deletedBinClips=deleted_bins,
                  deletedTimelineItems=deleted_tls)
    return report


def _delete_stale_scratch_timelines(project, media_pool):
    """Best-effort removal of any leftover scratch timeline from a previous
    (killed) run. Live-confirmed on 21.0.4.5: a SIGKILL leaves the scratch
    timeline in the project AND current, which both blocks CreateEmptyTimeline
    with the same name and leaves Resolve focused on an empty phantom
    timeline."""
    getter = getattr(project, "GetTimelineCount", None)
    by_index = getattr(project, "GetTimelineByIndex", None)
    if not callable(getter) or not callable(by_index):
        return
    try:
        count = int(getter() or 0)
    except (TypeError, ValueError):
        return
    stale = []
    for idx in range(1, count + 1):
        try:
            tl = by_index(idx)
        except Exception:
            continue
        if tl is not None and tl.GetName() == SCRATCH_TIMELINE_NAME:
            stale.append(tl)
    for tl in stale:
        _delete_scratch_timeline(project, media_pool, tl)


def _sweep_stale_scratches_before(resolve, context):
    """Best-effort stale-scratch sweep with the shared warn-and-continue
    wrapper. `context` completes the warning line ("before target
    resolution", "before info", ...).

    Live finding (2026-08-25 kill test): after a SIGKILL mid-run Resolve
    stays focused on the phantom scratch timeline, so resolving the target
    FIRST would treat the scratch as the user's timeline. Sweep stale
    scratches BEFORE target resolution — deleting the current timeline
    auto-refocuses Resolve onto the previously active one (live-verified).
    verify_token below (in the callers) still guards against any other
    focus drift.
    """
    try:
        # Direct call shape only — the fusionscript wrapper mis-resolves
        # these attributes through getattr()-style probing (live finding).
        _delete_stale_scratch_timelines(
            resolve.GetProjectManager().GetCurrentProject(),
            resolve.GetProjectManager().GetCurrentProject().GetMediaPool(),
        )
    except Exception as exc:
        sys.stderr.write(
            f"warning: stale scratch sweep {context} raised: {exc}\n")


# --------------------------------------------------------------------------
# Execution checkpoints (mirror of Core ExecutorCheckpoint.swift)
#
# Shape: {"completedLines": int, "completedClipIds": [str],
#         "clipHashes": [str], "binMediaIds": [str], "lastToken": str,
#         "lastCheckpointAt": ISO-8601 UTC, "pid": int}
#
# `binMediaIds` runs PARALLEL to completedClipIds: the media-pool id
# (GetMediaId) of each committed clip's pool item, recorded at bake time.
# Resume reconciliation matches committed clips onto actual bin entries by
# this id — positional ("first k entries") mapping is only a fallback and
# is abandoned whenever the ids cannot verify it (deleted pool items, stale
# bins, old-format checkpoints).
#
# `clipHashes` (proofread-edit prefix reuse) runs PARALLEL to
# completedClipIds: sha256 of canonical JSON of each authored unit's content
# ({startFrame, endFrame, text, keyframes, overlayKeyframes}, sorted keys).
# A re-run with reuseCheckpoint:true compares incoming unit hashes against
# this list and reuses the longest unchanged PREFIX instead of re-authoring.
# --------------------------------------------------------------------------

HEARTBEAT_EVERY_N_LINES = 10
HEARTBEAT_SECONDS = 5.0


def _validate_reuse_region(timeline, track_index, expected_markers, prefix):
    """Fail loud (`reuse-state-invalid`) when any ownership marker of the
    to-be-reused prefix region is missing from the target track — the track
    was externally modified and reuse would silently guess at state."""
    present = set()
    for item in (timeline.GetItemListInTrack("video", track_index) or []):
        try:
            name = str(item.GetName() or "")
        except Exception:
            continue
        if name.startswith(prefix):
            present.add(name)
    missing = [m for m in expected_markers if m not in present]
    if missing:
        raise BridgeFailure(
            "reuse-state-invalid",
            f"{len(missing)} owned marker(s) of the reusable prefix region "
            f"are missing from track {track_index} "
            f"({', '.join(missing)}) — the track was modified outside this "
            "app since the checkpoint was written. Re-run without "
            "reuseCheckpoint (a full run) to rebuild everything.",
            extra={"missingOwnedMarkers": missing},
        )


def _checkpoint_key(timeline):
    """Filesystem-safe checkpoint key: the request's timelineId when given,
    otherwise a sanitized current-timeline name."""
    raw = None
    try:
        raw = timeline.GetName()
    except (AttributeError, TypeError):
        pass
    safe = "".join(
        ch if (ch.isalnum() or ch in "._-") else "_" for ch in str(raw or "timeline")
    )
    return safe or "timeline"


def _persist_reconcile_report(runstate_dir, timeline_id, report):
    """Best-effort persistence shared by both executor modes."""
    if not runstate_dir:
        return
    try:
        with open(
            _reconcile_report_path(runstate_dir, timeline_id),
            "w", encoding="utf-8",
        ) as fh:
            json.dump(report, fh, indent=2)
    except OSError as exc:
        sys.stderr.write(f"warning: couldn't write reconcile report: {exc}\n")


def _protected_bin_prefix(wants_reuse, reuse_count, checkpoint):
    """Return the owned prefix that clean-bin may preserve."""
    if wants_reuse:
        return reuse_count
    if checkpoint is not None:
        return len(checkpoint.get("completedClipIds") or [])
    return 0


def _load_executor_checkpoint(request, timeline):
    """Derive shared checkpoint state and validate resumptions once.

    Both executors use the same sidecar, missing-runstate, and stale-token
    rules.  Executor-specific reuse markers remain in their own loops.
    """
    runstate_dir = request.get("runstateDir") or None
    timeline_id = str(request.get("timelineId") or _checkpoint_key(timeline))
    persist = bool(runstate_dir)
    expected_token = request.get("expectedToken")
    wants_resume = bool(request.get("resume")) and persist
    wants_reuse = bool(request.get("reuseCheckpoint")) and persist

    if not persist and (request.get("resume") or request.get("reuseCheckpoint")):
        raise BridgeFailure(
            "resume-requires-runstate-dir",
            "'resume'/'reuseCheckpoint' were requested but 'runstateDir' is "
            "missing — there is no checkpoint to resume from. Pass the same "
            "runstateDir used by the original run, or drop the flag to "
            "intentionally re-author everything.",
        )

    checkpoint = None
    if wants_resume or wants_reuse:
        checkpoint = _load_checkpoint(runstate_dir, timeline_id)
        if checkpoint is not None and wants_resume:
            checkpoint_token = checkpoint.get("lastToken")
            if checkpoint_token != expected_token:
                raise BridgeFailure(
                    "token-mismatch-checkpoint",
                    "The checkpoint for timeline "
                    f"{timeline_id!r} was written against a different "
                    f"identity token ({checkpoint_token!r} vs {expected_token!r}) "
                    "— refusing to resume a stale run. Delete the checkpoint "
                    f"({_checkpoint_path(runstate_dir, timeline_id)}) or "
                    "re-run `info` and restart fresh.",
                )

    return {
        "runstate_dir": runstate_dir,
        "timeline_id": timeline_id,
        "persist": persist,
        "expected_token": expected_token,
        "wants_resume": wants_resume,
        "wants_reuse": wants_reuse,
        "checkpoint": checkpoint,
    }


def _prepare_executor_target(project, timeline, request, track_name, bin_name,
                             checkpoint_state, *, prefix=OWNED_CLIP_PREFIX,
                             marker_for=_owned_marker):
    """Resolve the destination and perform shared D13 reconciliation."""
    emit_progress("preparing", 0.02)
    media_pool = project.GetMediaPool()
    track_index = _find_or_create_named_track(timeline, track_name)
    bin_folder = _find_or_create_bin(media_pool, bin_name)
    checkpoint = checkpoint_state["checkpoint"]
    reconcile_report = None
    if checkpoint is not None:
        emit_progress("reconciling", 0.03)
        track_items = list(
            timeline.GetItemListInTrack("video", track_index) or [])
        reconcile_report = _reconcile_bin_on_resume(
            media_pool, bin_folder, track_items, checkpoint,
            mode=request.get("reconcileMode") or "clean",
            timeline=timeline, track_index=track_index, prefix=prefix,
            marker_for=marker_for,
            validate_identity=checkpoint_state["wants_resume"],
        )
        if reconcile_report.get("action") == "adopted":
            try:
                _save_checkpoint(
                    checkpoint_state["runstate_dir"],
                    checkpoint_state["timeline_id"], checkpoint)
            except OSError as exc:
                sys.stderr.write(
                    f"warning: couldn't persist adopted checkpoint: {exc}\n")
        _persist_reconcile_report(
            checkpoint_state["runstate_dir"],
            checkpoint_state["timeline_id"],
            reconcile_report,
        )
    return media_pool, track_index, bin_folder, reconcile_report


def _prepare_reuse_and_clear(timeline, track_index, media_pool, bin_folder,
                             unit_hashes, checkpoint, wants_reuse,
                             require_empty_track, clean_bin, *, prefix,
                             marker_for):
    """Validate reusable ownership and clear only replaceable artifacts."""
    reuse_count = 0
    preserved_markers = []
    if wants_reuse:
        stored_hashes = checkpoint.get("clipHashes") if checkpoint else None
        if isinstance(stored_hashes, list):
            reuse_count = _longest_matching_prefix(unit_hashes, stored_hashes)
            if reuse_count > 0:
                preserved_markers = [
                    marker_for(i + 1) for i in range(reuse_count)]
                _validate_reuse_region(
                    timeline, track_index, preserved_markers, prefix)
        else:
            sys.stderr.write(
                "warning: checkpoint has no clipHashes (old format) — "
                "running a full authoring pass.\n")
        emit_progress("reuse", None, count=reuse_count)

    cleared = _clear_owned_clips(
        timeline, track_index,
        preserve=set(preserved_markers) if preserved_markers else None)
    if require_empty_track:
        emit_progress("verifying-empty-track", None, trackIndex=track_index)
        _enforce_empty_target_track(timeline, track_index)

    cleared_bin = 0
    if clean_bin:
        protect_prefix = _protected_bin_prefix(
            wants_reuse, reuse_count, checkpoint)
        cleared_bin = _clean_owned_bin(
            media_pool, bin_folder, protect_prefix=protect_prefix)

    return reuse_count, preserved_markers, cleared, cleared_bin


def _execute_animation_document(request, doc):
    """Full Multi-Clip execution: prep track/bin, author + bake every clip
    on a scratch timeline, place the baked clips on the dedicated track."""
    resolve = load_resolve()
    check_version(resolve)
    _ensure_edit_page(resolve)
    _sweep_stale_scratches_before(resolve, "before target resolution")
    project, timeline = open_project_timeline(resolve)
    verify_token(request, project, timeline)

    # Request-level captured style (optional; validated BEFORE any mutation):
    # a raw SaveSettings dict via "stylePayload" or a preset file via
    # "stylePath" — see _resolve_style_payload.
    request_style = _resolve_style_payload(request)
    highlight_style = _resolve_overlay_style_payload(request, request_style)
    # Highlight overlay fill color (optional, validated up front): the
    # .capproj preset's HighlightWindowParams.highlightColor.
    highlight_color = _parse_hex_color(request.get("highlightColor"))

    placement = doc.get("placement") or {}
    track_name = request.get("trackName") \
        or placement.get("trackName") or ANIMATE_TRACK_NAME
    bin_name = request.get("binName") \
        or placement.get("binName") or f"CaptionSuite — {timeline.GetName()}"

    clips = doc.get("clips") or []
    total = len(clips)

    # Checkpointing (all optional, backward compatible): without a
    # runstateDir everything stays in-memory and no files are written.
    checkpoint_state = _load_executor_checkpoint(request, timeline)
    runstate_dir = checkpoint_state["runstate_dir"]
    timeline_id = checkpoint_state["timeline_id"]
    persist = checkpoint_state["persist"]
    expected_token = checkpoint_state["expected_token"]
    wants_resume = checkpoint_state["wants_resume"]
    wants_reuse = checkpoint_state["wants_reuse"]
    ckpt = checkpoint_state["checkpoint"]
    require_empty_track = bool(request.get("requireEmptyTrack"))
    clean_bin = bool(request.get("cleanBin"))

    resumed_ids = []

    # Proofread-edit prefix reuse: hash every incoming clip up front (the
    # same hashes are persisted in the checkpoint for the NEXT run).
    unit_hashes = [_clip_content_hash(c) for c in clips]

    reconcile_mode = request.get("reconcileMode") or "clean"
    if reconcile_mode not in ("clean", "adopt"):
        raise BridgeFailure(
            "bad-reconcile-mode",
            f"reconcileMode must be 'clean' or 'adopt', got "
            f"{reconcile_mode!r}.",
        )

    media_pool, track_index, bin_folder, reconcile_report = (
        _prepare_executor_target(
            project, timeline, request, track_name, bin_name,
            checkpoint_state,
        )
    )

    reuse_count, preserved_markers, cleared, cleared_bin = (
        _prepare_reuse_and_clear(
            timeline, track_index, media_pool, bin_folder, unit_hashes,
            ckpt, wants_reuse, require_empty_track, clean_bin,
            prefix=OWNED_CLIP_PREFIX, marker_for=_owned_marker,
        )
    )

    baked_names = []
    pool_items = []
    # Media-pool ids parallel to the committed prefix (preserved_markers +
    # baked_names): recorded in every checkpoint so a later resume can map
    # committed clips onto actual bin entries by identity, not position.
    committed_pool_ids = []
    resumed_from = 0

    # Live finding (2026-08-25 smoke test): _clear_owned_clips removes stale
    # app-owned items, which changes the token's itemCount component — the
    # per-line identity re-check then fails with token-mismatch against the
    # caller's pre-clear snapshot on EVERY re-run onto a track holding owned
    # work. Only app-owned artifacts were removed, so the post-clear
    # composite is deterministic: re-baseline once here and verify each
    # line against that. Checkpoints record the same baseline so a resumed
    # run's fresh `info` token (reflecting the already-cleared track) matches.
    loop_request = dict(request)
    loop_request["expectedToken"] = _timeline_identity(
        project, timeline)[0]["compositeToken"]

    if wants_reuse:
        # Reuse run: authoring starts AFTER the preserved prefix. The reused
        # clips' bin entries stay untouched; only the re-authored suffix
        # gets fresh placement. Carry the reused prefix's recorded media ids
        # forward when available so later resumes keep identity mapping.
        start_index = reuse_count
        stored_ids = ckpt.get("binMediaIds") if ckpt else None
        if isinstance(stored_ids, list):
            committed_pool_ids = list(stored_ids[:reuse_count])
            committed_pool_ids += [None] * (reuse_count - len(committed_pool_ids))
    elif ckpt is not None:
        # Resume: map committed clips onto bin entries by the media ids
        # recorded at bake time. Reconciliation above already validated this
        # mapping and cleaned or adopted everything beyond the prefix — but
        # re-validate here rather than trusting positional order, and fail
        # safe to a full run if anything is off.
        resumed_ids = [str(c) for c in (ckpt.get("completedClipIds") or [])]
        matched = _validated_resume_prefix(
            ckpt, _bin_entry_list(bin_folder))
        if resumed_ids and matched is not None:
            resumed_from = len(matched)
            baked_names = list(resumed_ids)
            pool_items = [entry["clip"] for entry in matched]
            committed_pool_ids = [entry["id"] for entry in matched]
            start_index = resumed_from

            # Prefix-hash validation (proofread-edit safety): a resume must
            # not bake old committed clips under a CHANGED document. Any
            # mismatch over the claimed prefix — or a checkpoint without
            # comparable hashes — falls back to a clean FULL run instead of
            # producing a franken-result. (Adopted lines are the exception:
            # reconciliation verified them structurally but no hash was
            # recorded at bake time, so their hashes are backfilled from the
            # incoming document rather than invalidating every adoption.)
            stored_hashes = ckpt.get("clipHashes")
            if (isinstance(stored_hashes, list)
                    and len(stored_hashes) < start_index):
                stored_hashes = (stored_hashes
                                 + unit_hashes[len(stored_hashes):start_index])
            hash_ok = (
                isinstance(stored_hashes, list)
                and len(stored_hashes) >= start_index
                and unit_hashes[:start_index] == stored_hashes[:start_index]
            )
            if not hash_ok:
                sys.stderr.write(
                    "warning: document changed over the checkpoint's "
                    f"committed prefix ({start_index} line(s)) — falling "
                    "back to a clean full run.\n")
                emit_progress("resume-invalidated", None,
                              reason="prefix-hash-mismatch",
                              committed=start_index)
                checkpoint_path = _checkpoint_path(runstate_dir, timeline_id)
                sys.stderr.write(
                    f"warning: discarding committed prefix "
                    f"({checkpoint_path}).\n")
                ckpt["completedClipIds"] = []
                ckpt["completedLines"] = 0
                resumed_from = 0
                baked_names = []
                pool_items = []
                committed_pool_ids = []
                start_index = 0
        else:
            sys.stderr.write(
                "warning: resume invalidated — checkpoint's committed "
                "clips cannot be verified against the destination bin. "
                "Falling back to a clean full run.\n")
            emit_progress("resume-invalidated", None,
                          reason="bin-identity-unverifiable")
            start_index = 0
    else:
        start_index = 0

    if total == 0:
        emit_progress("done", 1.0, clearedOwnedClips=cleared)
        result = {
            "status": "done",
            "clipCount": 0,
            "bakedClipNames": [],
            "placedCount": 0,
            "clearedOwnedClips": cleared,
            "clearedBinClips": cleared_bin,
            "resumedFrom": 0,
            "reused": 0,
            "reauthored": 0,
        }
        if persist:
            result["checkpointPath"] = _checkpoint_path(runstate_dir, timeline_id)
        return result

    def save_ckpt():
        """Durably record progress after EVERY authored line."""
        completed_ids = preserved_markers + baked_names
        _save_checkpoint(runstate_dir, timeline_id, {
            "completedLines": len(completed_ids),
            "completedClipIds": completed_ids,
            "clipHashes": unit_hashes[:len(completed_ids)],
            "binMediaIds": committed_pool_ids[:len(completed_ids)],
            "lastToken": loop_request["expectedToken"],
            "lastCheckpointAt": _iso_now(),
            "pid": os.getpid(),
        })

    if persist:
        try:
            save_ckpt()
        except OSError as exc:
            sys.stderr.write(
                f"warning: couldn't write initial checkpoint: {exc}\n")

    # One scratch timeline for the WHOLE run (2 current-timeline switches,
    # not 2 per line — visible UI jitter otherwise, confirmed live). Baked
    # clips land straight in the destination bin via SetCurrentFolder.
    _delete_stale_scratch_timelines(project, media_pool)
    # Size the scratch to the REAL timeline BEFORE anything is baked on it:
    # a baked Fusion clip inherits the resolution of the timeline it was
    # baked on, so this is what keeps a 9:16 edit from getting 16:9
    # captions (_create_scratch_timeline).
    target_resolution = _timeline_resolution(timeline)
    scratch = _setup_scratch_timeline(project, media_pool, target_resolution)
    target_fps = _timeline_frame_rate(timeline)
    source_fps = _timeline_frame_rate(scratch)
    overflow_probe_findings = []
    last_heartbeat = time.time()
    try:
        for offset in range(start_index, total):
            clip_doc = clips[offset]
            line_number = offset + 1
            # Cheap identity re-check before EACH line's work: fail loud on
            # a mutated timeline instead of baking into the wrong one.
            verify_token(loop_request, project, timeline)
            emit_progress("baking", line_number / total,
                          line=line_number, total=total)
            now = time.time()
            if (line_number % HEARTBEAT_EVERY_N_LINES == 0
                    or now - last_heartbeat >= HEARTBEAT_SECONDS):
                emit({"event": "heartbeat", "line": line_number})
                last_heartbeat = now
            # Snapshot the bin so the freshly baked pool item can be found
            # even though Fusion clips cannot be renamed via SetClipProperty
            # (confirmed live: it returns False for them).
            before = _bin_clip_list(bin_folder)
            bake_doc = _rescale_clip_doc_for_fps(
                clip_doc, source_fps, target_fps)
            baked_names.append(_author_clip_on_track(
                scratch, 1, media_pool, bin_folder, bake_doc,
                line_number, request_style=request_style,
                highlight_style=highlight_style,
                highlight_color=highlight_color,
                target_resolution=target_resolution,
                probe_findings=overflow_probe_findings,
            ))
            fresh = _new_bin_clips(before, _bin_clip_list(bin_folder))
            pool_items.append(fresh[-1] if fresh else None)
            fresh_id = None
            if fresh:
                try:
                    fresh_id = str(fresh[-1].GetMediaId())
                except Exception:
                    fresh_id = None  # fail-quiet getter; resume fails safe
            committed_pool_ids.append(fresh_id)
            if persist:
                try:
                    save_ckpt()
                except OSError as exc:
                    # Durability failure must not abort authoring — warn and
                    # keep going; worst case resume starts further back.
                    sys.stderr.write(
                        f"warning: checkpoint write failed after line "
                        f"{line_number}: {exc}\n")

        # Back to the real timeline for placement (AppendToTimeline targets
        # the current timeline).
        if not project.SetCurrentTimeline(timeline):
            raise BridgeFailure(
                "placement-failed",
                "Couldn't switch back to the target timeline for placement.",
            )
        _verify_current_timeline_is(project, timeline)
        # Placement is its own mutation phase. The last loop check happened
        # before the final scratch bake, so re-validate the full token here
        # to catch an editor change made while authoring was in progress.
        verify_token(loop_request, project, timeline)
        emit_progress("placing", 0.95, lines=len(baked_names))
        # Reuse runs place ONLY the re-authored suffix: the preserved prefix
        # never left the track, so re-placing it would double-stack.
        place_docs = clips[start_index:] if wants_reuse else clips
        placed_count = _place_baked_clips(
            media_pool, bin_folder, place_docs, baked_names, pool_items,
            track_index, int(timeline.GetStartFrame()),
            source_fps=source_fps, target_fps=target_fps,
        )
        if placed_count < len(place_docs):
            # AppendToTimeline is a documented fail-quiet API (returns
            # None/empty rather than raising) — every clip up to here was
            # baked and checkpointed successfully, so without this check a
            # silent placement shortfall would still report "done" with the
            # full requested clipCount, even though nothing (or only some)
            # landed on the actual timeline. The live bug this closes is the
            # fail-quiet AppendToTimeline returning fewer items than requested
            # (Swift's AuthorTextplusResult DOES decode `placedCount`, but the
            # structured error here is the authoritative guard either way).
            raise BridgeFailure(
                "placement-incomplete",
                f"Baked {len(place_docs)} clip(s) but only {placed_count} "
                "landed on the timeline — Resolve's AppendToTimeline "
                "returned fewer than requested. The baked clips are still "
                "in the bin; re-running will retry placement without "
                "re-baking what's already there.",
            )
    except Exception as exc:
        # Never leave Resolve sitting on the scratch timeline after a
        # failure — the editor would face an empty phantom timeline.
        try:
            project.SetCurrentTimeline(timeline)
        except Exception:
            pass
        # Checkpoint state is already durable (saved per-line); report where
        # a resumed run would pick up.
        completed = len(preserved_markers) + len(baked_names)
        if isinstance(exc, BridgeFailure):
            exc.extra = {**exc.extra, "resumableAt": completed}
            raise
        raise BridgeFailure(
            "execution-failed",
            f"{type(exc).__name__}: {exc}",
            extra={"resumableAt": completed},
        ) from exc
    finally:
        _cleanup_scratch_timeline(project, media_pool, scratch)

    # Placement is verified by this point (the placement-incomplete guard
    # above raises otherwise), so the animated captions are now the
    # authoritative ones on this timeline.
    disabled_subtitle_tracks, restored_video_tracks = _disable_subtitle_tracks(timeline)

    emit_progress("done", 1.0, clearedOwnedClips=cleared)
    result = {
        "status": "done",
        "clipCount": total,
        "bakedClipNames": baked_names,
        "placedCount": placed_count,
        "disabledSubtitleTracks": disabled_subtitle_tracks,
        "restoredVideoTracks": restored_video_tracks,
        "clearedOwnedClips": cleared,
        "clearedBinClips": cleared_bin,
        "resumedFrom": resumed_from,
        "reused": reuse_count,
        "reauthored": total - reuse_count,
        "overflowProbe": {"status": "verified", "findings": overflow_probe_findings},
    }
    if reconcile_report is not None:
        result["reconcile"] = reconcile_report
    if persist:
        result["checkpointPath"] = _checkpoint_path(runstate_dir, timeline_id)
    return result


def author_textplus(request_json: JSONRequest) -> JSONMapping:
    """Consume an AnimationDocument.

    Default (pass-through, protocol verification): verifies the bridge
    protocol (NDJSON progress, token verification, structured errors) works
    for large payloads, echoing back the clip count.

    With "execute": true, runs the full Multi-Clip executor (§6): prepares
    the animate track + bin, authors and bakes one Fusion clip per line on
    a scratch timeline, and places them on the dedicated track.

    With `reuseCheckpoint: true` (+ runstateDir), a proofread-edit re-run
    reuses previously baked+placed clips for the unchanged PREFIX of clips
    and only clears/re-authors the changed suffix (fail-loud
    `reuse-state-invalid` when the track no longer matches the checkpoint).

    Optional captured style (both this mode and author-persistent-title):
    "stylePayload" — the RAW Text+ SaveSettings dict (the app reads the
    .caproj preset file and sends just its "settings"), or "stylePath" — a
    path to that preset file, which the bridge reads + extracts itself.
    Loaded onto every authored Text+ BEFORE text/spline authoring so
    authored keyframes always win over loaded state.
    """
    request = _parse_request(request_json, error_code="invalid_json")

    expected_token = request.get("expectedToken")
    if not expected_token:
        raise BridgeFailure("missing_token", "expectedToken is required")

    resolve = load_resolve()
    project, timeline = open_project_timeline(resolve)
    verify_token(request, project, timeline)

    animation_document_json = request.get("animationDocument")
    if not animation_document_json:
        raise BridgeFailure("missing_document", "animationDocument JSON is required")

    if isinstance(animation_document_json, str):
        try:
            doc = json.loads(animation_document_json)
        except json.JSONDecodeError as e:
            raise BridgeFailure("invalid_document", f"animationDocument is not valid JSON: {e}")
    else:
        doc = animation_document_json

    emit_progress("receiving", 0.0)

    if not request.get("execute"):
        clips = doc.get("clips", [])
        clip_count = len(clips)

        emit_progress("done", 1.0)

        return {
            "status": "received",
            "clipCount": clip_count,
        }

    return _execute_animation_document(request, doc)


# --------------------------------------------------------------------------
# Persistent-Title executor — window-baked model
# (docs/PERSISTENT-TITLE-DESIGN.md §6, chunk 4.0.13)
#
# The §6.1 "one persistent Text+ re-authored" mechanism is impossible live
# (F1–F3): a live title can't span a region or be placed on demand. What
# survives is window-granularity baking: pack consecutive cues into <=4.8 s
# windows (~62 ms/window measured, flat), author each window's 2-3 cues as
# COEXISTING visibility-windowed Text+ tools inside ONE comp, bake one Fusion
# Clip per window on the scratch timeline, and place frame-exact via
# AppendToTimeline with CaptionSuite-W#### markers.
#
# Visibility-windowing choice: each cue is routed through a dedicated Merge
# whose Background is transparent and whose Foreground is the cue's TextPlus
# chain. A stepped spline on that Merge's Blend input makes the whole cue
# branch transparent outside its slice. This is deliberately not attached to
# TextPlus.Blend: a live Resolve repro showed that generator-level Blend
# gating can leave multiple TextPlus generators visible (and can render a
# solo gated generator black), while Merge.Blend is the documented image
# compositing control.
# --------------------------------------------------------------------------

# Conservative default window cap. The real hard ceiling is Resolve's ~5 s
# (120 frames @ 24 fps) Text+ insert/bake cap: windows must never be packed
# longer than that or authoring breaks. DEFAULT_MAX_WINDOW_SECONDS is the
# app's default cap UNDER that ceiling; a per-request `windowing.maxWindowSeconds`
# may LOWER it (tighter windows) but is clamped so it can never raise it past
# HARD_MAX_WINDOW_SECONDS. Live per-timeline measurement of the true cap is
# deferred (too risky/heavy for v1).
DEFAULT_MAX_WINDOW_SECONDS = 4.8
HARD_MAX_WINDOW_SECONDS = 5.0  # < the insert/bake cap; never exceed this


def _pack_windows(clips, max_window_seconds=DEFAULT_MAX_WINDOW_SECONDS,
                  fps=24.0, max_cues_per_window=8):
    """Greedy packing of consecutive clips into <=max_window_seconds windows.

    A window spans from its FIRST clip's startFrame to the current clip's
    endFrame; adding a clip that would push that span over the cap starts a
    new window. Cues are never split across windows ("alignTo": "cue"), and
    a single cue longer than the cap gets its own window rather than failing
    (placement sets an explicit endFrame beyond the baked source, which is
    live-proven to work — F3). Pure function: no Resolve API involvement.

    Returns a list of lists of the original clip dicts, in order.
    """
    try:
        max_frames = max(int(round(float(max_window_seconds) * float(fps))), 1)
    except (TypeError, ValueError):
        raise BridgeFailure(
            "bad-windowing",
            f"windowing.maxWindowSeconds ({max_window_seconds!r}) and fps "
            f"({fps!r}) must be numbers.",
        ) from None

    windows = []
    current = []
    for clip in clips:
        start = int(clip.get("startFrame") or 0)
        end = int(clip.get("endFrame") or 0)
        if end - start > max_frames:
            raise BridgeFailure(
                "window-duration-exceeds-cap",
                f"Cue {clip.get('clipId')!r} spans {end - start} frame(s), "
                f"which exceeds the {max_frames}-frame window authoring cap. "
                "Re-segment the cue before animation; Resolve cannot safely "
                "bake an oversized Text+ window.",
            )
        if current:
            window_start = int(current[0].get("startFrame") or 0)
            # Start a fresh window when EITHER the time cap (max_frames) OR
            # the cue-count cap (max_cues_per_window) would be exceeded by
            # adding this cue — bounding comp complexity (Area 8 F2), not
            # just window duration.
            if (len(current) >= max_cues_per_window
                    or end - window_start > max_frames):
                windows.append(current)
                current = []
        current.append(clip)
    if current:
        windows.append(current)
    return windows


def _owned_window_marker(window_number):
    return f"{OWNED_WINDOW_PREFIX}{window_number:04d}"


def _shift_curve(curve, offset_frames):
    """Shift a document curve's entries into window-local (comp-local)
    frames by `offset_frames`; returns (entries, stepped)."""
    entries, stepped = _curve_entries(curve)
    return [
        {"frame": float(entry["frame"]) + offset_frames,
         "value": float(entry["value"])}
        for entry in entries
    ], stepped


def _attach_visibility_gate(comp, merge, start_local, end_local,
                            window_length):
    """Gate a cue branch to ``[start_local, end_local)`` on a Merge.

    The Merge must have a transparent Background and the cue branch as its
    Foreground. At Blend=0 the output is therefore transparent; at Blend=1
    it is the cue branch. Keeping this gate downstream of TextPlus avoids the
    generator-level Blend behavior that failed in live Resolve testing."""
    start_local = max(int(start_local), 0)
    end_local = min(max(int(end_local), start_local + 1), int(window_length))
    entries = []
    if start_local > 0:
        entries.append({"frame": 0, "value": 0.0})
    entries.append({"frame": start_local, "value": 1.0})
    entries.append({"frame": end_local, "value": 0.0})
    _attach_stepped_spline(comp, merge, "Blend", entries, stepped=True)


def _make_visibility_gate(comp, source_tool, transparent_background,
                          start_local, end_local, window_length, context):
    """Return a transparent-background Merge that gates ``source_tool``."""
    gate = comp.AddTool("Merge")
    if not gate:
        raise BridgeFailure(
            "visibility-gate-failed",
            f"{context}: couldn't create the visibility-gate Merge.",
        )
    gate.Background = transparent_background.Output
    gate.Foreground = source_tool.Output
    _attach_visibility_gate(comp, gate, start_local, end_local, window_length)
    return gate


def _author_cue_tools_in_comp(comp, cue_doc, window_start_frame,
                              window_length, tail_tool=None,
                              style_settings=None,
                              highlight_style_settings=None,
                              highlight_color=None,
                              transparent_background=None,
                              target_resolution=None, probe_findings=None):
    """Author ONE cue's tools (base Text+ + optional highlight overlay)
    inside a window comp. The cue's local TextPlus chain is first routed
    through a transparent-background Merge gate; that gated branch is then
    merged onto `tail_tool` (the preceding cue branches). All frames are
    shifted into window-local space; only this cue's slice is opaque.

    Returns the new chain tail: the last tool Fusion must render for this
    cue's slice. The caller wires it into MediaOut after all cues are
    authored — see _merge_over for why every extra tool MUST be merged into
    the MediaOut-fed chain (AddTool never auto-connects; orphaned tools do
    not render).
    """
    try:
        cue_start = int(cue_doc.get("startFrame") or 0)
        cue_end = int(cue_doc.get("endFrame") or 0)
    except (TypeError, ValueError):
        raise BridgeFailure(
            "bad-clip-frames",
            f"Cue {cue_doc.get('clipId')!r}: startFrame/endFrame must be "
            "integers.",
        ) from None
    text = str(cue_doc.get("text") or "")
    offset = cue_start - window_start_frame
    cue_length = max(cue_end - cue_start, 1)

    keyframes = cue_doc.get("keyframes")
    if not isinstance(keyframes, dict) or "End" not in keyframes:
        raise BridgeFailure(
            "missing-keyframes",
            f"Cue {cue_doc.get('clipId')!r}: animation document has no "
            "'End' keyframe curve.",
        )
    end_entries, end_stepped = _shift_curve(keyframes["End"], offset)
    if not end_entries:
        raise BridgeFailure(
            "missing-keyframes",
            f"Cue {cue_doc.get('clipId')!r}: 'End' keyframe curve has no "
            "entries.",
        )
    if transparent_background is None:
        # The window executor creates one shared background for the whole
        # comp. Keep this private helper safe for focused callers/tests too;
        # a direct one-cue call gets an equivalent local background.
        transparent_background = comp.AddTool("Background")
        if not transparent_background:
            raise BridgeFailure(
                "visibility-gate-failed",
                f"Cue {cue_doc.get('clipId')!r}: couldn't create the "
                "transparent visibility-gate background.",
            )
        transparent_background.SetInput("TopLeftAlpha", 0.0)

    base_tool = comp.AddTool("TextPlus")
    if not base_tool:
        raise BridgeFailure(
            "textplus-create-failed",
            f"Cue {cue_doc.get('clipId')!r}: couldn't create the base "
            "TextPlus in the window comp.",
        )
    if style_settings:
        # LoadSettings overwrites EVERY input incl. text — run BEFORE content
        # authoring so our values always win (multi-clip invariant). A5:
        # re-locate the tool by position/role afterwards, never by name.
        # `exclude` keeps role-match relocation from stealing a tool this
        # comp already owns (the previous cue's chain).
        base_tool = _apply_captured_style(
            comp, base_tool, style_settings,
            f"Cue {cue_doc.get('clipId')!r}", exclude=[tail_tool])
    base_tool.SetInput("StyledText", text)
    base_tool.SetInput("Start", 0.0)
    _strip_spline_modifiers(base_tool, ("Start", "End", "Blend"))
    _attach_stepped_spline(
        comp, base_tool, "End", end_entries,
        stepped=end_stepped, clip_length_frames=offset + cue_length,
    )
    if probe_findings is not None:
        finding = _probe_textplus_overflow(
            comp, base_tool, str(cue_doc.get("clipId") or "cue"),
            target_resolution, fully_revealed_frame=offset + cue_length - 1)
        probe_findings.append(finding)
    cue_tool = base_tool

    overlay_curves = cue_doc.get("overlayKeyframes")
    if overlay_curves:
        # Highlight overlay: ported straight from the multi-clip builder —
        # second TextPlus in the SAME comp, same text, lagged reveal.
        overlay_tool = comp.AddTool("TextPlus")
        if not overlay_tool:
            raise BridgeFailure(
                "overlay-create-failed",
                f"Cue {cue_doc.get('clipId')!r}: couldn't create the "
                "highlight overlay TextPlus.",
            )
        overlay_style = highlight_style_settings or style_settings
        if overlay_style:
            # Base and overlay can now carry distinct captured styles; keep
            # the same load-before-content ordering as the base tool above.
            overlay_tool = _apply_captured_style(
                comp, overlay_tool, overlay_style,
                f"Cue {cue_doc.get('clipId')!r} overlay",
                exclude=[base_tool, tail_tool])
        overlay_tool.SetInput("StyledText", text)
        _strip_spline_modifiers(overlay_tool, ("Start", "End", "Blend"))
        start_curve = overlay_curves.get("Start")
        if start_curve:
            s_entries, s_stepped = _shift_curve(start_curve, offset)
            if s_entries:
                # Same half-char-cell value lead, same-frame keying as the
                # multi-clip builder (see _lead_start_entries).
                _attach_stepped_spline(
                    comp, overlay_tool, "Start",
                    _lead_start_entries(s_entries, text),
                    stepped=s_stepped,
                )
        end_curve_ov = overlay_curves.get("End")
        if end_curve_ov:
            o_entries, o_stepped = _shift_curve(end_curve_ov, offset)
            _attach_stepped_spline(
                comp, overlay_tool, "End", o_entries,
                stepped=o_stepped, clip_length_frames=offset + cue_length,
            )
        # Distinct fill color for the highlight layer (after LoadSettings,
        # which overwrites every input) — see _apply_highlight_color.
        # See the identical call in _author_clip_on_track: `highlight_color`
        # arrives already parsed, so only the per-cue override is hex.
        _apply_highlight_color(
            overlay_tool,
            _parse_hex_color(cue_doc.get("highlightColor")) or highlight_color)
        # Same zero-movement invariant as the multi-clip builder: identical
        # layout inputs on both layers, base's values authoritative (see
        # _mirror_layout_inputs for the 0.09-vs-0.08 template divergence).
        _mirror_layout_inputs(base_tool, overlay_tool)
        # Overlay rides ON TOP of its own base: Foreground of a fresh Merge
        # over the running chain (which ends at this cue's base).
        cue_tool = _merge_over(
            comp, cue_tool, overlay_tool,
            f"Cue {cue_doc.get('clipId')!r} overlay")

    gated_tool = _make_visibility_gate(
        comp, cue_tool, transparent_background, offset,
        offset + cue_length, window_length,
        f"Cue {cue_doc.get('clipId')!r}",
    )
    return gated_tool if tail_tool is None else _merge_over(
        comp, tail_tool, gated_tool, f"Cue {cue_doc.get('clipId')!r} base")


def _author_window_baked_clip(timeline, track_index, media_pool, bin_folder,
                              window_clips, window_number,
                              style_settings=None,
                              highlight_style_settings=None,
                              highlight_color=None,
                              target_resolution=None, probe_findings=None):
    """Author ONE window as a single baked Fusion clip.

    `target_resolution` — see `_author_clip_on_track`'s doc comment; same
    reasoning, same fix (`comp.SetPrefs` after the comp is reachable).

    All of the window's cues are authored as coexisting visibility-windowed
    Text+ tools inside one comp under one undo bracket, BEFORE
    CreateFusionClip (a baked comp is unreachable afterwards — F3).
    Everything else mirrors `_author_clip_on_track`: scratch timeline hosting,
    bin targeting, ownership-marker naming, leftover sweep.

    Returns the baked window's marker name (CaptionSuite-W####).
    """
    window_number = int(window_number)
    window_start = int(window_clips[0].get("startFrame") or 0)
    window_end = int(window_clips[-1].get("endFrame") or 0)
    window_length = max(window_end - window_start, 1)
    clip_name = _owned_window_marker(window_number)

    if bin_folder is not None:
        try:
            media_pool.SetCurrentFolder(bin_folder)
        except Exception:
            pass  # best-effort; worst case the clip lands in the current folder

    title_item = timeline.InsertFusionTitleIntoTimeline("Text+")
    if not title_item:
        raise BridgeFailure(
            "title-insert-failed",
            f"Window {window_number}: couldn't insert a Text+ title "
            "(fail-quiet API returned None).",
        )
    try:
        comp = title_item.GetFusionCompByIndex(1)
        if not comp:
            raise BridgeFailure(
                "no-comp",
                f"Window {window_number}: the inserted title's Fusion comp "
                "is not reachable.",
            )
        _apply_comp_frame_format(comp, target_resolution)
        # Undo-bracketed writes around ALL comp mutations; EndUndo(False) so
        # scratch comps don't accumulate permanent undo-stack entries.
        comp.StartUndo(f"Animate window {window_number}")
        try:
            # The inserted title's own placeholder TextPlus (Template) is
            # NOT part of the authored chain: drop it so the comp renders
            # only what this executor authors.
            for candidate in list((comp.GetToolList(False) or {}).values()):
                if getattr(candidate, "ID", None) == "TextPlus":
                    candidate.Delete()
            media_out = _find_media_out(comp)
            transparent_background = comp.AddTool("Background")
            if not transparent_background:
                raise BridgeFailure(
                    "visibility-gate-failed",
                    f"Window {window_number}: couldn't create the "
                    "transparent visibility-gate background.",
                )
            # A transparent full-frame image is the Merge gate's off-state;
            # it also supplies a stable output resolution to every gate.
            transparent_background.SetInput("TopLeftAlpha", 0.0)
            tail = None
            for cue_doc in window_clips:
                tail = _author_cue_tools_in_comp(
                    comp, cue_doc, window_start, window_length,
                    tail_tool=tail, style_settings=style_settings,
                    highlight_style_settings=highlight_style_settings,
                    highlight_color=highlight_color,
                    transparent_background=transparent_background,
                    target_resolution=target_resolution,
                    probe_findings=probe_findings,
                )
            if tail is None:
                raise BridgeFailure(
                    "no-window-tools",
                    f"Window {window_number}: no tools were authored — "
                    "the window carries no cues.",
                )
            # Only the final Merge feeds MediaOut; everything upstream is
            # reachable through it (root cause of the invisible-highlight
            # bug: orphaned tools never render). Output-attribute assignment
            # — SetInput with a tool object is a fail-quiet no-op on
            # 21.0.4.5.
            media_out.Input = tail.Output
        finally:
            comp.EndUndo(False)

        baked_item = timeline.CreateFusionClip([title_item])
        if not baked_item:
            raise BridgeFailure(
                "bake-failed",
                f"Window {window_number}: CreateFusionClip returned None.",
            )
        pool_item = baked_item.GetMediaPoolItem()
        if not pool_item:
            raise BridgeFailure(
                "bake-failed",
                f"Window {window_number}: baked clip has no MediaPoolItem.",
            )
        pool_item.SetClipProperty("Clip Name", clip_name)
        return clip_name
    finally:
        # Sweep raw/baked items off the scratch track so the next window's
        # insert never lands on top of a leftover.
        leftover = timeline.GetItemListInTrack("video", track_index)
        if leftover:
            timeline.DeleteClips(list(leftover), False)


def _execute_persistent_title(request, doc):
    """Full Window-Baked execution: prep track/bin, pack cues into windows,
    author + bake one Fusion clip per window on a scratch timeline, place
    the baked clips on the dedicated track with W markers.

    Checkpoints at WINDOW granularity (completedWindows/completedClipIds);
    D13 reconciliation, clear-and-reuse, and token verification mirror the
    multi-clip executor identically."""
    resolve = load_resolve()
    check_version(resolve)
    _ensure_edit_page(resolve)
    _sweep_stale_scratches_before(resolve, "before target resolution")
    project, timeline = open_project_timeline(resolve)
    verify_token(request, project, timeline)

    # Request-level captured style (optional; validated BEFORE any mutation):
    # a raw SaveSettings dict via "stylePayload" or a preset file via
    # "stylePath" — see _resolve_style_payload. A document-embedded
    # `styleSettings` (composer-authored) takes precedence over it.
    request_style = _resolve_style_payload(request)
    highlight_style = _resolve_overlay_style_payload(request, request_style)
    # Highlight overlay fill color (optional, validated up front): the
    # .capproj preset's HighlightWindowParams.highlightColor.
    highlight_color = _parse_hex_color(request.get("highlightColor"))

    placement = doc.get("placement") or {}
    track_name = request.get("trackName") \
        or placement.get("trackName") or ANIMATE_TRACK_NAME
    bin_name = request.get("binName") \
        or placement.get("binName") or f"CaptionSuite — {timeline.GetName()}"

    clips = doc.get("clips") or []
    total_clips = len(clips)

    _, fps, _ = _timeline_identity(project, timeline)
    windowing = request.get("windowing") or {}
    # Honor an explicit per-request cap when supplied; otherwise fall back to
    # the conservative default. The request value is clamped to the hard
    # insert/bake ceiling (HARD_MAX_WINDOW_SECONDS) so a caller can never push
    # a window past what Resolve can author (Area 8 F1).
    requested_window = windowing.get("maxWindowSeconds")
    if requested_window is not None:
        try:
            max_window_seconds = min(
                float(requested_window), HARD_MAX_WINDOW_SECONDS)
        except (TypeError, ValueError):
            max_window_seconds = DEFAULT_MAX_WINDOW_SECONDS
    else:
        max_window_seconds = DEFAULT_MAX_WINDOW_SECONDS
    try:
        max_cues = int(windowing.get("maxCuesPerWindow", 8) or 8)
    except (TypeError, ValueError):
        max_cues = 8
    windows = _pack_windows(clips, max_window_seconds, fps, max_cues)
    total_windows = len(windows)
    emit_progress("packed", 0.01, cues=total_clips, windows=total_windows)

    # Checkpointing (all optional): without a runstateDir everything stays
    # in-memory and no files are written.
    checkpoint_state = _load_executor_checkpoint(request, timeline)
    runstate_dir = checkpoint_state["runstate_dir"]
    timeline_id = checkpoint_state["timeline_id"]
    persist = checkpoint_state["persist"]
    expected_token = checkpoint_state["expected_token"]
    wants_resume = checkpoint_state["wants_resume"]
    wants_reuse = checkpoint_state["wants_reuse"]
    ckpt = checkpoint_state["checkpoint"]
    require_empty_track = bool(request.get("requireEmptyTrack"))
    clean_bin = bool(request.get("cleanBin"))

    # Proofread-edit prefix reuse at WINDOW granularity: each window's hash
    # covers its full cue list, so any cue change rebakes that window.
    unit_hashes = [_window_content_hash(w) for w in windows]

    reconcile_mode = request.get("reconcileMode") or "clean"
    if reconcile_mode not in ("clean", "adopt"):
        raise BridgeFailure(
            "bad-reconcile-mode",
            f"reconcileMode must be 'clean' or 'adopt', got "
            f"{reconcile_mode!r}.",
        )

    media_pool, track_index, bin_folder, reconcile_report = (
        _prepare_executor_target(
            project, timeline, request, track_name, bin_name,
            checkpoint_state, prefix=OWNED_WINDOW_PREFIX,
            marker_for=_owned_window_marker,
        )
    )

    reuse_count, preserved_markers, cleared, cleared_bin = (
        _prepare_reuse_and_clear(
            timeline, track_index, media_pool, bin_folder, unit_hashes,
            ckpt, wants_reuse, require_empty_track, clean_bin,
            prefix=OWNED_WINDOW_PREFIX, marker_for=_owned_window_marker,
        )
    )

    baked_names = []
    pool_items = []
    # Media-pool ids parallel to the committed prefix (preserved_markers +
    # baked_names): recorded in every checkpoint so a later resume can map
    # committed windows onto actual bin entries by identity, not position.
    committed_pool_ids = []
    resumed_from = 0

    # Live finding (2026-08-25 smoke test): _clear_owned_clips removes stale
    # app-owned items, which changes the token's itemCount component — the
    # per-window identity re-check then fails with token-mismatch against
    # the caller's pre-clear snapshot on EVERY re-run onto a track holding
    # owned work. Only app-owned artifacts were removed, so the post-clear
    # composite is deterministic: re-baseline once here and verify each
    # window against that. Checkpoints record the same baseline so a resumed
    # run's fresh `info` token (reflecting the already-cleared track) matches.
    loop_request = dict(request)
    loop_request["expectedToken"] = _timeline_identity(
        project, timeline)[0]["compositeToken"]

    if wants_reuse:
        # Reuse run: bake only windows after the preserved prefix; their bin
        # entries and placed instances stay untouched. Carry the reused
        # prefix's recorded media ids forward when available so later
        # resumes keep identity mapping.
        start_index = reuse_count
        stored_ids = ckpt.get("binMediaIds") if ckpt else None
        if isinstance(stored_ids, list):
            committed_pool_ids = list(stored_ids[:reuse_count])
            committed_pool_ids += [None] * (reuse_count - len(committed_pool_ids))
    elif ckpt is not None:
        # Resume: map committed windows onto bin entries by the media ids
        # recorded at bake time (same identity discipline as the multi-clip
        # executor). Reconciliation above already validated this mapping;
        # re-validate here rather than trusting positional order, and fail
        # safe to a full run if anything is off — including a document that
        # changed over the claimed prefix (prefix-hash validation).
        resumed_ids = [str(c) for c in (ckpt.get("completedClipIds") or [])]
        matched = _validated_resume_prefix(
            ckpt, _bin_entry_list(bin_folder))
        if resumed_ids and matched is not None:
            resumed_from = len(matched)
            baked_names = list(resumed_ids)
            pool_items = [entry["clip"] for entry in matched]
            committed_pool_ids = [entry["id"] for entry in matched]
            start_index = resumed_from

            stored_hashes = ckpt.get("clipHashes")
            if (isinstance(stored_hashes, list)
                    and len(stored_hashes) < start_index):
                stored_hashes = (stored_hashes
                                 + unit_hashes[len(stored_hashes):start_index])
            hash_ok = (
                isinstance(stored_hashes, list)
                and len(stored_hashes) >= start_index
                and unit_hashes[:start_index] == stored_hashes[:start_index]
            )
            if not hash_ok:
                sys.stderr.write(
                    "warning: document changed over the checkpoint's "
                    f"committed prefix ({start_index} window(s)) — falling "
                    "back to a clean full run.\n")
                emit_progress("resume-invalidated", None,
                              reason="prefix-hash-mismatch",
                              committed=start_index)
                ckpt["completedClipIds"] = []
                ckpt["completedLines"] = 0
                resumed_from = 0
                baked_names = []
                pool_items = []
                committed_pool_ids = []
                start_index = 0
        else:
            sys.stderr.write(
                "warning: resume invalidated — checkpoint's committed "
                "windows cannot be verified against the destination bin. "
                "Falling back to a clean full run.\n")
            emit_progress("resume-invalidated", None,
                          reason="bin-identity-unverifiable")
            start_index = 0
    else:
        start_index = 0

    if total_windows == 0 or total_clips == 0:
        emit_progress("done", 1.0, clearedOwnedClips=cleared)
        result = {
            "status": "done",
            "clipCount": total_clips,
            "windowCount": 0,
            "placedCount": 0,
            "bakedClipNames": [],
            "avgWindowBakeMs": 0,
            "clearedOwnedClips": cleared,
            "clearedBinClips": cleared_bin,
            "resumedFrom": 0,
            "reused": 0,
            "reauthored": 0,
        }
        if persist:
            result["checkpointPath"] = _checkpoint_path(runstate_dir, timeline_id)
        return result

    def save_ckpt():
        """Durably record progress after EVERY baked window."""
        completed_ids = preserved_markers + baked_names
        _save_checkpoint(runstate_dir, timeline_id, {
            "completedWindows": len(completed_ids),
            "completedLines": len(completed_ids),  # reconcile-helper alias
            "completedClipIds": completed_ids,
            "clipHashes": unit_hashes[:len(completed_ids)],
            "binMediaIds": committed_pool_ids[:len(completed_ids)],
            "lastToken": loop_request["expectedToken"],
            "lastCheckpointAt": _iso_now(),
            "pid": os.getpid(),
        })

    if persist:
        try:
            save_ckpt()
        except OSError as exc:
            sys.stderr.write(
                f"warning: couldn't write initial checkpoint: {exc}\n")

    # One scratch timeline for the WHOLE run (same UI-jitter reasoning as
    # the multi-clip executor); baked window clips land straight in the
    # destination bin via SetCurrentFolder.
    _delete_stale_scratch_timelines(project, media_pool)
    # Size the scratch to the REAL timeline BEFORE anything is baked on it:
    # a baked Fusion clip inherits the resolution of the timeline it was
    # baked on, so this is what keeps a 9:16 edit from getting 16:9
    # captions (_create_scratch_timeline).
    target_resolution = _timeline_resolution(timeline)
    scratch = _setup_scratch_timeline(project, media_pool, target_resolution)
    target_fps = _timeline_frame_rate(timeline)
    source_fps = _timeline_frame_rate(scratch)
    style_settings = doc.get("styleSettings") or request_style
    overflow_probe_findings = []
    bake_ms_samples = []
    last_heartbeat = time.time()
    try:
        for offset in range(start_index, total_windows):
            window_clips = windows[offset]
            window_number = offset + 1
            # Identity re-check per WINDOW (the token design's mandatory
            # phase boundary for this executor — §4 of the design doc),
            # against the post-clear baseline (see loop_request above).
            verify_token(loop_request, project, timeline)
            emit_progress("baking-window", window_number / total_windows,
                          window=window_number, total=total_windows)
            now = time.time()
            if (window_number % HEARTBEAT_EVERY_N_LINES == 0
                    or now - last_heartbeat >= HEARTBEAT_SECONDS):
                emit({"event": "heartbeat", "window": window_number})
                last_heartbeat = now

            before = _bin_clip_list(bin_folder)
            started = time.time()
            bake_window_clips = [
                _rescale_clip_doc_for_fps(cue_doc, source_fps, target_fps)
                for cue_doc in window_clips
            ]
            baked_names.append(_author_window_baked_clip(
                scratch, 1, media_pool, bin_folder, bake_window_clips,
                window_number, style_settings=style_settings,
                highlight_style_settings=highlight_style,
                highlight_color=highlight_color,
                target_resolution=target_resolution,
                probe_findings=overflow_probe_findings,
            ))
            bake_ms_samples.append((time.time() - started) * 1000.0)
            fresh = _new_bin_clips(before, _bin_clip_list(bin_folder))
            pool_items.append(fresh[-1] if fresh else None)
            fresh_id = None
            if fresh:
                try:
                    fresh_id = str(fresh[-1].GetMediaId())
                except Exception:
                    fresh_id = None  # fail-quiet getter; resume fails safe
            committed_pool_ids.append(fresh_id)
            if persist:
                try:
                    save_ckpt()
                except OSError as exc:
                    sys.stderr.write(
                        f"warning: checkpoint write failed after window "
                        f"{window_number}: {exc}\n")

        # Back to the real timeline for placement (AppendToTimeline targets
        # the current timeline). Place ALL windows, including the resumed
        # prefix: a mid-bake SIGKILL (the canonical kill) leaves the killed
        # run's committed windows baked-but-never-placed, because placement
        # happens once at the very end of a run. This is safe against
        # double-placement because _clear_owned_clips above removed every
        # previously placed instance from the track (live fix 2026-08-25;
        # mirrors the multi-clip executor, which always places the full set).
        # Reuse runs are the exception: the preserved window prefix never
        # left the track, so ONLY the re-authored suffix gets placed.
        if not project.SetCurrentTimeline(timeline):
            raise BridgeFailure(
                "placement-failed",
                "Couldn't switch back to the target timeline for placement.",
            )
        _verify_current_timeline_is(project, timeline)
        # As in the multi-clip executor, placement needs its own identity
        # check after scratch authoring and immediately before mutation.
        verify_token(loop_request, project, timeline)
        emit_progress("placing", 0.95, windows=len(baked_names))
        window_docs = [
            {"startFrame": w[0].get("startFrame"),
             "endFrame": w[-1].get("endFrame")}
            for w in windows
        ]
        place_docs = (window_docs[start_index:]
                      if wants_reuse else window_docs[:len(baked_names)])
        placed_count = _place_baked_clips(
            media_pool, bin_folder, place_docs,
            baked_names, pool_items, track_index,
            int(timeline.GetStartFrame()),
            source_fps=source_fps, target_fps=target_fps,
        )
        if placed_count < len(place_docs):
            # See the identical check in _execute_animation_document for why
            # this can't be silently reported as "done".
            raise BridgeFailure(
                "placement-incomplete",
                f"Baked {len(place_docs)} window(s) but only {placed_count} "
                "landed on the timeline — Resolve's AppendToTimeline "
                "returned fewer than requested. The baked clips are still "
                "in the bin; re-running will retry placement without "
                "re-baking what's already there.",
            )
    except Exception as exc:
        # Never leave Resolve sitting on the scratch timeline after failure.
        try:
            project.SetCurrentTimeline(timeline)
        except Exception:
            pass
        completed = len(preserved_markers) + len(baked_names)
        if isinstance(exc, BridgeFailure):
            exc.extra = {**exc.extra, "resumableAt": completed}
            raise
        raise BridgeFailure(
            "execution-failed",
            f"{type(exc).__name__}: {exc}",
            extra={"resumableAt": completed},
        ) from exc
    finally:
        _cleanup_scratch_timeline(project, media_pool, scratch)

    avg_bake_ms = (
        round(sum(bake_ms_samples) / len(bake_ms_samples), 1)
        if bake_ms_samples else 0
    )
    # See the identical call in _execute_animation_document: placement is
    # verified by here, so Resolve's own subtitle track is now redundant.
    disabled_subtitle_tracks, restored_video_tracks = _disable_subtitle_tracks(timeline)

    emit_progress("done", 1.0, clearedOwnedClips=cleared)
    result = {
        "status": "done",
        "clipCount": total_clips,
        "windowCount": total_windows,
        "placedCount": placed_count,
        "disabledSubtitleTracks": disabled_subtitle_tracks,
        "restoredVideoTracks": restored_video_tracks,
        "bakedClipNames": baked_names,
        "avgWindowBakeMs": avg_bake_ms,
        "clearedOwnedClips": cleared,
        "clearedBinClips": cleared_bin,
        "resumedFrom": resumed_from,
        "reused": reuse_count,
        "reauthored": total_windows - reuse_count,
        "overflowProbe": {"status": "verified", "findings": overflow_probe_findings},
    }
    if reconcile_report is not None:
        result["reconcile"] = reconcile_report
    if persist:
        result["checkpointPath"] = _checkpoint_path(runstate_dir, timeline_id)
    return result


def mode_author_persistent_title(request_json: JSONRequest) -> JSONMapping:
    """Window-Baked persistent-title authoring
    (docs/PERSISTENT-TITLE-DESIGN.md §6).

    Consumes an AnimationDocument byte-compatible with author-textplus's
    (flat clips[], absolute frames, per-cue keyframe curves), packs the cues
    into <=~4.8 s windows Python-side (the executor owns fps and the insert
    cap), bakes ONE Fusion Clip per window containing all of the window's
    cues as visibility-windowed Text+ tools, and places the baked clips
    frame-exact on the dedicated track with CaptionSuite-W#### markers.

    Options mirror author-textplus execute:true: trackName, binName,
    runstateDir, timelineId, resume, reconcileMode, requireEmptyTrack,
    cleanBin — plus `windowing.maxWindowSeconds` (default 4.8) and the
    optional captured style (stylePayload / stylePath, see author-textplus).
    `reuseCheckpoint: true` reuses the baked+placed prefix of unchanged
    windows from the previous run's checkpoint instead of re-authoring.
    """
    request = _parse_request(request_json)

    animation_document = request.get("animationDocument")
    if not animation_document:
        raise BridgeFailure(
            "missing-document",
            "animationDocument is required.",
        )
    if isinstance(animation_document, str):
        try:
            doc = json.loads(animation_document)
        except json.JSONDecodeError as exc:
            raise BridgeFailure(
                "invalid-document",
                f"animationDocument is not valid JSON: {exc}",
            ) from exc
    else:
        doc = animation_document
    if not isinstance(doc, dict):
        raise BridgeFailure(
            "invalid-document",
            "animationDocument must be a JSON object.",
        )

    emit_progress("receiving", 0.0)
    return _execute_persistent_title(request, doc)


def mode_info(request: JSONMapping) -> JSONMapping:
    """Composite identity token (ARCHITECTURE.md §2 rule 5): project name +
    timeline identity + start frame + fps + item count.

    Every mutating mode re-verifies this token before committing work;
    mismatch = fail loud, never silent misplacement.
    """
    resolve = load_resolve()
    version = check_version(resolve)
    # Same stale-scratch sweep as the executors (live finding, 2026-08-25):
    # after a SIGKILL mid-run Resolve stays focused on the phantom scratch,
    # and the documented recovery is "re-run `info`" — which would otherwise
    # hand back the SCRATCH's identity token. Only app-named scratch
    # timelines are ever deleted here.
    _sweep_stale_scratches_before(resolve, "before info")
    project, timeline = open_project_timeline(resolve)

    token, _, _ = _timeline_identity(project, timeline)

    # Timeline resolution rides along so the app can flag a saved style
    # captured at a different shape — a Text+ sized for a 1920-wide frame
    # overflows a 1080-wide one (Text+ Size is a fraction of frame height,
    # but line width is bounded by frame width), which is exactly the
    # "16:9 style is too large for 9:16" the user hits.
    resolution = _timeline_resolution(timeline)

    return {
        "resolveVersion": version,
        "token": token,
        "timelineWidth": resolution[0] if resolution else None,
        "timelineHeight": resolution[1] if resolution else None,
    }


def _not_implemented(mode):
    def handler(request):
        raise BridgeFailure(
            "not-implemented",
            f"Mode {mode!r} is scaffolded but not implemented yet — it gets "
            "a live-verified probe before any feature builds on it "
            "(ARCHITECTURE.md §2 bridge rule 2).",
        )
    return handler


# --------------------------------------------------------------------------
# capture-style
# --------------------------------------------------------------------------

def _convert_ordered_dict(obj):
    """Recursively convert OrderedDict to regular dict for JSON serialization."""
    if isinstance(obj, OrderedDict):
        return {k: _convert_ordered_dict(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [_convert_ordered_dict(item) for item in obj]
    return obj


def capture_style(request_json: JSONRequest) -> JSONMapping:
    """Three-phase capture-style mode.

    Phase 1 (insert): create a throwaway styling timeline, put one Text+ on
    it, and leave Resolve there so the user styles it in the Inspector —
    where they're already looking, not an existing Fusion comp they'd have
    to go find (ARCHITECTURE.md §4.2 / EXECUTION-PLAN.md Step 4.3's
    documented design, amended 2026-08-27 to stage on a scratch timeline
    rather than the user's own — see `_capture_style_insert` for the live
    incidents that forced it).
    Phase 2 (capture): Done in the app — read SaveSettings(), tear the
    styling timeline down, return the payload.
    Phase 3 (discard): Cancel in the app — tear it down without reading it.
    Also swept automatically at the start of the next `insert` in case a
    previous session's scratch was never cleaned up (app crash/force-quit
    mid-capture).
    """
    request = _parse_request(request_json)

    resolve = load_resolve()
    check_version(resolve)
    _ensure_edit_page(resolve)
    project, timeline = open_project_timeline(resolve)

    phase = request.get("phase", "insert")

    # By capture/discard, Resolve's CURRENT timeline is the styling scratch
    # (insert deliberately parks the user there), so `GetCurrentTimeline()`
    # no longer identifies the real target. Recover it from the token the
    # app echoes back — it names the timeline `info` was taken against.
    if phase != "insert":
        recovered = _timeline_from_token(project, request.get("expectedToken"))
        if recovered is not None:
            timeline = recovered

    # Item count is ignored off the insert phase for a historical reason
    # that no longer applies (insert used to mutate the real timeline, so
    # its own clip changed the count and every capture/discard
    # token-mismatched against it — the live "Timeline changed since the
    # caller's `info` snapshot" error). The scratch redesign means the real
    # timeline is never touched, so the count should now match on its own;
    # this stays lenient so a stray nudge in Resolve while the user styles
    # can't throw away a capture they already did the work for.
    verify_token(request, project, timeline, ignore_item_count=(phase != "insert"))

    if phase == "insert":
        return _capture_style_insert(resolve, project, timeline, request)
    elif phase == "capture":
        return _capture_style_capture(resolve, project, timeline, request)
    elif phase == "discard":
        return _capture_style_discard(resolve, project, timeline, request)
    else:
        raise BridgeFailure(
            "invalid-phase",
            f"Unknown phase: {phase!r}. Must be 'insert', 'capture', or 'discard'.",
        )


CAPTURE_STYLE_CLIP_NAME = "CaptionSuite-StyleCapture"
# Distinct from SCRATCH_TIMELINE_NAME (the executor's bake staging area) so
# a capture in flight and an animate run can never collide over one timeline.
CAPTURE_STYLE_TIMELINE_NAME = "CaptionSuite Style Scratch (auto)"


def _find_timeline_by_name(project, name):
    """Locate a timeline in the current project by exact name, or None."""
    try:
        count = int(project.GetTimelineCount() or 0)
    except (TypeError, ValueError):
        return None
    for index in range(1, count + 1):
        try:
            candidate = project.GetTimelineByIndex(index)
            if candidate is not None and candidate.GetName() == name:
                return candidate
        except Exception:
            continue
    return None


def _timeline_from_token(project, token_string):
    """Re-find the REAL target timeline named by a composite identity token.

    Capture Style's capture/discard phases run as separate bridge
    subprocesses, by which time Resolve's *current* timeline is the styling
    scratch — so the real timeline can't be recovered from
    `GetCurrentTimeline()` any more. The token already carries its identity
    (`_timeline_identity`: `project|uniqueId-or-name|start=…|fps=…|items=…`),
    so segment 1 is the durable handle across phases. Returns None when the
    token is malformed or names a timeline that no longer exists.
    """
    parts = str(token_string or "").split("|")
    if len(parts) < 2 or not parts[1]:
        return None
    identity = parts[1]
    try:
        count = int(project.GetTimelineCount() or 0)
    except (TypeError, ValueError):
        return None
    for index in range(1, count + 1):
        try:
            candidate = project.GetTimelineByIndex(index)
        except Exception:
            continue
        if candidate is None:
            continue
        for getter in ("GetUniqueId", "GetName"):
            try:
                if getattr(candidate, getter)() == identity:
                    return candidate
            except Exception:
                continue
    return None


def _delete_capture_style_scratch(project, media_pool, real_timeline=None):
    """Best-effort teardown of the styling scratch timeline.

    Switches back to `real_timeline` FIRST when given: Resolve will not
    delete the timeline it is currently sitting on, and leaving the user
    parked on a half-deleted scratch is worse than leaving the scratch.
    Never raises — callers use this both for normal cleanup and for
    speculative sweeps where there may be nothing to remove.
    """
    scratch = _find_timeline_by_name(project, CAPTURE_STYLE_TIMELINE_NAME)
    if scratch is None:
        return
    if real_timeline is not None:
        try:
            project.SetCurrentTimeline(real_timeline)
        except Exception:
            pass
    for attempt in (
        lambda: media_pool.DeleteTimelines([scratch]),
        lambda: project.DeleteTimeline(scratch),
    ):
        try:
            if attempt():
                return
        except (AttributeError, TypeError):
            continue
        except Exception:
            return
    sys.stderr.write(
        "warning: this Resolve build exposes no timeline-deletion API — "
        f"the styling timeline {CAPTURE_STYLE_TIMELINE_NAME!r} must be "
        "removed by hand\n")


def _find_capture_style_clip(timeline):
    """Re-locates the transient style-capture clip a prior `insert` call
    placed — always on track 1 (F2: InsertFusionTitleIntoTimeline always
    appends to V1's end, ignoring every other track), matched STRICTLY by
    the marker name `insert` set. Returns None when nothing matches —
    nothing to discard, `capture`/`discard` called without a matching
    `insert`, or the marker failed to take.

    Live incident (2026-08-26): this used to fall back to "the last item on
    track 1" whenever the marker match failed, on the theory that F2
    guarantees the newly inserted clip lands at track 1's end regardless.
    That fallback deleted a real editor clip off the user's V1 — the marker
    rename is a TimelineItem.SetName() call, and we'd already separately
    confirmed this exact Resolve session has intermittent Fusion
    remote-object flakiness (GetToolIndex/GetHash/GetName all observed
    failing with `TypeError: 'NoneType' object is not callable`); nothing
    rules out SetName sharing it, and "last item in whatever order
    GetItemListInTrack returns" is not a documented, trustworthy proxy for
    "the item we just inserted" when it's wrong. `_capture_style_insert`
    now verifies the marker took (with retries) and fails loud instead of
    proceeding unmarked, so a guess should never be needed again — but the
    guess itself is removed too, since failing loud here (nothing to act
    on) is categorically safer than a heuristic that can delete the wrong
    clip.
    """
    if int(timeline.GetTrackCount("video") or 0) < 1:
        return None
    items = list(timeline.GetItemListInTrack("video", 1) or [])
    for item in items:
        try:
            if item.GetName() == CAPTURE_STYLE_CLIP_NAME:
                return item
        except Exception:
            continue
    return None


def _delete_capture_style_clip(timeline):
    """Best-effort removal of the transient style-capture clip, if any —
    never raises, since callers use this both for normal cleanup (where a
    failure should still be reported through their own path) and for
    speculative sweeps (where there may be nothing to remove at all)."""
    clip = _find_capture_style_clip(timeline)
    if clip is None:
        return
    try:
        timeline.DeleteClips([clip], False)
    except Exception:
        pass


def _capture_style_insert(resolve, project, timeline, request):
    """Phase 1: build a throwaway scratch timeline, insert a Text+ on it,
    and leave Resolve sitting on that timeline so the user can style it.

    Why a scratch timeline (redesign 2026-08-27, replacing insert-on-the-
    user's-own-timeline): `InsertFusionTitleIntoTimeline` gives no control
    over position (F2) or duration (F1) and, worse, live-verified as a real
    ripple-insert (F2a) that shoves the user's clips later in time — a
    shift `DeleteClips(..., ripple=False)` does NOT undo. Three successive
    attempts to tame that on the real timeline (park the playhead, then
    verify the park) each still produced a real user incident: a 45 s Text+
    at the head of the edit and every clip pushed 45 s late. Every one of
    those failure modes is *structural* to inserting into a timeline that
    has content in it.

    On an empty scratch timeline none of it can happen: nothing exists to
    ripple, so position and duration stop mattering (the default 120 f
    lands at the scratch's own start), the user's timeline is never
    mutated at all — which also means its item count never moves, so
    Capture Style can no longer trigger the Animate "timeline drift"
    check — and cleanup is deleting one whole throwaway timeline rather
    than identifying one clip among the user's real ones (the mechanism
    that, when its marker silently failed, deleted a real V1 clip).

    Crucially this does NOT hit F3: F3 applies to *baked* Fusion clips
    (`CreateFusionClip`), whose comps become permanently unreachable. A
    RAW inserted Text+ keeps its comp fully reachable wherever it lives —
    which is exactly what `_author_clip_on_track` already relies on when
    it authors on the executor's scratch timeline. Live-verified here:
    scratch insert → comp reachable → `SaveSettings()` returns the styled
    payload → real timeline byte-for-byte unchanged.
    """
    media_pool = project.GetMediaPool()
    if media_pool is None:
        raise BridgeFailure(
            "no-media-pool", "Resolve's media pool is not reachable.")

    # Sweep a scratch left over from a crashed/force-quit prior capture, so
    # a second one can never accumulate beside it.
    _delete_capture_style_scratch(project, media_pool, timeline)

    creator = getattr(media_pool, "CreateEmptyTimeline", None)
    if not callable(creator):
        raise BridgeFailure(
            "scratch-timeline-unsupported",
            "This Resolve build exposes no CreateEmptyTimeline API, which "
            "Capture Style needs to stage the Text+ safely.",
        )
    scratch = creator(CAPTURE_STYLE_TIMELINE_NAME)
    if not scratch:
        raise BridgeFailure(
            "scratch-timeline-failed",
            "Couldn't create the temporary styling timeline (fail-quiet "
            "API returned None).",
        )
    # Style against the REAL edit's shape: without this the styling timeline
    # sits at the project default (e.g. 16:9) while the user's timeline is
    # 9:16, so text sized/placed to look right here would be wrong once
    # animated. Same SetSetting-on-an-empty-timeline route the executor's
    # scratch uses — see `_create_scratch_timeline`.
    target_resolution = _timeline_resolution(timeline)
    if target_resolution and all(target_resolution):
        for key, value in (("useCustomSettings", "1"),
                           ("timelineResolutionWidth", str(int(target_resolution[0]))),
                           ("timelineResolutionHeight", str(int(target_resolution[1])))):
            try:
                scratch.SetSetting(key, value)
            except Exception:
                pass

    try:
        # CreateEmptyTimeline makes the new timeline current on its own
        # (live-verified) — which is what puts the Text+ in front of the
        # user for styling. Make that explicit rather than load-bearing
        # on a side effect.
        if project.GetCurrentTimeline().GetName() != CAPTURE_STYLE_TIMELINE_NAME:
            project.SetCurrentTimeline(scratch)

        title_item = scratch.InsertFusionTitleIntoTimeline("Text+")
        if not title_item:
            raise BridgeFailure(
                "title-insert-failed",
                "Couldn't insert a Text+ title onto the styling timeline "
                "(fail-quiet API returned None).",
            )

        # Best-effort now, not a safety mechanism: the scratch timeline
        # holds nothing else, so capture falls back to "the only clip on
        # V1" safely. Contrast the old design, where a failed marker meant
        # guessing among the user's REAL clips (and once deleted one).
        try:
            title_item.SetName(CAPTURE_STYLE_CLIP_NAME)
        except Exception:
            pass

        comp = title_item.GetFusionCompByIndex(1)
        if not comp:
            raise BridgeFailure(
                "no-comp",
                "The inserted title's Fusion comp is not reachable.",
            )
        # Required here, not defensive: the scratch timeline inherits the
        # PROJECT default resolution, which is exactly the 16:9-vs-9:16
        # mismatch users hit. Match the REAL timeline so they style against
        # their true aspect ratio.
        _apply_comp_frame_format(comp, _timeline_resolution(timeline))
        textplus = _find_or_create_textplus(comp)
    except Exception:
        # Never strand the user on a scratch timeline after a failed insert.
        _delete_capture_style_scratch(project, media_pool, timeline)
        raise

    # Live-verified (2026-08-26): several read-only introspection calls on
    # Fusion's remote comp/tool proxy objects (Comp.GetToolIndex(),
    # Tool.GetHash(), Comp.GetName() — confirmed one at a time, each only
    # after guarding the last) can raise `TypeError: 'NoneType' object is
    # not callable` — an intermittent Fusion remote-object binding flake,
    # unrelated to SaveSettings()/GetToolList()/AddTool(), which all work
    # fine on the same objects. This was the exact "internal-error" the app
    # surfaced, and because it fired AFTER the real
    # InsertFusionTitleIntoTimeline call already landed a clip on the
    # timeline, that clip was orphaned (never reached the pendingTool
    # state, so Cancel's cleanup never applied to it either). Every field
    # below besides status/phase/message is diagnostic-only — the app
    # doesn't read toolIndex/toolId/compName for anything functional
    # (`_locate_capture_style_tool` re-finds the tool structurally, not by
    # these) — so none of them are worth risking the whole insert over.
    try:
        tool_index = comp.GetToolIndex(textplus)
    except Exception:
        tool_index = 1
    try:
        tool_id = str(textplus.GetHash())
    except Exception:
        tool_id = CAPTURE_STYLE_CLIP_NAME
    try:
        comp_name = comp.GetName()
    except Exception:
        comp_name = CAPTURE_STYLE_CLIP_NAME

    return {
        "status": "ready",
        "phase": "insert",
        "toolIndex": tool_index,
        "toolId": tool_id,
        "compName": comp_name,
        "message": "Resolve is now on a temporary styling timeline holding "
                   "one Text+. Style it in Resolve's Inspector, then click "
                   "Done — the whole temporary timeline is deleted and you "
                   "land back on your own edit, untouched.",
    }


def _locate_capture_style_tool(timeline):
    """Shared by capture/discard: re-finds the transient clip and its
    TextPlus tool.

    Does NOT match by the toolId/toolIndex the app is still sent from
    insert (kept for diagnostics only) — live-verified (2026-08-26) that
    Comp.GetToolIndex()/Tool.GetHash() can raise `TypeError: 'NoneType'
    object is not callable`, an intermittent Fusion remote-object binding
    flake, so depending on either to re-find the tool risked the exact
    crash this exists to avoid. Unlike the main multi-tool caption comps
    (Phase 0 A5: Fusion may rename auxiliary tools, so THOSE must match by
    role/position), this comp is single-purpose and holds exactly the one
    TextPlus `_capture_style_insert` created — `_find_or_create_textplus`
    re-finds it deterministically by ID, no stored reference needed.
    """
    clip_item = _find_capture_style_clip(timeline)
    if clip_item is None:
        # `timeline` here is always the styling SCRATCH, which holds exactly
        # one clip and nothing of the user's — so falling back to "the only
        # item on V1" is safe, and covers a silently-failed SetName marker
        # (a live-confirmed flake class). This is emphatically NOT the
        # positional guess removed from `_find_capture_style_clip`: that one
        # ran against the user's real timeline, where guessing wrong deleted
        # real footage.
        items = list(timeline.GetItemListInTrack("video", 1) or [])
        if len(items) == 1:
            clip_item = items[0]
    if clip_item is None:
        raise BridgeFailure(
            "capture-clip-missing",
            "Couldn't find the Text+ clip inserted for styling — was it "
            "deleted or moved before clicking Done?",
        )
    comp = clip_item.GetFusionCompByIndex(1)
    if not comp:
        raise BridgeFailure(
            "no-comp",
            "The style-capture clip's Fusion comp is not reachable.",
        )
    return clip_item, comp


# Text+ shading elements, by their fixed 1-based index in the Shading tab.
# Only element 1's inputs are enumerated by GetInputList(); 2/3/4 expose just
# Enabled/Name until selected, but ALL of them read and write by ID directly
# (live-verified 2026-08-27), which is what these helpers rely on.
_SHADING_FILL = 1
_SHADING_OUTLINE = 2
_SHADING_BACKGROUND = 3
_SHADING_SHADOW = 4


def _read_input(tool, name):
    """GetInput that never raises and never invents a value."""
    try:
        return tool.GetInput(name)
    except Exception:
        return None


def _read_number(tool, name):
    value = _read_input(tool, name)
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _read_rgb_hex(tool, element):
    """The element's colour as #RRGGBB, or None when unreadable.

    Fusion stores each channel 0..1; a channel that reads back None is
    treated as 0.0 rather than failing the whole colour, because an
    untouched channel legitimately reports None on this build.
    """
    channels = []
    for prefix in ("Red", "Green", "Blue"):
        value = _read_number(tool, f"{prefix}{element}")
        channels.append(0.0 if value is None else value)
    if all(c == 0.0 for c in channels) and _read_input(tool, f"Red{element}") is None \
            and _read_input(tool, f"Green{element}") is None:
        return None  # nothing readable at all — don't report a bogus black
    return "#" + "".join(
        f"{max(0, min(255, int(round(c * 255)))):02X}" for c in channels)


def _read_shading_element(tool, element):
    """One shading element (outline / background / shadow) as a dict, or
    None when the element is switched off. `Enabled{N}` is authoritative:
    colour and thickness keep stale values after a user disables one."""
    enabled = _read_number(tool, f"Enabled{element}")
    if not enabled:
        return None
    detail = {"color": _read_rgb_hex(tool, element)}
    for key, input_name in (
        ("thickness", f"Thickness{element}"),
        ("opacity", f"Opacity{element}"),
        ("softness", f"Softness{element}"),
    ):
        value = _read_number(tool, input_name)
        if value is not None:
            detail[key] = round(value, 6)
    return detail


# Text+ exposes no font-case control (live-verified: none of its 309 inputs
# matches case/caps), so casing is NOT part of a captured style — it lives in
# the text itself. Recorded here as a known gap rather than silently omitted.
def _capture_style_details(tool):
    """Structured, human-readable summary of a styled Text+.

    Read field-by-field via GetInput rather than parsed out of the
    SaveSettings payload: that payload only carries inputs the user actually
    touched, so a style would report "no outline" identically whether the
    outline was off or simply left at its default. These reads report the
    tool's real current state.
    """
    details = {
        "font": _read_input(tool, "Font"),
        "fontFace": _read_input(tool, "Style"),
        "size": _read_number(tool, "Size"),
        "color": _read_rgb_hex(tool, _SHADING_FILL),
        "opacity": _read_number(tool, f"Opacity{_SHADING_FILL}"),
        "tracking": _read_number(tool, "CharacterSpacing"),
        "wordSpacing": _read_number(tool, "WordSpacing"),
        "lineSpacing": _read_number(tool, "LineSpacing"),
        "alignmentHorizontal": _read_number(tool, "HorizontalJustificationNew"),
        "alignmentVertical": _read_number(tool, "VerticalJustificationNew"),
        "stroke": _read_shading_element(tool, _SHADING_OUTLINE),
        "background": _read_shading_element(tool, _SHADING_BACKGROUND),
        "dropShadow": _read_shading_element(tool, _SHADING_SHADOW),
        "frameWidth": _read_number(tool, "Width"),
        "frameHeight": _read_number(tool, "Height"),
        "layoutWidth": _read_number(tool, "LayoutWidth"),
        "layoutHeight": _read_number(tool, "LayoutHeight"),
        "layoutSize": _read_number(tool, "LayoutSize"),
        # No Text+ input controls letter case — see the note above.
        "fontCaseSupported": False,
    }
    return {k: v for k, v in details.items() if v is not None}


def _capture_style_capture(resolve, project, timeline, request):
    """Phase 2: Read SaveSettings() off the styled TextPlus, then tear the
    whole styling timeline down and put the user back on their own edit.

    `timeline` is the REAL target timeline (resolved from the request token
    by the dispatcher — by this phase Resolve's *current* timeline is the
    scratch), and is what we return the user to.
    """
    media_pool = project.GetMediaPool()
    scratch = _find_timeline_by_name(project, CAPTURE_STYLE_TIMELINE_NAME)
    if scratch is None:
        raise BridgeFailure(
            "capture-clip-missing",
            "Couldn't find the temporary styling timeline — was it deleted "
            "before clicking Done? Nothing was captured; try again.",
        )

    # Teardown must survive a failed read (L4): leaving the scratch timeline
    # behind would strand the user on it and stack another on the next
    # capture.
    try:
        clip_item, comp = _locate_capture_style_tool(scratch)
        textplus = _find_or_create_textplus(comp)
        settings_dict = _convert_ordered_dict(textplus.SaveSettings())
        style_details = _capture_style_details(textplus)
    finally:
        _delete_capture_style_scratch(project, media_pool, timeline)

    return {
        "status": "captured",
        "phase": "capture",
        "styleSettings": settings_dict,
        "styleDetails": style_details,
        "message": "Style captured. The temporary styling timeline is gone "
                   "and you're back on your own edit.",
    }


def _capture_style_discard(resolve, project, timeline, request):
    """Phase 3: Cancel in the app — tear the styling timeline down without
    reading it. A missing scratch (already cleaned up, or nothing was ever
    inserted this session) is not an error; discard is idempotent."""
    _delete_capture_style_scratch(project, project.GetMediaPool(), timeline)
    return {
        "status": "discarded",
        "phase": "discard",
        "message": "Style capture cancelled; the temporary styling timeline "
                   "was removed and your own edit is untouched.",
    }


# --------------------------------------------------------------------------
# extract-word-timing
# --------------------------------------------------------------------------

class _Heartbeat:
    """Emit heartbeat lines from a background thread while the main thread
    sits inside a long blocking Resolve call (CreateSubtitlesFromAudio gives
    no progress and can run minutes at production scale)."""

    def __init__(self, interval=2.0):
        self.interval = interval
        self._stop = threading.Event()
        self._thread = None

    def _run(self):
        while not self._stop.wait(self.interval):
            try:
                emit_heartbeat()
            except Exception:
                pass  # never let liveness reporting kill the real work

    def __enter__(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, exc_type, exc, tb):
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=self.interval * 2)
        return False


def _auto_caption_settings(resolve, chars_per_line=1):
    """Build CreateSubtitlesFromAudio's settings dict from named constants
    only — keys AND values (A1 landmine: a raw-int value fails silently,
    `False` with no error text, so we refuse to guess any constant).

    `chars_per_line` defaults to 1 — the word-timing-extraction shape
    (`extract-word-timing`'s scratch track wants maximum granularity, not
    readable captions). `generate-subtitles` passes a real line length
    instead: this dict is Resolve's OWN auto-caption feature, not
    CueBuilder's pause-aware segmentation, so it should look like Resolve's
    normal auto-captions (character-filled lines) — the point of the button
    is only to get *something* onto a subtitle track for Check/Forge to then
    improve, not to approximate the app's own segmentation here.
    """
    def const(name):
        value = getattr(resolve, name, None)
        if value is None:
            raise BridgeFailure(
                "resolve-constants-missing",
                f"This Resolve build exposes no scripting constant {name!r} — "
                "its auto-caption API surface differs from every probed "
                "version. Refusing to guess values because a wrong settings "
                "dict fails silently.",
            )
        return value

    return {
        const("SUBTITLE_LANGUAGE"): const("AUTO_CAPTION_AUTO"),
        const("SUBTITLE_CAPTION_PRESET"): const("AUTO_CAPTION_SUBTITLE_DEFAULT"),
        # Plain int values here were validated live on 21.0.4.5 (probe C8);
        # only the three above have named-constant value domains.
        const("SUBTITLE_CHARS_PER_LINE"): chars_per_line,
        # Live-confirmed constant domain (Resolve 21.0.4.5): SINGLE=1.0,
        # DOUBLE=2.0. Enum-valued keys must use Resolve's named constants,
        # never guessed ints, or the API fail-quiets with False.
        const("SUBTITLE_LINE_BREAK"): const("AUTO_CAPTION_LINE_SINGLE"),
        const("SUBTITLE_GAP"): 0,
    }


# Resolve's own auto-caption default is 42 chars/line; CueBuilder's proven
# character ceiling (Step 2.5) happens to match, so a fresh Resolve-generated
# track already looks familiar rather than arbitrary.
GENERATED_SUBTITLE_CHARS_PER_LINE = 42


def _caption_lines(text):
    if text is None:
        return []
    return [line.strip() for line in str(text).splitlines() if line.strip()]


def _infer_subtitle_layout(cues):
    longest = 0
    maximum_line_count = 0
    for cue in cues:
        lines = _caption_lines(cue.get("text"))
        if not lines:
            continue
        maximum_line_count = max(maximum_line_count, len(lines))
        longest = max(longest, max(len(line) for line in lines))

    if longest <= 0 or maximum_line_count <= 0:
        return None
    if maximum_line_count == 1:
        mode = "single"
    elif maximum_line_count == 2:
        mode = "double"
    else:
        return None
    return {
        "charactersPerLine": longest,
        "lineBreakMode": mode,
    }


def _populated_subtitle_tracks(timeline):
    count = int(timeline.GetTrackCount("subtitle") or 0)
    populated = []
    for idx in range(1, count + 1):
        items = timeline.GetItemListInTrack("subtitle", idx) or []
        if len(items) > 0:
            populated.append(idx)
    return populated


def _split_chunk_proportionally(text, start_frame, end_frame):
    """Character-length-weighted split of one multi-word chunk across its
    frame span (port of word_timing._distribute_words_proportionally; each
    word ends where the next begins, the last ends at the chunk end)."""
    words = text.split()
    if not words:
        return []
    if len(words) == 1:
        return [(text, start_frame, end_frame)]

    total_chars = sum(len(w) for w in words) + (len(words) - 1)
    span = end_frame - start_frame
    cursor = 0
    onsets = []
    for word in words:
        onsets.append(start_frame + round((cursor / total_chars) * span))
        cursor += len(word) + 1

    out = []
    for i, word in enumerate(words):
        onset = onsets[i]
        end = onsets[i + 1] if i + 1 < len(words) else end_frame
        out.append((word, onset, max(end, onset)))
    return out


def mode_extract_word_timing(request: JSONMapping) -> JSONMapping:
    """Word-level timing from Resolve's own audio transcription, via the
    scratch-track trick (port of word_timing.extract_word_items):

    add an empty subtitle track -> CreateSubtitlesFromAudio targets the
    empty track instead of overwriting real captions -> detect which track
    changed by per-track counts -> read items back -> delete the scratch
    track even on failure.

    Multi-word chunks (contractions etc., ~15% of output) are split
    proportionally by character length so callers get one entry per word.
    The overlap-join onto separately-authored caption lines stays Swift-side
    (ARCHITECTURE.md §4.1 ResolveTimingExtractor) — it needs reviewed line
    text this mode deliberately doesn't own.
    """
    resolve = load_resolve()
    check_version(resolve)
    project, timeline = open_project_timeline(resolve)
    verify_token(request, project, timeline)

    settings = _auto_caption_settings(resolve)

    populated = _populated_subtitle_tracks(timeline)
    if len(populated) >= 2:
        raise BridgeFailure(
            "subtitle-tracks-conflict",
            f"{len(populated)} subtitle tracks already hold items "
            f"({populated}) — CreateSubtitlesFromAudio can hang Resolve "
            "outright in that state (A1 landmine). Clear stale subtitle "
            "tracks first, then retry.",
        )

    before_count = int(timeline.GetTrackCount("subtitle") or 0)
    if not timeline.AddTrack("subtitle"):
        raise BridgeFailure(
            "scratch-track-add-failed",
            "Couldn't add a scratch subtitle track for timing extraction.",
        )
    scratch_index = int(timeline.GetTrackCount("subtitle") or 0)
    if scratch_index <= before_count:
        raise BridgeFailure(
            "scratch-track-add-failed",
            "Scratch subtitle track was not created (track count unchanged).",
        )

    try:
        fps_raw = timeline.GetSetting("timelineFrameRate")
        fps = float(fps_raw)
        start_base = int(timeline.GetStartFrame())

        snapshot_tracks = range(1, scratch_index + 1)
        before = {
            i: len(timeline.GetItemListInTrack("subtitle", i) or [])
            for i in snapshot_tracks
        }

        emit_progress("generating", 0.1)
        with _Heartbeat():
            ok = timeline.CreateSubtitlesFromAudio(settings)
        if not ok:
            raise BridgeFailure(
                "auto-caption-rejected",
                "CreateSubtitlesFromAudio returned False with no diagnostic "
                "(fail-quiet API). Causes seen live: no/short timeline audio, "
                "free-license build, bad settings dict (this bridge validates "
                "its dict), and — found live on 21.0.4.5 — plain timeline "
                "state: the same audio and dict succeed on a pristine "
                "timeline while a mutated one rejects instantly. If this "
                "timeline has been heavily edited, try duplicating its audio "
                "onto a fresh timeline.",
            )

        after = {
            i: len(timeline.GetItemListInTrack("subtitle", i) or [])
            for i in snapshot_tracks
        }
        changed = [i for i in before if after[i] != before[i]]
        if not changed:
            raise BridgeFailure(
                "extraction-empty",
                "CreateSubtitlesFromAudio reported success but changed no "
                "subtitle track.",
            )
        if len(changed) > 1:
            raise BridgeFailure(
                "extraction-ambiguous",
                f"Generation changed multiple subtitle tracks {changed} — "
                "cannot tell which holds the word-level output. Refusing to "
                "guess; nothing was modified outside the scratch track.",
            )

        emit_progress("reading-items", 0.9)
        items = timeline.GetItemListInTrack("subtitle", changed[0]) or []
        chunks = [
            (item.GetName() or "", int(item.GetStart()), int(item.GetEnd()))
            for item in items
        ]
    finally:
        try:
            timeline.DeleteTrack("subtitle", scratch_index)
        except Exception as exc:
            sys.stderr.write(
                f"warning: failed to delete scratch subtitle track "
                f"{scratch_index}: {exc}\n"
            )

    words = []
    multi_word_chunks = 0
    for text, chunk_start, chunk_end in sorted(chunks, key=lambda c: c[1]):
        if not text.strip():
            continue
        pieces = _split_chunk_proportionally(text, chunk_start, chunk_end)
        if len(pieces) > 1:
            multi_word_chunks += 1
        for word_text, onset, end in pieces:
            words.append({
                "text": word_text,
                "startFrame": onset,
                "endFrame": end,
                "startSeconds": round((onset - start_base) / fps, 6),
                "endSeconds": round((end - start_base) / fps, 6),
            })

    emit_progress("done", 1.0)
    return {
        "fps": fps,
        "timelineStartFrame": start_base,
        "words": words,
        "stats": {
            "rawChunkCount": len(chunks),
            "multiWordChunks": multi_word_chunks,
            "wordCount": len(words),
        },
    }


def mode_pull_subtitles(request: JSONMapping) -> JSONMapping:
    """Read-only: dump every subtitle cue on the current timeline.

    Returns cues per subtitle track with absolute frames plus timeline-relative
    seconds, the cue text from GetName(), and the identity token so a caller
    can safely chain a mutating mode right after. Optionally restricts to one
    track via {"trackIndex": N}.
    """
    resolve = load_resolve()
    check_version(resolve)
    project, timeline = open_project_timeline(resolve)

    token, fps, start_frame = _timeline_identity(project, timeline)

    track_count = int(timeline.GetTrackCount("subtitle") or 0)
    if track_count == 0:
        raise BridgeFailure(
            "no-subtitle-tracks",
            "The current timeline has no subtitle tracks to pull from. "
            "Import or generate captions first.",
        )

    requested = request.get("trackIndex")
    if requested is not None:
        try:
            requested = int(requested)
        except (TypeError, ValueError):
            raise BridgeFailure(
                "bad-track-index",
                f"trackIndex must be an integer, got {requested!r}.",
            ) from None
        if not 1 <= requested <= track_count:
            raise BridgeFailure(
                "track-index-out-of-range",
                f"trackIndex {requested} is outside 1…{track_count} "
                f"(timeline has {track_count} subtitle track(s)).",
            )
        track_indexes = [requested]
    else:
        track_indexes = _populated_subtitle_tracks(timeline)
        if not track_indexes:
            raise BridgeFailure(
                "no-populated-subtitle-tracks",
                "Subtitle tracks exist but all are empty — nothing to pull.",
            )

    emit_progress("pulling", tracks=len(track_indexes))

    tracks_out = []
    total_cues = 0
    for idx in track_indexes:
        items = sorted(
            timeline.GetItemListInTrack("subtitle", idx) or [],
            key=lambda it: it.GetStart(),
        )
        name = None
        try:
            name = timeline.GetTrackName("subtitle", idx)
        except (AttributeError, TypeError):
            pass  # older majors may not expose track names; index remains
        cues = []
        for position, item in enumerate(items):
            start = int(item.GetStart())
            end = int(item.GetEnd())
            cues.append(
                {
                    "position": position,
                    "text": item.GetName(),
                    "startFrame": start,
                    "endFrame": end,
                    "startSeconds": round((start - start_frame) / fps, 3),
                    "endSeconds": round((end - start_frame) / fps, 3),
                }
            )
        total_cues += len(cues)
        tracks_out.append({
            "trackIndex": idx,
            "trackName": name,
            "subtitleLayout": _infer_subtitle_layout(cues),
            "cues": cues,
        })

    return {
        "token": token,
        "fps": fps,
        "tracks": tracks_out,
        "cueCount": total_cues,
    }


def mode_generate_subtitles(request: JSONMapping) -> JSONMapping:
    """Runs Resolve's own auto-caption feature (`CreateSubtitlesFromAudio`)
    onto a real, kept subtitle track — the "Generate Captions in Resolve"
    button's backing mode, for a timeline that has none yet.

    Deliberately NOT the `extract-word-timing` scratch-and-delete shape:
    that mode wants maximum-granularity chunks it immediately discards after
    reading timing back. This mode wants normal-looking captions left in
    place, at Resolve's own default line length, so Check has something real
    to pull and refine — it is a bootstrap step, not a segmentation
    replacement.

    Refuses when ANY subtitle track already holds items — unlike
    `extract-word-timing`, there's no scratch track here tolerating one
    pre-existing real track; this mode's whole precondition is "nothing to
    pull yet," so even one populated track means the caller should be
    pulling, not generating (unlike `extract-word-timing`'s >=2 A1 hang-guard,
    which exists only to protect its *own* scratch track from that same
    landmine). Live-verified 2026-08-26: calling this against a timeline that
    already had one populated (pulled-from) track produced a bare
    `auto-caption-rejected` from Resolve's fail-quiet API instead of a clear
    reason — this guard turns that into an actionable refusal before ever
    calling Resolve. Returns the same shape as `pull-subtitles` (the fresh
    track's cues, ready to load straight into a session without a second
    bridge round trip).
    """
    resolve = load_resolve()
    check_version(resolve)
    project, timeline = open_project_timeline(resolve)
    verify_token(request, project, timeline)

    settings = _auto_caption_settings(resolve, chars_per_line=GENERATED_SUBTITLE_CHARS_PER_LINE)

    populated = _populated_subtitle_tracks(timeline)
    if populated:
        raise BridgeFailure(
            "subtitle-tracks-conflict",
            f"This timeline already has {len(populated)} subtitle track(s) "
            f"with content ({populated}) — pull those instead of generating "
            "a new one.",
        )

    before_count = int(timeline.GetTrackCount("subtitle") or 0)
    before = {
        i: len(timeline.GetItemListInTrack("subtitle", i) or [])
        for i in range(1, before_count + 1)
    }

    emit_progress("generating", 0.1)
    with _Heartbeat():
        ok = timeline.CreateSubtitlesFromAudio(settings)
    if not ok:
        raise BridgeFailure(
            "auto-caption-rejected",
            "CreateSubtitlesFromAudio returned False with no diagnostic "
            "(fail-quiet API). Causes seen live: no/short timeline audio, "
            "free-license build, or a bad settings dict (this bridge "
            "validates its own).",
        )

    after_count = int(timeline.GetTrackCount("subtitle") or 0)
    after = {
        i: len(timeline.GetItemListInTrack("subtitle", i) or [])
        for i in range(1, after_count + 1)
    }
    changed = [i for i in after if after[i] != before.get(i, 0)]
    if not changed:
        raise BridgeFailure(
            "generation-empty",
            "CreateSubtitlesFromAudio reported success but no subtitle "
            "track gained any items.",
        )
    if len(changed) > 1:
        raise BridgeFailure(
            "generation-ambiguous",
            f"Generation changed multiple subtitle tracks {changed} — "
            "cannot tell which is the new one. Nothing beyond Resolve's own "
            "auto-caption call was touched.",
        )

    track_index = changed[0]
    token, fps, start_frame = _timeline_identity(project, timeline)
    track_name = None
    try:
        track_name = timeline.GetTrackName("subtitle", track_index)
    except (AttributeError, TypeError):
        pass

    items = sorted(
        timeline.GetItemListInTrack("subtitle", track_index) or [],
        key=lambda it: it.GetStart(),
    )
    cues = []
    for position, item in enumerate(items):
        start = int(item.GetStart())
        end = int(item.GetEnd())
        cues.append({
            "position": position,
            "text": item.GetName(),
            "startFrame": start,
            "endFrame": end,
            "startSeconds": round((start - start_frame) / fps, 3),
            "endSeconds": round((end - start_frame) / fps, 3),
        })

    emit_progress("done", 1.0)
    return {
        "token": token,
        "fps": fps,
        "tracks": [{
            "trackIndex": track_index,
            "trackName": track_name,
            "subtitleLayout": _infer_subtitle_layout(cues) or {
                "charactersPerLine": GENERATED_SUBTITLE_CHARS_PER_LINE,
                "lineBreakMode": "single",
            },
            "cues": cues,
        }],
        "cueCount": len(cues),
    }


def mode_export_timeline_audio(request: JSONMapping) -> JSONMapping:
    """Renders the current timeline's own composed audio out to a WAV file,
    via Resolve's built-in "Audio Only" render preset — so Forge can attach
    it and run WhisperX/waveform analysis without the user hunting down and
    manually picking the right source file.

    Rendering (rather than reading a timeline item's linked source file
    directly) is deliberate: a real edit can have multiple audio clips,
    trims, and tracks, and only Resolve's own render pipeline is guaranteed
    to produce one file whose time 0 matches the timeline's time 0 — exactly
    the coordinate system `pull-subtitles`' cue times are already in. A
    direct file-path read would only be correct for the trivial
    single-untrimmed-clip case and silently wrong otherwise (live-verified:
    this project's own audio item's GetStart()/GetEnd() cover only the
    captioned ~36s region while the timeline itself runs ~527s — reading the
    raw source file directly would hand WhisperX 491s of extra, uncaptioned
    timeline space for no reason).

    {"startSeconds": 0.0, "endSeconds": 40.0} restricts the render to that
    timeline-relative window (translated to MarkIn/MarkOut frames) — callers
    that already know their existing cues' time range should pass it, so a
    short highlight clip on a long timeline doesn't waste minutes rendering
    (and then WhisperX-transcribing) empty space. Omitted = the whole
    timeline. `expectedToken` is required (this mutates render state and
    writes a file) and verified like `extract-word-timing`.
    """
    resolve = load_resolve()
    check_version(resolve)
    project, timeline = open_project_timeline(resolve)
    verify_token(request, project, timeline)

    target_dir = request.get("targetDirectory")
    if not target_dir:
        raise BridgeFailure("missing-target-directory", "`targetDirectory` is required.")
    try:
        os.makedirs(target_dir, exist_ok=True)
    except OSError as exc:
        raise BridgeFailure(
            "target-directory-unwritable",
            f"Couldn't create/use targetDirectory {target_dir!r}: {exc}",
        ) from exc

    token, fps, timeline_start_frame = _timeline_identity(project, timeline)
    timeline_end_frame = int(timeline.GetEndFrame())

    def _frame(seconds_key, default_frame):
        value = request.get(seconds_key)
        if value is None:
            return default_frame
        try:
            seconds = float(value)
        except (TypeError, ValueError):
            raise BridgeFailure(
                "bad-range", f"{seconds_key} must be a number, got {value!r}."
            ) from None
        return timeline_start_frame + round(seconds * fps)

    mark_in = _frame("startSeconds", timeline_start_frame)
    mark_out = _frame("endSeconds", timeline_end_frame)
    mark_in = max(mark_in, timeline_start_frame)
    mark_out = min(mark_out, timeline_end_frame)
    if mark_out <= mark_in:
        raise BridgeFailure(
            "empty-range",
            f"Requested range (frames {mark_in}..{mark_out}) is empty or "
            "inverted after clamping to the timeline's own bounds "
            f"({timeline_start_frame}..{timeline_end_frame}).",
        )

    # Capture the currently active render preset so we can restore it
    # afterward (Area 3 F6): this mode swaps the preset to "Audio Only" and
    # overwrites render settings, and leaving that active would surprise the
    # user's next render from the app. Best-effort — older builds may not
    # expose GetRenderPreset, in which case we simply skip the restore.
    prev_preset = None
    try:
        prev_preset = project.GetRenderPreset()
    except (AttributeError, TypeError):
        prev_preset = None

    try:
        if not project.LoadRenderPreset("Audio Only"):
            raise BridgeFailure(
                "audio-only-preset-missing",
                "Resolve's built-in \"Audio Only\" render preset couldn't be "
                "loaded — has it been renamed or removed? Rendering was refused "
                "rather than falling back to whatever preset was last active, "
                "which could render full video.",
            )

        custom_name = f"forge-audio-{token['timelineId'] or 'timeline'}-{int(time.time())}"
        custom_name = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in custom_name)
        if not project.SetRenderSettings({
            "TargetDir": target_dir,
            "CustomName": custom_name,
            "MarkIn": mark_in,
            "MarkOut": mark_out,
        }):
            raise BridgeFailure(
                "render-settings-rejected",
                "Resolve rejected the render settings (target directory/range).",
            )

        job_id = project.AddRenderJob()
        if not job_id:
            raise BridgeFailure("render-job-not-created", "AddRenderJob() returned no job id.")

        try:
            if not project.StartRendering([job_id], False):
                raise BridgeFailure("render-start-failed", "StartRendering() returned False.")

            last_heartbeat = time.time()
            while project.IsRenderingInProgress():
                status = project.GetRenderJobStatus(job_id) or {}
                pct = status.get("CompletionPercentage")
                emit_progress("rendering", pct=(pct / 100 if pct is not None else None))
                if time.time() - last_heartbeat >= 2.0:
                    emit_heartbeat()
                    last_heartbeat = time.time()
                time.sleep(0.4)

            final_status = project.GetRenderJobStatus(job_id) or {}
            if final_status.get("JobStatus") != "Complete":
                raise BridgeFailure(
                    "render-failed",
                    f"Render job finished as {final_status.get('JobStatus')!r}, not Complete.",
                    extra={"status": final_status},
                )
        finally:
            try:
                project.DeleteRenderJob(job_id)
            except Exception as exc:
                sys.stderr.write(f"warning: failed to delete render job {job_id}: {exc}\n")

        output_path = os.path.join(target_dir, f"{custom_name}.wav")
        if not os.path.isfile(output_path):
            raise BridgeFailure(
                "render-output-missing",
                f"Render reported Complete but no file was found at {output_path!r}.",
            )

        emit_progress("done", pct=1.0)
        return {
            "token": token,
            "audioFilePath": output_path,
            "fps": fps,
            "startSeconds": round((mark_in - timeline_start_frame) / fps, 6),
            "endSeconds": round((mark_out - timeline_start_frame) / fps, 6),
        }
    finally:
        # Restore the previously active render preset (Area 3 F6). This mode
        # swaps to "Audio Only" and overwrites render settings; leaving that
        # active would surprise the user's next render. Best-effort only.
        if prev_preset:
            try:
                project.LoadRenderPreset(prev_preset)
            except Exception as exc:
                sys.stderr.write(
                    f"warning: couldn't restore prior render preset "
                    f"{prev_preset!r}: {exc}\n")

MODES = {
    "info": mode_info,
    "pull-subtitles": mode_pull_subtitles,
    "generate-subtitles": mode_generate_subtitles,
    "extract-word-timing": mode_extract_word_timing,
    "capture-style": capture_style,
    "author-textplus": author_textplus,
    "author-persistent-title": mode_author_persistent_title,
    "export-timeline-audio": mode_export_timeline_audio,
}


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

def read_request() -> JSONMapping:
    """Read the single JSON request object from stdin, if one is piped in."""
    if sys.stdin.isatty():
        return {}
    try:
        fd = sys.stdin.buffer.fileno()
        if not isinstance(fd, int):
            raise TypeError("stdin fileno() did not return an integer")
    except (AttributeError, OSError, TypeError, ValueError):
        # Test/caller-provided file-like objects do not necessarily expose a
        # selectable descriptor; retain the normal whole-input behavior for
        # those objects.
        raw = sys.stdin.buffer.read()
        if not raw.strip():
            return {}
        try:
            request = json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise BridgeFailure(
                "request-unparseable",
                f"stdin isn't valid JSON: {exc}",
            ) from exc
        if not isinstance(request, dict):
            raise BridgeFailure(
                "request-not-object",
                "The stdin request must be a JSON object.",
            )
        return request
    raw = bytearray()

    while True:
        # Poll rather than blocking in read(): Python retries an interrupted
        # select() when a signal handler returns normally, so the bounded
        # timeout is what lets the deferred SIGTERM flag be observed.
        ready, _, _ = select.select([fd], [], [], 0.1)
        if _shutdown_requested:
            raise BridgeFailure("shutdown-requested", "Shutdown requested before dispatch.")
        if not ready:
            continue

        chunk = os.read(fd, 4096)
        if not chunk:
            break
        raw.extend(chunk)

    if not raw.strip():
        return {}
    try:
        request = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise BridgeFailure(
            "request-unparseable",
            f"stdin isn't valid JSON: {exc}",
        ) from exc

    if not isinstance(request, dict):
        raise BridgeFailure(
            "request-not-object",
            "The stdin request must be a JSON object.",
        )
    return request


def main(argv: List[str]) -> int:
    global _operation_id
    _operation_id = None
    _install_signal_handlers()

    if len(argv) < 2 or not argv[1]:
        emit_error(None, "usage", "usage: resolve_bridge.py <mode> [json-on-stdin]")
        return 2

    mode = argv[1]
    handler = MODES.get(mode)
    if handler is None:
        known = ", ".join(sorted(MODES))
        emit_error(mode, "unknown-mode", f"Unknown mode {mode!r}. Known modes: {known}")
        return 2

    try:
        request = read_request()
    except BridgeFailure as exc:
        emit_error(mode, exc.code, exc.message)
        return 3

    operation_id = request.get("operationId")
    _operation_id = operation_id if isinstance(operation_id, str) and operation_id else None

    try:
        if _shutdown_requested:
            raise BridgeFailure("shutdown-requested", "Shutdown requested before dispatch.")
        emit_result(mode, handler(request))
        return 0
    except BridgeFailure as exc:
        emit_error(mode, exc.code, exc.message, extra=exc.extra)
        return 3
    except Exception as exc:  # noqa: BLE001 — last-ditch structured report
        emit_error(mode, "internal-error", f"{type(exc).__name__}: {exc}")
        return 4
    finally:
        # Tests and library callers may invoke handlers directly in this interpreter; an
        # operation id belongs only to this one dispatched request.
        _operation_id = None


if __name__ == "__main__":
    sys.exit(main(sys.argv))
