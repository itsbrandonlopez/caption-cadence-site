"""Semantic Resolve fake tests and bridge integration contracts."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "Resolve"))

import fakeresolve
import resolve_bridge


class TestFusionSemantics(unittest.TestCase):
    def test_bridge_uses_attribute_assignment_for_modifiers(self):
        comp = fakeresolve.FakeComp()
        textplus = comp.AddTool("TextPlus")

        spline = resolve_bridge._attach_stepped_spline(
            comp,
            textplus,
            "End",
            [{"frame": 0, "value": 0.0}],
            clip_length_frames=10,
        )

        self.assertIs(textplus.End, spline)
        self.assertEqual(spline.keyframes[0.0][1], 0.0)
        self.assertEqual(spline.keyframes[9.0][1], 1.0)

    def test_setinput_modifier_attachment_is_a_fail_quiet_noop(self):
        comp = fakeresolve.FakeComp()
        textplus = comp.AddTool("TextPlus")
        spline = comp.BezierSpline({})

        self.assertFalse(textplus.SetInput("End", spline))
        self.assertIsNone(textplus.End)

    def test_addtool_spline_is_not_a_modifier(self):
        comp = fakeresolve.FakeComp()
        registered = comp.AddTool("BezierSpline")

        self.assertIsInstance(registered, fakeresolve.FakeRegisteredSpline)
        self.assertFalse(registered.SetInput("StepIn", True))


class TestTimelineSemantics(unittest.TestCase):
    def test_delete_clips_requires_the_probed_list_shape(self):
        timeline = fakeresolve.FakeTimeline()
        item = object()
        timeline.items.append(item)

        self.assertTrue(timeline.DeleteClips([item]))
        self.assertEqual(timeline.items, [])

        with self.assertRaises(fakeresolve.FakeResolveError):
            timeline.DeleteClips(item)

    def test_append_to_timeline_returns_the_inserted_items(self):
        timeline = fakeresolve.FakeTimeline()
        items = [object(), object()]

        self.assertEqual(timeline.AppendToTimeline(items), items)
        self.assertEqual(timeline.items, items)


if __name__ == "__main__":
    unittest.main()
