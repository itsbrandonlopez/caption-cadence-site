#!/usr/bin/env python3
"""whisperx_helper.py — WhisperX provisioning + forced-alignment transcription
for Resolve Caption Suite (Step 2.2).

Same wire protocol as resolve_bridge.py: one invocation = one JSON request on
stdin = NDJSON responses on stdout = meaningful exit code. Every stdout line
is a single JSON object printed with an explicit flush (the D12 finding:
unflushed print() on a pipe batches into one burst at exit, which breaks both
progress UX and the Swift-side heartbeat watchdog).

    {"event": "progress",  "step": "...", "pct": 0.42}
    {"event": "heartbeat", "t": 1771900000.123}
    {"event": "result", "ok": true,  "mode": "...", "data": {...}}
    {"event": "result", "ok": false, "mode": "...",
     "error": {"code": "...", "message": "..."}}

stderr carries human-readable diagnostics only; it is never protocol.

Modes (argv[1]):

  setup     Run by the BASE python3 (the venv does not exist yet — the app
            cannot spawn a python it has not built). Creates an isolated venv
            at --target and pip-installs the pinned whisperx stack into it.
            Request JSON on stdin is currently unused except for forward
            compatibility.

  transcribe Run by the VENV's own python (imports whisperx/torch). One audio
            file in, word-level timings out. Mirrors the Phase-0-validated
            CLI invocation (`--model small --device cpu --output_format json`,
            wav2vec2 forced alignment) but drives the library API directly
            instead of shelling out to the `whisperx` console script: the CLI
            has no progress channel at all, and this mode's entire purpose is
            streaming progress + structured errors back over NDJSON.

  verify    Run by the VENV's own python. Fast (no model load): confirms
            whisperx/torch/torchcodec actually import (not just that the venv directory
            exists — the Swift-side `isWhisperXInstalled` check before this
            was file-presence only, which passes even for a partially-broken
            or stale venv), reports versions, checks ffmpeg is on PATH (the
            audio-decode dependency neither pip install nor the import check
            exercises), and reports whether the requested model's weights are
            already cached — all in well under a second, so Settings/onboarding
            can show real status instead of "installed" meaning only "a file
            exists here."

  repair_ffmpeg
            Run only after explicit user action. Reuses an already-installed
            compatible Homebrew FFmpeg keg, or installs the keg-only ffmpeg@7
            formula when Homebrew is available. It never runs as a side effect
            of ordinary setup or verification.

Exit codes mirror resolve_bridge.py:
    0   success   2 usage error   3 structured failure   4 internal error

Bundling decision encoded here (Step 2.2 design): WhisperX ships as a
FIRST-RUN MANAGED ENVIRONMENT (option b), not a bundled framework and not a
system-python dependency. The app owns one isolated venv under
~/Library/Application Support/Resolve Caption Suite/WhisperX/venv; `setup`
builds it from whatever base python3 macOS provides, pinned versions keep the
stack reproducible, and uninstalling the app means deleting that one folder.
Rationale lives in the WhisperXRunner.swift header.
"""

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time

# ONNX Runtime's macOS telemetry worker has a shutdown race in the third-party
# wheel used by WhisperX. Its teardown can abort the Python child after the
# transcription work completes (SIGABRT, reported by the app as exit status 6).
# Keep the helper safe when invoked directly; the app also sets this variable.
# An explicit caller override is preserved for diagnostics.
os.environ.setdefault("ORT_DISABLE_TELEMETRY", "1")

# Pinned Phase-0 stack: exactly what VERIFICATION-RESULTS.md C8/C9 validated
# (forced-aligned word timestamps whose boundary landed within 3ms of a
# hand-measured real pause). Upgrades are a deliberate re-validation, not a
# routine pip bump.
WHISPERX_PIN = "whisperx==3.8.6"

# whisperx/torch wheels do not exist for every CPython minor; stay inside the
# range the stack is known to build on.
MIN_PYTHON = (3, 11)
MAX_PYTHON_EXCLUSIVE = (3, 15)

# The app owns exactly one managed venv under this directory (Step 2.2 design).
# A venv_path supplied on the request must live INSIDE it — refusing anything
# else prevents the helper from creating/using Python environments elsewhere
# on the filesystem (Area 11 F3).
SUPPORT_DIR = os.path.expanduser(
    "~/Library/Application Support/Resolve Caption Suite/WhisperX")

# WhisperX 3.8.6 installs torch 2.8 + torchcodec 0.7. TorchCodec needs the
# FFmpeg shared libraries, and its macOS wheel searches for the versioned
# dylibs rather than the `ffmpeg` executable. Homebrew's unversioned formula
# can move ahead of that ABI, so the supported repair target is the keg-only
# ffmpeg@7 formula (with older compatible kegs accepted when already present).
COMPATIBLE_FFMPEG_MAJORS = (7, 6, 5, 4)
FFMPEG_LIBRARY_DIRECTORIES = tuple(
    f"{prefix}/opt/ffmpeg@{major}/lib"
    for prefix in ("/opt/homebrew", "/usr/local")
    for major in COMPATIBLE_FFMPEG_MAJORS
)


def compatible_ffmpeg_library_directories():
    return [
        path for path in FFMPEG_LIBRARY_DIRECTORIES
        if os.path.isdir(path)
    ]


def ffmpeg_info():
    """Return a known Homebrew FFmpeg's version without PATH lookup.

    This helper is launched by an unsandboxed desktop app.  Executing the first
    ``ffmpeg`` found in a caller-provided PATH would turn a verification action
    into arbitrary code execution for a hostile launch environment.  The
    supported runtime already documents Homebrew locations, so inspect only
    those absolute paths.
    """
    path = next(
        (candidate for candidate in (
            "/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg"
        ) if os.path.isfile(candidate) and os.access(candidate, os.X_OK)),
        None,
    )
    if path is None:
        return None, None
    try:
        proc = subprocess.run(
            [path, "-version"], capture_output=True, text=True, timeout=10
        )
        match = re.search(r"ffmpeg version\s+([0-9]+(?:\.[0-9]+)*)", proc.stdout)
        return path, match.group(1) if match else None
    except (OSError, subprocess.TimeoutExpired):
        return path, None


def torchcodec_repair_hint(ffmpeg_path, ffmpeg_version, error):
    """Turn a noisy native-loader error into an actionable UI message."""
    if not ffmpeg_path:
        return (
            "FFmpeg is not installed. Install FFmpeg 7 with shared libraries, "
            "then run Verify Installation again."
        )
    if ffmpeg_version:
        try:
            major = int(ffmpeg_version.split(".", 1)[0])
        except ValueError:
            major = None
        if major is not None and major not in COMPATIBLE_FFMPEG_MAJORS:
            return (
                f"FFmpeg {ffmpeg_version} is installed, but this WhisperX "
                "runtime needs FFmpeg 4–7 shared libraries. Install "
                "ffmpeg@7, then choose Repair FFmpeg Runtime."
            )
    if not compatible_ffmpeg_library_directories():
        return (
            f"FFmpeg was found at {ffmpeg_path}, but compatible shared "
            "libraries were not found. Install ffmpeg@7, then choose "
            "Repair FFmpeg Runtime."
        )
    return (
        "TorchCodec could not load its FFmpeg backend. Choose Repair FFmpeg "
        "Runtime, then verify again."
    )


def find_brew():
    # As with FFmpeg, repair must not execute an arbitrary PATH entry.  These
    # are Homebrew's supported macOS installation locations.
    return next(
        (path for path in ("/opt/homebrew/bin/brew", "/usr/local/bin/brew")
         if os.path.isfile(path) and os.access(path, os.X_OK)),
        None,
    )


def _is_within(path, directory):
    """True when `path` is the same as, or nested beneath, `directory`."""
    try:
        common = os.path.commonpath(
            [os.path.abspath(path), os.path.abspath(directory)])
    except ValueError:
        return False
    return common == os.path.abspath(directory)


class BridgeFailure(Exception):
    """A structured, expected failure carrying a machine-readable code."""

    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
        self.message = message


# The protocol channel, captured before anything below can rebind sys.stdout.
_PROTOCOL_OUT = sys.stdout


def emit(obj):
    """Print one protocol line. Explicit flush is NON-NEGOTIABLE."""
    _PROTOCOL_OUT.write(json.dumps(obj, separators=(",", ":")) + "\n")
    _PROTOCOL_OUT.flush()


def emit_progress(step, pct=None, **extra):
    obj = {"event": "progress", "step": step}
    if pct is not None:
        obj["pct"] = round(pct, 4)
    obj.update(extra)
    emit(obj)


def emit_result(mode, data):
    emit({"event": "result", "ok": True, "mode": mode, "data": data})


def emit_error(mode, code, message):
    emit({
        "event": "result",
        "ok": False,
        "mode": mode,
        "error": {"code": code, "message": message},
    })


def read_request():
    raw = sys.stdin.read()
    if not raw.strip():
        return {}
    try:
        req = json.loads(raw)
    except ValueError as exc:
        raise BridgeFailure("bad_request", f"stdin is not valid JSON: {exc}")
    if not isinstance(req, dict):
        raise BridgeFailure("bad_request", "stdin request must be a JSON object")
    return req


def start_heartbeats(stop_event, interval=10.0):
    """Background liveness thread.

    Model load / transcription / alignment can run silent for minutes; without
    these beats the Swift-side heartbeat watchdog would kill a healthy child.
    """

    def beat():
        while not stop_event.wait(interval):
            emit({"event": "heartbeat", "t": time.time()})

    thread = threading.Thread(target=beat, daemon=True)
    thread.start()
    return stop_event


def run_pip(args, step_label, venv_python):
    """One pip stage with progress before/after and stderr surfaced verbatim."""
    emit_progress(step_label)
    proc = subprocess.run(
        # --isolated ignores user pip configuration and PIP_* environment
        # variables, preventing a local config/environment from silently
        # redirecting this app-managed dependency download to another index.
        [venv_python, "-m", "pip", "--isolated"] + args,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        tail = "\n".join(proc.stderr.splitlines()[-25:])
        raise BridgeFailure(
            "pip_failed",
            f"`pip {' '.join(args[:2])}` failed (exit {proc.returncode}):\n{tail}",
        )


def mode_setup(mode_name):
    req = read_request()
    target = req.get("venv_path") or _arg_value("--venv")
    if not target:
        raise BridgeFailure("missing_target", "setup requires a venv_path")
    # Reject any venv_path that does not live under the sanctioned support
    # directory (Area 11 F3) — the app must never create or operate a Python
    # environment outside its own managed WhisperX folder.
    if not _is_within(target, SUPPORT_DIR):
        raise BridgeFailure(
            "venv_path_unsafe",
            f"venv_path {target!r} is not inside the sanctioned support "
            f"directory {SUPPORT_DIR!r}. Refusing to manage a venv outside "
            "the app's WhisperX folder.",
        )

    version = sys.version_info[:2]
    if version < MIN_PYTHON or version >= MAX_PYTHON_EXCLUSIVE:
        raise BridgeFailure(
            "python_version_unsupported",
            "Base python is %d.%d; the pinned WhisperX stack needs >= 3.11 "
            "and < 3.%d." % (version + (MIN_PYTHON[0], MAX_PYTHON_EXCLUSIVE[1])),
        )

    import venv as venv_module

    emit_progress("creating_venv", pct=0.1)
    builder = venv_module.EnvBuilder(with_pip=True)
    builder.create(target)

    # From here on, EVERYTHING targets the venv's own interpreter — pip
    # included. sys.executable is still the BASE python that spawned this
    # helper; installing with it would populate the base environment and
    # leave the fresh venv empty (the Phase-2 audit finding).
    venv_python = f"{target}/bin/python"
    run_pip(["install", "--upgrade", "pip"], "upgrading_pip", venv_python)
    run_pip(["install", WHISPERX_PIN], "installing_whisperx", venv_python)

    emit_progress("verifying_import", pct=0.9)
    proc = subprocess.run(
        [venv_python, "-c", "import whisperx"],
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        raise BridgeFailure(
            "import_check_failed",
            f"whisperx did not import in the fresh venv:\n{proc.stderr[-2000:]}",
        )

    emit_result(
        mode_name,
        {"venv_python": venv_python, "pin": WHISPERX_PIN},
    )


def mode_repair_ffmpeg(mode_name):
    """Install the compatible Homebrew FFmpeg keg after explicit user action."""
    read_request()
    existing = compatible_ffmpeg_library_directories()
    if not existing:
        brew = find_brew()
        if not brew:
            raise BridgeFailure(
                "ffmpeg_repair_unavailable",
                "Homebrew was not found. Install FFmpeg 7 with shared libraries "
                "manually, then run Verify Installation again.",
            )

        emit_progress("installing_ffmpeg_runtime")
        stop = start_heartbeats(threading.Event(), interval=10.0)
        try:
            try:
                proc = subprocess.run(
                    [brew, "install", "ffmpeg@7"],
                    capture_output=True,
                    text=True,
                    timeout=900,
                )
            except subprocess.TimeoutExpired:
                raise BridgeFailure(
                    "ffmpeg_repair_timed_out",
                    "Installing ffmpeg@7 exceeded the 15-minute repair limit. "
                    "Check Homebrew, then run Verify Installation again.",
                )
            except OSError as exc:
                raise BridgeFailure(
                    "ffmpeg_repair_failed",
                    f"Could not run Homebrew: {exc}",
                )
            if proc.returncode != 0:
                tail = "\n".join(proc.stderr.splitlines()[-20:])
                raise BridgeFailure(
                    "ffmpeg_repair_failed",
                    f"Homebrew could not install ffmpeg@7 (exit {proc.returncode}).\n{tail}",
                )
        finally:
            stop.set()
        existing = compatible_ffmpeg_library_directories()

    if not existing:
        raise BridgeFailure(
            "ffmpeg_repair_incomplete",
            "Homebrew completed, but no compatible FFmpeg shared-library keg "
            "was found. Run Verify Installation again or install FFmpeg 7 "
            "manually.",
        )
    emit_result(mode_name, {"library_paths": existing})


def model_is_cached(model_name):
    """True when the HF weights for `model_name` are already local.

    Used to fail LOUD with `model_download_needed` when downloads are not
    permitted, rather than letting huggingface_hub silently start a multi-GB
    fetch mid-transcription.

    whisperx 3.x transcribes via the faster-whisper backend, whose weights
    live under Systran/faster-whisper-<name> (model.bin); the openai/whisper-*
    layout is probed too for older stacks.
    """
    try:
        from huggingface_hub import try_to_load_from_cache

        candidates = [
            ("Systran/faster-whisper-%s" % model_name, "model.bin"),
            ("openai/whisper-%s" % model_name, "model.safetensors"),
            ("openai/whisper-%s" % model_name, "pytorch_model.bin"),
        ]
        for repo_id, filename in candidates:
            hit = try_to_load_from_cache(repo_id=repo_id, filename=filename)
            if isinstance(hit, str):
                return True
        return False
    except Exception:
        # Cache probing is best-effort only; absence of the helper must never
        # block a run where downloading was explicitly allowed anyway.
        return False


def mode_transcribe(mode_name):
    req = read_request()
    audio_path = req.get("audio_path") or _arg_value("--audio")
    if not audio_path:
        raise BridgeFailure("missing_audio", "transcribe requires an audio_path")
    import os

    if not os.path.isfile(audio_path):
        raise BridgeFailure("audio_not_found", f"No such file: {audio_path}")

    model_name = req.get("model", "small")
    device = req.get("device", "cpu")
    compute_type = req.get("compute_type", "int8")
    language = req.get("language")  # None = let whisperx detect
    batch_size = int(req.get("batch_size", 8))
    allow_download = bool(req.get("allow_download", False))

    hf_id = f"Systran/faster-whisper-{model_name}"
    if not allow_download and not model_is_cached(model_name):
        raise BridgeFailure(
            "model_download_needed",
            f"Weights for {hf_id} are not cached locally and downloads are "
            "disabled for this run.",
        )

    stop = start_heartbeats(threading.Event())
    try:
        emit_progress("loading_whisperx")
        import whisperx

        emit_progress("downloading_model" if allow_download else "loading_model")
        asr_model = whisperx.load_model(model_name, device, compute_type=compute_type)

        emit_progress("decoding_audio")
        audio = whisperx.load_audio(audio_path)
        duration_s = float(len(audio) / 16000)

        emit_progress("transcribing")
        result = asr_model.transcribe(audio, batch_size=batch_size)
        detected = language or result.get("language")

        emit_progress("loading_align_model")
        align_model, align_meta = whisperx.load_align_model(
            language_code=detected, device=device
        )

        emit_progress("aligning")
        aligned = whisperx.align(
            result["segments"],
            align_model,
            align_meta,
            audio,
            device,
            return_char_alignments=False,
        )

        words = []
        skipped_unaligned = 0
        for segment in aligned["segments"]:
            for w in segment.get("words", []):
                # WhisperX occasionally leaves punctuation-only tokens
                # unaligned (no start/end) — same skip rule as the validated
                # c9 probe.
                if w.get("start") is None or w.get("end") is None:
                    skipped_unaligned += 1
                    continue
                words.append({
                    "word": w["word"],
                    "start": round(float(w["start"]), 6),
                    "end": round(float(w["end"]), 6),
                    "score": (
                        round(float(w["score"]), 4)
                        if w.get("score") is not None else None
                    ),
                })

        emit_progress("done", pct=1.0)
        emit_result(mode_name, {
            "language": detected,
            "duration_seconds": duration_s,
            "skipped_unaligned_words": skipped_unaligned,
            "words": words,
        })
    finally:
        stop.set()


def mode_verify(mode_name):
    """Self-test: does whisperx actually work in this venv, not just exist.

    Deliberately loads no model (fast — under a second) so this is cheap
    enough to call proactively (Settings' "Verify Installation" button,
    onboarding) rather than only discovering a broken install mid-transcribe.
    
    Implements enhanced supply chain security verification for the WhisperX environment
    and dependencies to address audit findings about package integrity.
    """
    req = read_request()
    model_name = req.get("model", "small")

    report = {
        "python_version": ".".join(str(part) for part in sys.version_info[:3]),
    }

    # Enhanced supply chain security verification
    try:
        import whisperx
        report["whisperx_import_ok"] = True
        report["whisperx_version"] = getattr(whisperx, "__version__", "unknown")
        
        # Verify package integrity by checking if it's from the expected pinned version
        if WHISPERX_PIN:
            # Extract version from pinned package name (e.g., "whisperx==3.8.6")
            expected_version = WHISPERX_PIN.split("==")[-1] if "==" in WHISPERX_PIN else None
            actual_version = getattr(whisperx, "__version__", "unknown")
            
            if expected_version and actual_version != "unknown":
                # Check that the version matches our pinned requirement
                if expected_version in actual_version or actual_version.startswith(expected_version):
                    report["whisperx_package_integrity"] = "verified"
                else:
                    report["whisperx_package_integrity"] = f"version_mismatch: expected {expected_version}, got {actual_version}"
            else:
                report["whisperx_package_integrity"] = "version_check_unavailable"
        else:
            report["whisperx_package_integrity"] = "no_version_check_configured"
            
    except Exception as exc:
        report["whisperx_import_ok"] = False
        report["whisperx_import_error"] = f"{type(exc).__name__}: {exc}"
        report["whisperx_package_integrity"] = "import_failed"

    try:
        import torch
        report["torch_import_ok"] = True
        report["torch_version"] = torch.__version__
        
        # Verify that torch is from the expected version range
        if hasattr(torch, "__version__"):
            # Basic validation that torch is from expected version range
            torch_version = torch.__version__
            report["torch_package_integrity"] = "verified" if torch_version else "verification_unavailable"
        else:
            report["torch_package_integrity"] = "version_check_unavailable"
            
    except Exception as exc:
        report["torch_import_ok"] = False
        report["torch_import_error"] = f"{type(exc).__name__}: {exc}"
        report["torch_package_integrity"] = "import_failed"

    try:
        import torchcodec
        report["torchcodec_import_ok"] = True
        report["torchcodec_version"] = getattr(torchcodec, "__version__", "unknown")
        
        # Verify torchcodec package integrity
        if hasattr(torchcodec, "__version__"):
            report["torchcodec_package_integrity"] = "verified" if torchcodec.__version__ else "verification_unavailable"
        else:
            report["torchcodec_package_integrity"] = "version_check_unavailable"
            
    except Exception as exc:
        report["torchcodec_import_ok"] = False
        report["torchcodec_import_error"] = f"{type(exc).__name__}: {exc}"
        report["torchcodec_package_integrity"] = "import_failed"

    ffmpeg_path, ffmpeg_version = ffmpeg_info()
    report["ffmpeg_found"] = ffmpeg_path is not None
    if ffmpeg_path:
        report["ffmpeg_path"] = ffmpeg_path
    report["ffmpeg_version"] = ffmpeg_version
    report["ffmpeg_library_paths"] = compatible_ffmpeg_library_directories()
    if not report.get("torchcodec_import_ok", False):
        report["torchcodec_repair_hint"] = torchcodec_repair_hint(
            ffmpeg_path,
            ffmpeg_version,
            report.get("torchcodec_import_error", ""),
        )

    report["requested_model"] = model_name
    report["model_cached"] = model_is_cached(model_name)

    # Additional security checks for the environment
    try:
        # Check that we're running from the expected application directory structure
        import os
        
        # Verify that our environment is properly isolated (not from system Python)
        python_executable = sys.executable
        if SUPPORT_DIR in python_executable:
            report["environment_isolation"] = "verified"
        else:
            report["environment_isolation"] = "questionable"
            
        # Check that the venv has proper permissions and ownership
        if os.path.exists(SUPPORT_DIR):
            report["venv_location_safe"] = "verified"
        else:
            report["venv_location_safe"] = "not_found"
            
    except Exception as exc:
        report["environment_security_check"] = f"failed: {exc}"

    emit_result(mode_name, report)


def _arg_value(flag):
    """Fallback for callers that passed options on argv instead of stdin."""
    argv = sys.argv
    if flag in argv:
        i = argv.index(flag)
        if i + 1 < len(argv):
            return argv[i + 1]
    return None


MODES = {
    "setup": mode_setup,
    "repair_ffmpeg": mode_repair_ffmpeg,
    "transcribe": mode_transcribe,
    "verify": mode_verify,
}


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in MODES:
        print(f"usage: {sys.argv[0]} {{setup|transcribe|verify|repair_ffmpeg}} [options]", file=sys.stderr)
        return 2
    # Protocol-channel hygiene: whisperx's own logging emits INFO lines on
    # stdout (verified live: "whisperx.asr - INFO - No language specified…"),
    # which would corrupt NDJSON parsing. From here on, sys.stdout IS stderr;
    # only emit() touches the captured real stdout.
    sys.stdout = sys.stderr
    mode_name = sys.argv[1]
    try:
        MODES[mode_name](mode_name)
        return 0
    except BridgeFailure as failure:
        emit_error(mode_name, failure.code, failure.message)
        return 3
    except Exception as exc:  # noqa: BLE001 — final backstop, still structured
        emit_error(mode_name, "internal_error", f"{type(exc).__name__}: {exc}")
        return 4


if __name__ == "__main__":
    sys.exit(main())
